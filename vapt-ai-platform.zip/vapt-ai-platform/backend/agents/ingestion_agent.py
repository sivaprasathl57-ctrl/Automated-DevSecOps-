"""
Agent 1 — Ingestion Agent
Walks an uploaded project directory, builds a file inventory, detects the
tech stack, and locates dependency manifests for the Dependency Agent.
"""
import os

CODE_EXTENSIONS = {
    ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript", ".jsx": "JavaScript (React)",
    ".tsx": "TypeScript (React)", ".java": "Java", ".php": "PHP", ".rb": "Ruby",
    ".go": "Go", ".c": "C", ".cpp": "C++", ".cs": "C#", ".html": "HTML", ".yml": "YAML",
    ".yaml": "YAML", ".json": "JSON",
}

MANIFEST_FILES = {
    "requirements.txt": "pip",
    "package.json": "npm",
    "pom.xml": "maven",
    "build.gradle": "gradle",
    "Gemfile": "bundler",
    "go.mod": "go",
    "composer.json": "composer",
}

SKIP_DIRS = {".git", "node_modules", "venv", ".venv", "__pycache__", "dist", "build", ".next"}


def ingest(root_dir: str) -> dict:
    """Returns an inventory: files scanned, language breakdown, manifests found."""
    inventory = {
        "files": [],           # list of {path, language, size}
        "manifests": [],       # list of {path, ecosystem}
        "language_counts": {},
        "total_files": 0,
        "total_size": 0,
    }

    for dirpath, dirnames, filenames in os.walk(root_dir):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fname in filenames:
            fpath = os.path.join(dirpath, fname)
            rel = os.path.relpath(fpath, root_dir)
            ext = os.path.splitext(fname)[1].lower()

            if fname in MANIFEST_FILES:
                inventory["manifests"].append({"path": rel, "ecosystem": MANIFEST_FILES[fname]})

            if ext in CODE_EXTENSIONS:
                try:
                    size = os.path.getsize(fpath)
                except OSError:
                    size = 0
                lang = CODE_EXTENSIONS[ext]
                inventory["files"].append({"path": rel, "language": lang, "size": size})
                inventory["language_counts"][lang] = inventory["language_counts"].get(lang, 0) + 1
                inventory["total_files"] += 1
                inventory["total_size"] += size

    return inventory
