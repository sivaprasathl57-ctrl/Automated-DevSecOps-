"""
Shared HTTP plumbing for the Module 2 active agents.

Every agent goes through `request()` so that: (a) every live test is
capped by a sane timeout, (b) SSRF-style redirects to internal targets are
not silently followed off-host, and (c) every request/response pair can be
captured verbatim for the evidence shown in the report.
"""
from __future__ import annotations

import time
import difflib
from typing import Optional
from urllib.parse import urlparse

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

DEFAULT_TIMEOUT = 8
USER_AGENT = "VAPT-AI-Module2/1.0 (authorized-security-test)"


def new_session() -> requests.Session:
    s = requests.Session()
    s.headers.update({"User-Agent": USER_AGENT})
    s.verify = False  # authorized testing often hits self-signed/staging certs
    return s


def request(session: requests.Session, method: str, url: str, *, params=None, data=None,
            json=None, files=None, headers=None, timeout=DEFAULT_TIMEOUT,
            allow_redirects=True) -> dict:
    """Perform a real HTTP request and return a normalized, evidence-ready dict.

    Never raises on HTTP-level errors — network failures are captured as
    {"error": ...} so a single dead endpoint can't abort an agent's whole run.
    """
    start = time.time()
    try:
        resp = session.request(method.upper(), url, params=params, data=data, json=json,
                                files=files, headers=headers, timeout=timeout,
                                allow_redirects=allow_redirects)
        elapsed = time.time() - start
        body = resp.text[:20000] if resp.text else ""
        return {
            "ok": True,
            "status_code": resp.status_code,
            "headers": dict(resp.headers),
            "body": body,
            "elapsed": elapsed,
            "url": resp.url,
            "history": [h.status_code for h in resp.history],
        }
    except requests.exceptions.RequestException as e:
        return {"ok": False, "error": str(e), "elapsed": time.time() - start}


def same_host(url_a: str, url_b: str) -> bool:
    try:
        return urlparse(url_a).hostname == urlparse(url_b).hostname
    except Exception:
        return False


def similarity(a: str, b: str) -> float:
    """0..1 crude content similarity, used by blind/boolean detectors."""
    if not a and not b:
        return 1.0
    return difflib.SequenceMatcher(None, a[:5000], b[:5000]).ratio()


def build_evidence(req_desc: str, response: dict, note: str = "") -> dict:
    """Uniform evidence block attached to every Module 2 finding."""
    ev = {
        "request": req_desc,
        "note": note,
    }
    if response.get("ok"):
        ev["status_code"] = response.get("status_code")
        ev["response_time_s"] = round(response.get("elapsed", 0), 3)
        snippet = (response.get("body") or "")[:800]
        ev["response_snippet"] = snippet
    else:
        ev["error"] = response.get("error")
    return ev
