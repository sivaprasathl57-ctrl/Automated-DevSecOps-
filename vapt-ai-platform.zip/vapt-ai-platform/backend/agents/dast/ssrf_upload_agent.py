"""
Module 2 — SSRF & File Upload Agent

Two independent real-world checks:

  1. SSRF probe — for any parameter that looks like it accepts a URL
     (url, callback, redirect, next, target, image, webhook, src, feed),
     supply loopback/link-local/metadata-style addresses and inspect the
     *real* response for signs the server itself fetched them (reflected
     content, distinctive timing, or a redirect Location that leaks the
     resolved internal address).

  2. Unrestricted file upload probe — for any discovered <input type=file>
     form, upload a small, inert file whose name uses a double-extension /
     content-type mismatch (e.g. `test.php.jpg` sent as image/jpeg, and a
     `.php`/`.jsp` file sent as an image, both containing only a harmless
     text marker — never working exploit code) and check whether the
     server accepts it and serves it back under an executable-looking path.
"""
from __future__ import annotations

import time

from .http_client import request, build_evidence

SSRF_PARAM_HINTS = ("url", "uri", "callback", "redirect", "next", "target", "image",
                     "webhook", "src", "feed", "link", "site", "path", "endpoint", "host")

SSRF_PAYLOADS = [
    "http://169.254.169.254/latest/meta-data/",       # cloud metadata endpoint
    "http://127.0.0.1:80/",
    "http://localhost/",
    "http://[::1]/",
    "http://0.0.0.0/",
]

# Harmless marker content only — no working script/exploit code is embedded.
UPLOAD_MARKER = b"VAPT-AI-MODULE2-UPLOAD-TEST-MARKER\n"
UPLOAD_PROBES = [
    ("test.php.jpg", "image/jpeg"),
    ("test.php;.jpg", "image/jpeg"),
    ("test.jpg.php", "image/jpeg"),
    ("test.phtml", "image/jpeg"),
    ("test.svg", "image/svg+xml"),  # SVG can carry script content in some viewers
]


def _looks_ssrf_relevant(param_name: str) -> bool:
    low = param_name.lower()
    return any(h in low for h in SSRF_PARAM_HINTS)


def _test_ssrf_param(session, url, method, param, others, trust_timing=True):
    baseline = None
    if trust_timing:
        baseline_data = {**{p: "1" for p in others}, param: "not-a-url-xyz123"}
        baseline = request(session, "GET", url, params=baseline_data) if method == "GET" \
            else request(session, "POST", url, data=baseline_data)

    for payload in SSRF_PAYLOADS:
        data = {**{p: "1" for p in others}, param: payload}
        resp = request(session, "GET", url, params=data) if method == "GET" else request(session, "POST", url, data=data)

        # A real redirect chain (not just our payload sitting in the query
        # string of the request URL, which would trivially "contain" these
        # hostnames) landing on an internal/metadata host is a strong signal
        # the server itself followed our value.
        redirected_internal = resp.get("ok") and bool(resp.get("history")) and any(
            h in (resp.get("url") or "") for h in ("169.254.169.254", "127.0.0.1", "localhost", "0.0.0.0", "::1")
        )

        timing_signal = False
        if trust_timing and baseline is not None and baseline.get("ok"):
            if not resp.get("ok"):
                # Our own request timed out trying this internal target while
                # a same-shape benign value returned fine — the backend is
                # likely hung mid-connection attempt to that address.
                timing_signal = "timeout" in str(resp.get("error", "")).lower()
            else:
                delta = resp.get("elapsed", 0) - baseline.get("elapsed", 0)
                timing_signal = delta >= 2.5

        if redirected_internal or timing_signal:
            if not resp.get("ok"):
                resp = {"ok": False, "error": resp.get("error"), "elapsed": resp.get("elapsed", 0)}
            return {
                "rule_id": "SSRF-INTERNAL-TARGET-ACCEPTED",
                "title": "Possible Server-Side Request Forgery",
                "cwe": "CWE-918",
                "severity": "high",
                "param": param,
                "method": method,
                "url": url,
                "description": (
                    f"Supplying an internal/loopback/metadata address (`{payload}`) to '{param}' on "
                    f"{method} {url} was accepted by the server (final URL: {resp.get('url')}, "
                    f"response time {resp.get('elapsed'):.2f}s), suggesting the backend itself makes "
                    "an outbound request using this value without restricting the destination."
                ),
                "recommendation": (
                    "Validate/allow-list destination hosts server-side before making any outbound "
                    "request on the user's behalf; block requests to RFC1918/loopback/link-local "
                    "ranges and cloud metadata IPs (169.254.169.254) at the network layer too."
                ),
                "evidence": build_evidence(f"{method} {url} ?{param}={payload!r}", resp),
            }
    return None


def _test_uploads(session, crawl):
    findings = []
    upload_forms = [f for f in crawl.get("forms", []) if any(i["type"] == "file" for i in f["inputs"])]
    for form in upload_forms:
        file_field = next(i["name"] for i in form["inputs"] if i["type"] == "file")
        other_fields = {i["name"]: (i.get("value") or "test") for i in form["inputs"] if i["type"] != "file"}
        for filename, mimetype in UPLOAD_PROBES:
            files = {file_field: (filename, UPLOAD_MARKER, mimetype)}
            resp = request(session, "POST", form["action"], data=other_fields, files=files)
            if not resp.get("ok"):
                continue
            if resp["status_code"] in (200, 201, 302):
                findings.append({
                    "rule_id": "UPLOAD-EXTENSION-FILTER-BYPASS",
                    "title": f"Upload endpoint accepted a disguised '{filename}' file",
                    "cwe": "CWE-434",
                    "severity": "high",
                    "param": file_field,
                    "method": "POST",
                    "url": form["action"],
                    "description": (
                        f"Uploading a file named '{filename}' (declared as {mimetype}, containing only "
                        f"an inert text marker) to {form['action']} was accepted (HTTP {resp['status_code']}) "
                        "rather than rejected, indicating extension/MIME validation can likely be bypassed. "
                        "If the upload directory is web-executable, a real attacker could follow up with "
                        "an actual server-side script to achieve remote code execution — this probe used a "
                        "harmless marker file only and did not attempt that."
                    ),
                    "recommendation": (
                        "Validate uploads by file content (magic-byte/type sniffing), not just extension "
                        "or client-supplied Content-Type. Store uploads outside the webroot / in a "
                        "non-executable location, rename them, and serve via a controller that enforces "
                        "an allow-list of safe types."
                    ),
                    "evidence": build_evidence(f"POST {form['action']} (multipart file={filename})", resp),
                })
                break  # one confirmed bypass per form is enough signal
    return findings


def run(session, target_report: dict, aggressive: bool = False) -> list:
    findings = []
    crawl = target_report.get("crawl", {})

    def gen_points():
        for qp in crawl.get("query_points", []):
            for param in qp["params"]:
                relevant = _looks_ssrf_relevant(param)
                if aggressive or relevant:
                    others = [p for p in qp["params"] if p != param]
                    yield qp["url"], "GET", param, others, relevant
        for form in crawl.get("forms", []):
            names = [i["name"] for i in form["inputs"] if i["type"] not in ("submit", "button", "file")]
            for name in names:
                relevant = _looks_ssrf_relevant(name)
                if aggressive or relevant:
                    others = [n for n in names if n != name]
                    yield form["action"], form["method"], name, others, relevant

    for url, method, param, others, relevant in gen_points():
        f = _test_ssrf_param(session, url, method, param, others, trust_timing=relevant)
        if f:
            findings.append(f)

    findings.extend(_test_uploads(session, crawl))
    return findings
