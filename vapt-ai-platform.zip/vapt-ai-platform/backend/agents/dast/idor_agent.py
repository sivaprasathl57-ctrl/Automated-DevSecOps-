"""
Module 2 — IDOR (Insecure Direct Object Reference) Agent

Real black-box probe: for every numeric object identifier the crawler found
(either in the URL path like /invoice/1042 or in a query param like
?user_id=1042), request neighboring IDs (n-1, n+1, and a same-session
re-request) and inspect the *actual* HTTP responses.

Heuristic: if a neighboring, presumably-not-ours ID returns 200 with a
distinctly different, substantial body (not a login redirect / 403 / 404 /
generic error page), that's a strong signal the endpoint is not enforcing
per-object authorization.
"""
from __future__ import annotations

from urllib.parse import urlparse

from .http_client import request, build_evidence, similarity

DENY_MARKERS = ("login", "sign in", "not authorized", "forbidden", "access denied", "permission denied")


def _looks_like_deny(status_code, body):
    if status_code in (401, 403, 404):
        return True
    low = (body or "").lower()
    return any(m in low for m in DENY_MARKERS)


def _probe_path_id(session, point):
    url = point["url"]
    idx = point["segment_index"]
    value = point["value"]
    parsed = urlparse(url)
    segments = [s for s in parsed.path.split("/") if s]

    baseline = request(session, "GET", url)
    if not baseline.get("ok"):
        return None

    try:
        neighbor_val = str(int(value) + 1)
    except ValueError:
        return None
    segments[idx] = neighbor_val
    neighbor_path = "/" + "/".join(segments)
    neighbor_url = f"{parsed.scheme}://{parsed.netloc}{neighbor_path}"
    neighbor_resp = request(session, "GET", neighbor_url)
    if not neighbor_resp.get("ok"):
        return None

    if _looks_like_deny(neighbor_resp["status_code"], neighbor_resp.get("body", "")):
        return None
    if neighbor_resp["status_code"] != 200:
        return None

    body_sim = similarity(baseline.get("body", ""), neighbor_resp.get("body", ""))
    # A distinct-but-substantial body for a *different* object id (rather
    # than an identical template/error page) is the IDOR tell.
    if len(neighbor_resp.get("body", "")) > 40 and body_sim < 0.95:
        return {
            "rule_id": "IDOR-PATH-ID",
            "title": "Possible IDOR via sequential object ID in URL path",
            "cwe": "CWE-639",
            "severity": "high",
            "param": f"path segment #{idx}",
            "method": "GET",
            "url": url,
            "description": (
                f"Requesting {url} returns object '{value}'. Simply incrementing that ID to "
                f"'{neighbor_val}' ({neighbor_url}) also returns HTTP 200 with distinct content, "
                "with no ownership/authorization check observed — a different user's/record's data "
                "may be exposed just by changing the ID."
            ),
            "recommendation": "Enforce server-side authorization on every object fetch (verify the "
                               "authenticated identity owns/may access the requested record); prefer "
                               "unguessable identifiers (UUIDs) over sequential integers as defense in depth.",
            "evidence": build_evidence(f"GET {url} vs GET {neighbor_url}", neighbor_resp,
                                        note=f"Original id='{value}' status={baseline['status_code']}; "
                                             f"neighbor id='{neighbor_val}' status={neighbor_resp['status_code']}, "
                                             f"content similarity={body_sim:.2f}"),
        }
    return None


def _probe_query_id(session, qp):
    url = qp["url"]
    findings = []
    for param in qp["params"]:
        baseline_params = {p: "1" for p in qp["params"]}
        baseline = request(session, "GET", url, params=baseline_params)
        if not baseline.get("ok"):
            continue
        neighbor_params = {**baseline_params, param: "2"}
        neighbor = request(session, "GET", url, params=neighbor_params)
        if not neighbor.get("ok") or _looks_like_deny(neighbor["status_code"], neighbor.get("body", "")):
            continue
        if neighbor["status_code"] != 200:
            continue
        body_sim = similarity(baseline.get("body", ""), neighbor.get("body", ""))
        if len(neighbor.get("body", "")) > 40 and body_sim < 0.95:
            findings.append({
                "rule_id": "IDOR-QUERY-PARAM",
                "title": f"Possible IDOR via '{param}' query parameter",
                "cwe": "CWE-639",
                "severity": "high",
                "param": param,
                "method": "GET",
                "url": url,
                "description": (
                    f"Changing '{param}' from 1 to 2 on {url} returns HTTP 200 with distinct content "
                    "and no visible ownership check — another user's/record's object may be reachable "
                    "just by tampering with this parameter."
                ),
                "recommendation": "Validate that the authenticated caller is authorized for the specific "
                                   "object id server-side on every request, not just that they're logged in.",
                "evidence": build_evidence(f"GET {url}?{param}=1 vs ?{param}=2", neighbor,
                                            note=f"content similarity={body_sim:.2f}"),
            })
    return findings


def run(session, target_report: dict, aggressive: bool = False) -> list:
    crawl = target_report.get("crawl", {})
    findings = []
    for point in crawl.get("path_id_points", []):
        f = _probe_path_id(session, point)
        if f:
            findings.append(f)

    from .crawler import id_like_params
    for qp in id_like_params(crawl.get("query_points", [])):
        findings.extend(_probe_query_id(session, qp))

    return findings
