"""
Module 2 Orchestrator — Active Vulnerability Agents

Runs, in order, against a single authorized live target:
  0. Target Mapper       -> crawls the real site to find real injection surfaces
  1. XSS Agent           -> reflected XSS (multiple technique families)
  2. SQL Injection Agent -> error-based, boolean-blind, time-blind
  3. CSRF Agent          -> missing tokens, cookie SameSite
  4. IDOR Agent          -> object reference tampering
  5. Path Traversal Agent-> LFI / directory traversal
  6. Auth & Authz Agent  -> cookie hardening, JWT, exposed admin paths, user enum
  7. SSRF & Upload Agent -> internal-target SSRF, unrestricted file upload
  8. Misconfiguration    -> headers, exposed files, CORS, dangerous methods

Every finding carries a real request/response evidence block captured live
from the target — this is an active black-box scan, not a static demo.

AUTHORIZATION GATE: exactly like Module 1, the caller (API layer) must
confirm the user attested they own or are explicitly authorized to test
the target before this orchestrator is ever invoked.
"""
import asyncio
import time
from typing import AsyncGenerator
from urllib.parse import urlparse

from . import crawler, xss_agent, sqli_agent, csrf_agent, idor_agent
from . import path_traversal_agent, auth_agent, ssrf_upload_agent, misconfig_agent
from . import code_agent
from .http_client import new_session

AGENT_REGISTRY = {
    "xss":             ("Cross-Site Scripting (XSS)", xss_agent),
    "sqli":            ("SQL Injection", sqli_agent),
    "csrf":            ("CSRF", csrf_agent),
    "idor":            ("IDOR", idor_agent),
    "path_traversal":  ("Path Traversal / LFI", path_traversal_agent),
    "auth":            ("Authentication & Authorization", auth_agent),
    "ssrf_upload":     ("SSRF & File Upload", ssrf_upload_agent),
    "misconfig":       ("Security Misconfiguration", misconfig_agent),
}


def _normalize_target(target: str):
    if "://" not in target:
        target = f"https://{target}"
    parsed = urlparse(target)
    base_url = f"{parsed.scheme}://{parsed.netloc}"
    return base_url


async def run_scan(job: dict, target: str, selected_agents: list, aggressive: bool = False,
                    root_dir: str = None) -> AsyncGenerator[dict, None]:

    def emit(agent, status, message, findings_count=None):
        ev = {"job_id": job["id"], "agent": agent, "status": status,
              "message": message, "timestamp": time.time()}
        if findings_count is not None:
            ev["findings_count"] = findings_count
        job["events"].append(ev)
        return ev

    job["status"] = "running"
    job["report"]["findings"] = []
    all_findings = []
    agents_to_run = [a for a in selected_agents if a in AGENT_REGISTRY] or list(AGENT_REGISTRY.keys())

    # ---- Live active testing against a target URL (if provided) ----
    if target:
        base_url = _normalize_target(target)
        job["report"]["target"] = base_url
        session = new_session()

        yield emit("mapper", "started", f"Crawling {base_url} to discover real forms, parameters, and object IDs...")
        try:
            crawl = await asyncio.to_thread(crawler.crawl, base_url, session)
            job["report"]["crawl"] = crawl
            job["report"]["base_url"] = base_url
            yield emit("mapper", "completed",
                        f"Mapped {crawl['pages_crawled']} page(s): {len(crawl['forms'])} form(s), "
                        f"{len(crawl['query_points'])} parameterized URL(s), "
                        f"{len(crawl['path_id_points'])} numeric path ID(s).")
        except Exception as e:
            job["report"]["crawl"] = {"error": str(e)}
            job["report"]["base_url"] = base_url
            yield emit("mapper", "error", f"Target mapping failed: {e}")

        for key in agents_to_run:
            label, module = AGENT_REGISTRY[key]
            yield emit(key, "started", f"{label} agent sending live test requests to {base_url}...")
            try:
                findings = await asyncio.to_thread(module.run, session, job["report"], aggressive)
                for f in findings:
                    f["agent"] = key
                    f["agent_label"] = label
                    f["finding_type"] = "live_request"
                all_findings.extend(findings)
                job["report"]["findings"] = all_findings
                if findings:
                    yield emit(key, "completed", f"{label} complete — {len(findings)} finding(s).", len(findings))
                else:
                    yield emit(key, "completed", f"{label} complete — no issues detected.", 0)
            except Exception as e:
                yield emit(key, "error", f"{label} agent failed: {e}")

    # ---- Source-code scan against an uploaded project folder (if provided) ----
    if root_dir:
        for key in agents_to_run:
            label = code_agent.AGENT_LABELS.get(key, key)
            yield emit(key, "started", f"{label} agent scanning uploaded source code for real vulnerable code locations...")
            try:
                findings = await asyncio.to_thread(code_agent.scan_category, key, root_dir)
                all_findings.extend(findings)
                job["report"]["findings"] = all_findings
                if findings:
                    yield emit(key, "completed", f"{label} source scan complete — {len(findings)} finding(s).", len(findings))
                else:
                    yield emit(key, "completed", f"{label} source scan complete — no matching patterns found.", 0)
            except Exception as e:
                yield emit(key, "error", f"{label} source scan failed: {e}")

    job["report"]["executive_summary"] = _build_executive_summary(all_findings, agents_to_run)
    job["status"] = "completed"
    yield emit("summary", "completed", f"Module 2 scan finished. {len(all_findings)} total finding(s) across {len(agents_to_run)} agent(s).")


def _build_executive_summary(findings: list, agents_run: list) -> dict:
    sev_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for f in findings:
        if not f.get("is_fixed", False):
            sev_counts[f.get("severity", "info")] = sev_counts.get(f.get("severity", "info"), 0) + 1

    score = 100
    score -= sev_counts["critical"] * 25
    score -= sev_counts["high"] * 12
    score -= sev_counts["medium"] * 5
    score -= sev_counts["low"] * 2
    score = max(0, min(100, score))

    if score >= 80:
        rating = "Good"
    elif score >= 55:
        rating = "Needs Attention"
    else:
        rating = "At Risk"

    by_agent = {}
    for f in findings:
        by_agent[f.get("agent")] = by_agent.get(f.get("agent"), 0) + 1

    return {
        "risk_score": score,
        "risk_rating": rating,
        "total_findings": len(findings),
        "severity_counts": sev_counts,
        "findings_by_agent": by_agent,
        "agents_run": agents_run,
    }
