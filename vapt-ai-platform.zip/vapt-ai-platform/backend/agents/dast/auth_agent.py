"""
Module 2 — Authentication & Authorization Agent

Real, non-destructive checks against the live target (no credential
guessing/brute force is performed):
  1. Session cookie hardening — HttpOnly / Secure / SameSite flags.
  2. JWTs (in cookies or bearer-looking strings on the page) decoded to
     check for `alg: none` / weak `alg` — a real, structural weakness,
     not a guess.
  3. Sensitive admin/auth paths reachable without a session at all.
  4. Username enumeration — comparing real "invalid user" vs "invalid
     password" responses on any discovered login form.
  5. Missing `Referrer-Policy` on pages that carry a session token in the URL.
"""
from __future__ import annotations

import base64
import json
import re

from .http_client import request, build_evidence, similarity

SENSITIVE_PATHS = [
    "/admin", "/admin/", "/administrator", "/wp-admin", "/manage", "/dashboard",
    "/api/admin", "/console", "/actuator", "/actuator/env", "/debug",
]

JWT_RE = re.compile(r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*")


def _b64url_decode(seg):
    seg += "=" * (-len(seg) % 4)
    try:
        return json.loads(base64.urlsafe_b64decode(seg.encode()))
    except Exception:
        return None


def _check_cookies(session, base_url):
    findings = []
    request(session, "GET", base_url)
    for c in session.cookies:
        name_l = c.name.lower()
        if not any(h in name_l for h in ("sess", "auth", "token", "jwt", "sid")):
            continue
        issues = []
        if not c.secure:
            issues.append("missing Secure flag")
        rest = getattr(c, "_rest", {}) or {}
        http_only = any(k.lower() == "httponly" for k in rest.keys())
        if not http_only:
            issues.append("missing HttpOnly flag")
        if issues:
            findings.append({
                "rule_id": "AUTH-COOKIE-FLAGS",
                "title": f"Session cookie '{c.name}' missing hardening flag(s)",
                "cwe": "CWE-614",
                "severity": "medium",
                "param": c.name,
                "method": "GET",
                "url": base_url,
                "description": (
                    f"The session/auth cookie '{c.name}' set by {base_url} is {', '.join(issues)}. "
                    "Without HttpOnly, JavaScript (e.g. from an XSS bug) can read the cookie; "
                    "without Secure, it can be sent over plaintext HTTP."
                ),
                "recommendation": "Set `HttpOnly`, `Secure`, and `SameSite=Lax/Strict` on every session/auth cookie.",
                "evidence": build_evidence(f"GET {base_url}", {"ok": True, "status_code": 200, "elapsed": 0, "body": ""},
                                            note=f"Cookie flags observed missing: {issues}"),
            })
    return findings


def _check_jwt(session, base_url):
    findings = []
    resp = request(session, "GET", base_url)
    if not resp.get("ok"):
        return findings
    candidates = set(JWT_RE.findall(resp.get("body", "")))
    for c in session.cookies:
        if JWT_RE.fullmatch(c.value or ""):
            candidates.add(c.value)
    for token in candidates:
        parts = token.split(".")
        if len(parts) < 2:
            continue
        header = _b64url_decode(parts[0])
        if not header:
            continue
        alg = str(header.get("alg", "")).lower()
        if alg in ("none", ""):
            findings.append({
                "rule_id": "AUTH-JWT-ALG-NONE",
                "title": "JWT accepts/uses insecure 'alg: none'",
                "cwe": "CWE-347",
                "severity": "critical",
                "param": None,
                "method": "GET",
                "url": base_url,
                "description": (
                    f"A JWT observed on {base_url} declares header alg='{header.get('alg')}', which "
                    "means the token's signature is not cryptographically verified — an attacker "
                    "can forge arbitrary claims (e.g. role=admin)."
                ),
                "recommendation": "Reject tokens with alg=none server-side; pin the expected algorithm "
                                   "(e.g. RS256) rather than trusting the token's own `alg` header.",
                "evidence": build_evidence(f"GET {base_url}", resp, note=f"Decoded JWT header: {header}"),
            })
        elif alg.startswith("hs") :
            findings.append({
                "rule_id": "AUTH-JWT-WEAK-ALG",
                "title": f"JWT uses symmetric algorithm '{header.get('alg')}'",
                "cwe": "CWE-326",
                "severity": "low",
                "param": None,
                "method": "GET",
                "url": base_url,
                "description": (
                    f"A JWT observed on {base_url} uses {header.get('alg')} (HMAC). This is not a "
                    "vulnerability by itself, but if the signing secret is weak/guessable or the "
                    "verifier can be tricked into accepting a public RSA key as an HMAC secret "
                    "(alg-confusion), tokens can be forged."
                ),
                "recommendation": "Use a long, high-entropy signing secret (or move to RS256/ES256) "
                                   "and ensure the verifier pins the expected algorithm.",
                "evidence": build_evidence(f"GET {base_url}", resp, note=f"Decoded JWT header: {header}"),
            })
    return findings


def _check_sensitive_paths(session, base_url):
    findings = []
    for path in SENSITIVE_PATHS:
        url = base_url.rstrip("/") + path
        resp = request(session, "GET", url, allow_redirects=False)
        if not resp.get("ok"):
            continue
        if resp["status_code"] == 200 and len(resp.get("body", "")) > 50:
            findings.append({
                "rule_id": "AUTHZ-UNAUTHENTICATED-SENSITIVE-PATH",
                "title": f"Sensitive path reachable without authentication: {path}",
                "cwe": "CWE-306",
                "severity": "high",
                "param": None,
                "method": "GET",
                "url": url,
                "description": (
                    f"{url} returned HTTP 200 with no session/authentication supplied, suggesting "
                    "an administrative or internal surface is exposed to anonymous users."
                ),
                "recommendation": "Require authentication (and role-based authorization) before serving "
                                   "any administrative/management endpoint; return 401/redirect-to-login otherwise.",
                "evidence": build_evidence(f"GET {url} (no auth)", resp),
            })
    return findings


def _check_username_enum(session, target_report):
    findings = []
    login_form = None
    for form in target_report.get("crawl", {}).get("forms", []):
        names = [i["name"].lower() for i in form["inputs"]]
        if any("pass" in n for n in names) and any(("user" in n or "email" in n) for n in names):
            login_form = form
            break
    if not login_form:
        return findings

    user_field = next(i["name"] for i in login_form["inputs"] if "user" in i["name"].lower() or "email" in i["name"].lower())
    pass_field = next(i["name"] for i in login_form["inputs"] if "pass" in i["name"].lower())

    resp_unknown_user = request(session, "POST", login_form["action"],
                                 data={user_field: "definitely-not-a-real-user-9f8x", pass_field: "wrongpass123"})
    if not resp_unknown_user.get("ok"):
        return findings

    # Only usernames — no password guessing/brute forcing is performed. We
    # try a handful of common account names to see whether *any* of them
    # produces a response distinguishable from the known-fake user above.
    for candidate_user in ("admin", "administrator", "test", "user", "root"):
        resp_candidate = request(session, "POST", login_form["action"],
                                  data={user_field: candidate_user, pass_field: "wrongpass123"})
        if not resp_candidate.get("ok"):
            continue
        if resp_candidate["status_code"] != resp_unknown_user["status_code"] or \
           similarity(resp_unknown_user.get("body", ""), resp_candidate.get("body", "")) < 0.9:
            findings.append({
                "rule_id": "AUTH-USERNAME-ENUMERATION",
                "title": "Login form reveals whether a username exists",
                "cwe": "CWE-204",
                "severity": "medium",
                "param": user_field,
                "method": "POST",
                "url": login_form["action"],
                "description": (
                    f"POSTing a fabricated username vs. the common account name '{candidate_user}' to "
                    f"{login_form['action']} produces distinguishably different responses (status or "
                    "body), letting an attacker enumerate valid usernames before attempting credential attacks."
                ),
                "recommendation": "Return an identical, generic 'invalid username or password' response "
                                   "(same status, same timing, same body) regardless of which field was wrong.",
                "evidence": build_evidence(f"POST {login_form['action']}", resp_candidate,
                                            note=f"unknown-user status={resp_unknown_user['status_code']} vs "
                                                 f"'{candidate_user}' status={resp_candidate['status_code']}"),
            })
            break
    return findings


def run(session, target_report: dict, aggressive: bool = False) -> list:
    base_url = target_report.get("base_url")
    findings = []
    findings.extend(_check_cookies(session, base_url))
    findings.extend(_check_jwt(session, base_url))
    findings.extend(_check_sensitive_paths(session, base_url))
    findings.extend(_check_username_enum(session, target_report))
    return findings
