"""
Module 2 — Target Mapper

Crawls the *real* live target (homepage + same-host links, one hop deep)
and extracts genuine, testable injection surfaces:
  - query-string parameters found on crawled links
  - HTML forms (action, method, every named input incl. type=file)
  - path segments that look like object identifiers (for IDOR probing)

This is intentionally small/bounded (a handful of pages, not a full spider)
so Module 2 stays fast and polite to the target.
"""
from __future__ import annotations

import re
from urllib.parse import urlparse, urljoin, parse_qs

from bs4 import BeautifulSoup

from .http_client import request

MAX_PAGES = 12
ID_LIKE_PARAM_RE = re.compile(r'(^|_)(id|uid|user|uuid|acct|account|order|doc|file|invoice|ref|num|no)(_|$)', re.I)
NUMERIC_SEGMENT_RE = re.compile(r'^\d+$')


def _extract_forms(base_url, html):
    soup = BeautifulSoup(html, "html.parser")
    forms = []
    for f in soup.find_all("form"):
        action = urljoin(base_url, f.get("action") or base_url)
        method = (f.get("method") or "GET").upper()
        inputs = []
        for tag in f.find_all(["input", "textarea", "select"]):
            name = tag.get("name")
            if not name:
                continue
            inputs.append({
                "name": name,
                "type": (tag.get("type") or "text").lower() if tag.name == "input" else tag.name,
                "value": tag.get("value", ""),
            })
        forms.append({"action": action, "method": method, "inputs": inputs})
    return forms


def _extract_links(base_url, html):
    soup = BeautifulSoup(html, "html.parser")
    links = set()
    for a in soup.find_all("a", href=True):
        links.add(urljoin(base_url, a["href"]))
    return links


def crawl(base_url: str, session) -> dict:
    parsed_base = urlparse(base_url)
    visited = set()
    to_visit = [base_url]
    forms = []
    query_points = []   # {"url": bare_url, "params": [...]}
    path_id_points = []  # {"url": ..., "segment_index": i, "value": "123"}

    while to_visit and len(visited) < MAX_PAGES:
        url = to_visit.pop(0)
        if url in visited:
            continue
        visited.add(url)

        resp = request(session, "GET", url)
        if not resp.get("ok"):
            continue
        html = resp.get("body") or ""

        parsed = urlparse(url)
        if parsed.query:
            qs = parse_qs(parsed.query)
            if qs:
                query_points.append({
                    "url": url.split("?")[0],
                    "method": "GET",
                    "params": list(qs.keys()),
                })

        segments = [s for s in parsed.path.split("/") if s]
        for i, seg in enumerate(segments):
            if NUMERIC_SEGMENT_RE.match(seg):
                path_id_points.append({"url": url, "segment_index": i, "value": seg})

        page_forms = _extract_forms(url, html)
        forms.extend(page_forms)

        for link in _extract_links(url, html):
            lp = urlparse(link)
            if lp.hostname == parsed_base.hostname and link not in visited and len(visited) + len(to_visit) < MAX_PAGES:
                to_visit.append(link)

    # de-duplicate query points by (url, tuple(params))
    seen = set()
    dedup_qp = []
    for qp in query_points:
        key = (qp["url"], tuple(sorted(qp["params"])))
        if key not in seen:
            seen.add(key)
            dedup_qp.append(qp)

    return {
        "pages_crawled": len(visited),
        "forms": forms,
        "query_points": dedup_qp,
        "path_id_points": path_id_points[:20],
    }


def id_like_params(query_points):
    """Filter query points down to the ones whose param names look like object refs."""
    out = []
    for qp in query_points:
        matches = [p for p in qp["params"] if ID_LIKE_PARAM_RE.search(p)]
        if matches:
            out.append({**qp, "params": matches})
    return out
