"""
Module 2 — CSRF Agent

Real, non-destructive checks against every state-changing form the crawler
found, plus the session cookies actually set by the live target:
  1. Does the form ship a hidden anti-CSRF token field?
  2. Does the target send a custom CSRF header requirement (checked via a
     same-origin vs. no-origin/no-referer request diff)?
  3. Are session cookies missing SameSite, which is the browser-level
     backstop against CSRF?
"""
from __future__ import annotations

from .http_client import request, build_evidence

TOKEN_NAME_HINTS = ("csrf", "xsrf", "_token", "authenticity_token", "requestverificationtoken", "nonce")


def _form_has_token(form) -> bool:
    for inp in form["inputs"]:
        name = (inp.get("name") or "").lower()
        if any(hint in name for hint in TOKEN_NAME_HINTS):
            return True
    return False


def _check_state_changing_forms(crawl):
    findings = []
    for form in crawl.get("forms", []):
        if form["method"] != "POST":
            continue
        if _form_has_token(form):
            continue
        findings.append({
            "rule_id": "CSRF-MISSING-TOKEN",
            "title": "State-changing form missing anti-CSRF token",
            "cwe": "CWE-352",
            "severity": "medium",
            "param": None,
            "method": "POST",
            "url": form["action"],
            "description": (
                f"The POST form at {form['action']} has no hidden CSRF token field "
                f"(checked for names containing: {', '.join(TOKEN_NAME_HINTS)}). Without one, "
                "a malicious page can auto-submit a forged request to this endpoint using the "
                "victim's existing session cookie."
            ),
            "recommendation": "Issue a per-session (or per-request) anti-CSRF token, embed it as a "
                               "hidden field, and reject submissions where it's missing/invalid. "
                               "Pair with SameSite=Lax/Strict cookies.",
            "evidence": build_evidence(f"POST {form['action']}", {"ok": True, "status_code": None, "elapsed": 0, "body": ""},
                                        note=f"Form fields seen: {[i['name'] for i in form['inputs']]}"),
        })
    return findings


def _check_cookie_samesite(session, base_url):
    findings = []
    resp = request(session, "GET", base_url)
    if not resp.get("ok"):
        return findings
    raw_cookies = resp["headers"]
    set_cookie_headers = []
    # requests' response.headers collapses multiple Set-Cookie into one string
    # joined by ", " in some transports; fall back to the session cookie jar too.
    for c in session.cookies:
        same_site = getattr(c, "_rest", {}).get("SameSite") or getattr(c, "_rest", {}).get("samesite")
        if not same_site:
            findings.append({
                "rule_id": "CSRF-COOKIE-NO-SAMESITE",
                "title": f"Cookie '{c.name}' missing SameSite attribute",
                "cwe": "CWE-352",
                "severity": "low",
                "param": c.name,
                "method": "GET",
                "url": base_url,
                "description": (
                    f"The cookie '{c.name}' set by {base_url} has no SameSite attribute, so "
                    "the browser will attach it to cross-site requests — removing a key "
                    "built-in mitigation against CSRF for any endpoint that relies on this cookie."
                ),
                "recommendation": "Set `SameSite=Lax` (or `Strict` for session cookies used only for "
                                   "same-site navigation) plus `Secure` on all auth/session cookies.",
                "evidence": build_evidence(f"GET {base_url}", resp, note=f"Set-Cookie seen for '{c.name}' without SameSite."),
            })
    return findings


def run(session, target_report: dict, aggressive: bool = False) -> list:
    crawl = target_report.get("crawl", {})
    base_url = target_report.get("base_url")
    findings = []
    findings.extend(_check_state_changing_forms(crawl))
    findings.extend(_check_cookie_samesite(session, base_url))
    return findings
