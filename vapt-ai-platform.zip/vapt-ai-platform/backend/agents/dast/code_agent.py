"""
Module 2 — Source Code Agent

When a project folder is uploaded instead of (or alongside) a live target
URL, this agent scans the real uploaded source files for the same 8
vulnerability categories the live agents test for, and points to the exact
file + line, with a short suggested-fix code snippet (guidance only — never
auto-applied to the user's files, and never AI-generated — every suggestion
below is a static, deterministic template picked by rule id).

Two detection strategies are combined here, matching how a human reviewer
actually works:

  1. Data-flow / taint tracking (taint_scanner.py) for XSS, SQL Injection,
     Path Traversal, and SSRF — bugs that are only real if a value that
     originated from user input reaches a dangerous sink unsanitized. A
     flat single-line regex can't tell a real bug from a hardcoded safe
     string; the taint scanner traces the variable across lines the way a
     reviewer would, and reports the trace (source line -> sink line) as
     evidence.

  2. Structural / presence-absence checks (this file) for CSRF, IDOR,
     Auth & Authorization, SSRF file-upload, and Security Misconfiguration
     — bugs that are about something *missing* (a token, a check, a
     hardening flag) rather than a value flowing somewhere, so a single
     line genuinely is the whole story for these.

Language-agnostic, pattern-based (grep-with-context, in the spirit of
Semgrep/Bandit's simpler rules) covering common idioms across Python,
JavaScript/TypeScript/Node, PHP, Java, and Ruby. Like any pattern-based
scanner it will have false positives/negatives — it's a strong triage aid
pointing you at exactly where to look, not a certified guarantee.
"""
from __future__ import annotations

import os
import re

from . import taint_scanner

MAX_FILE_BYTES = 1_500_000
SKIP_DIRS = {".git", "node_modules", "venv", ".venv", "__pycache__", "dist", "build", ".next", "vendor"}
CODE_EXTENSIONS = {".py", ".js", ".ts", ".jsx", ".tsx", ".php", ".java", ".rb", ".go", ".html"}

TAINT_TRACKED_AGENTS = {"xss", "sqli", "path_traversal", "ssrf_upload"}

# Structural / presence-absence rules only — see module docstring for why
# XSS/SQLi/Path Traversal/outbound-SSRF are handled by taint_scanner.py
# instead of a flat regex here.
CODE_RULES = [
    # ===================== CSRF =====================
    dict(id="CODE-CSRF-001", agent="csrf", cwe="CWE-352", severity="high",
         title="CSRF protection explicitly disabled",
         pattern=r'(?i)(csrf_exempt|WTF_CSRF_ENABLED\s*=\s*False|CSRF_ENABLED\s*=\s*False|csurf\s*:\s*false)',
         recommendation="Remove the CSRF exemption; every state-changing endpoint should require a valid CSRF token.",
         suggestion="# remove @csrf_exempt; ensure the form includes {{ form.csrf_token }} / a hidden csrf_token field"),
    dict(id="CODE-CSRF-002", agent="csrf", cwe="CWE-352", severity="medium",
         title="Cookie set without SameSite attribute",
         pattern=r'(?i)set_cookie\s*\([^)]*\)(?!.*samesite)',
         recommendation="Set SameSite=Lax/Strict (and Secure) on session/auth cookies as a CSRF backstop.",
         suggestion="resp.set_cookie('session', value, httponly=True, secure=True, samesite='Lax')"),

    # ===================== IDOR =====================
    dict(id="CODE-IDOR-001", agent="idor", cwe="CWE-639", severity="high",
         title="Object fetched by request-supplied ID with no visible ownership filter",
         pattern=r'(?i)\.objects\.get\s*\(\s*(pk|id)\s*=\s*request\.(GET|POST|args)',
         recommendation="Filter by the authenticated user/owner in the same query, not just by the object's primary key.",
         suggestion="Invoice.objects.get(id=invoice_id, owner=request.user)  # not .get(id=invoice_id) alone"),
    dict(id="CODE-IDOR-002", agent="idor", cwe="CWE-639", severity="high",
         title="Express handler fetches a record by req.params id with no ownership check",
         pattern=r'(?i)find(One|ById)\s*\(\s*req\.params\.',
         recommendation="After fetching, verify the record belongs to the authenticated user before returning it.",
         suggestion="if (record.userId !== req.user.id) return res.status(403).json({error: 'forbidden'});"),
    dict(id="CODE-IDOR-003", agent="idor", cwe="CWE-639", severity="medium",
         title="Route path parameter used directly as a database lookup key",
         pattern=r'(?i)(findById|getById|find_by_id)\s*\(\s*(request\.|req\.)(args|params)',
         recommendation="Re-check authorization for the specific object on every fetch, not just that the caller is logged in.",
         suggestion="record = get_object_or_404(Model, id=object_id, owner=current_user)"),

    # ===================== Auth & Authorization =====================
    dict(id="CODE-AUTH-001", agent="auth", cwe="CWE-347", severity="critical",
         title="JWT verification disabled or alg=none accepted",
         pattern=r'(?i)(verify_signature[\'"]?\s*:\s*False|algorithms\s*=\s*\[\s*[\'"]none[\'"]|verify\s*=\s*False)',
         recommendation="Always verify JWT signatures and explicitly allow-list strong algorithms; reject 'none'.",
         suggestion="jwt.decode(token, SECRET_KEY, algorithms=['HS256'])  # never algorithms=['none']"),
    dict(id="CODE-AUTH-002", agent="auth", cwe="CWE-798", severity="critical",
         title="Hardcoded default admin credential check",
         pattern=r'(?i)(username|user)\s*==\s*[\'"]admin[\'"].{0,40}(password|pass)\s*==\s*[\'"]',
         recommendation="Remove hardcoded credential checks; validate against a hashed credential store.",
         suggestion="if bcrypt.checkpw(password.encode(), user.password_hash): ...  # not a hardcoded literal"),
    dict(id="CODE-AUTH-003", agent="auth", cwe="CWE-208", severity="medium",
         title="Password compared with a non-constant-time operator",
         pattern=r'(?i)password\s*==\s*(request\.|input_password|user_input|req\.)',
         recommendation="Use a constant-time comparison for secrets to avoid timing side-channels.",
         suggestion="hmac.compare_digest(stored_hash, computed_hash)  # or bcrypt.checkpw(), not == "),
    dict(id="CODE-AUTH-004", agent="auth", cwe="CWE-614", severity="medium",
         title="Session cookie hardening explicitly disabled",
         pattern=r'(?i)(SESSION_COOKIE_SECURE\s*=\s*False|httponly\s*=\s*False|secure\s*:\s*false)',
         recommendation="Set Secure, HttpOnly, and SameSite on every session/auth cookie.",
         suggestion="app.config.update(SESSION_COOKIE_SECURE=True, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax')"),

    # ===================== SSRF & File Upload (structural — not a data-flow sink) =====================
    dict(id="CODE-UPLOAD-001", agent="ssrf_upload", cwe="CWE-434", severity="high",
         title="Uploaded file saved using the client-supplied filename directly",
         pattern=r'(?i)\.save\s*\(\s*(os\.path\.join\([^)]*\.filename|file\.filename)\)',
         recommendation="Sanitize the filename and validate extension/content type before saving; store outside the webroot.",
         suggestion="filename = secure_filename(file.filename); "
                    "if not filename.lower().endswith(ALLOWED_EXTS): abort(400)\nfile.save(os.path.join(UPLOAD_DIR, filename))"),

    # ===================== Security Misconfiguration =====================
    dict(id="CODE-MISCONFIG-001", agent="misconfig", cwe="CWE-16", severity="medium",
         title="Debug mode enabled in framework config",
         pattern=r'(?i)(DEBUG\s*=\s*True|app\.run\([^)]*debug\s*=\s*True)',
         recommendation="Disable debug mode in production — it can leak stack traces, source code, and secrets.",
         suggestion="app.run(debug=False)  # or DEBUG = False in settings for production"),
    dict(id="CODE-MISCONFIG-002", agent="misconfig", cwe="CWE-942", severity="medium",
         title="Overly permissive CORS policy (wildcard origin)",
         pattern=r'(?i)(Access-Control-Allow-Origin[\'"]?\s*[:=]\s*[\'"]\*|allow_origins\s*=\s*\[\s*[\'"]\*[\'"])',
         recommendation="Restrict CORS to an explicit allow-list of trusted origins, especially if credentials are allowed.",
         suggestion="allow_origins=['https://app.example.com']  # not ['*'], especially with allow_credentials=True"),
    dict(id="CODE-MISCONFIG-003", agent="misconfig", cwe="CWE-295", severity="high",
         title="TLS certificate verification disabled",
         pattern=r'(?i)(verify\s*=\s*False|rejectUnauthorized\s*:\s*false|NODE_TLS_REJECT_UNAUTHORIZED\s*=\s*[\'"]?0)',
         recommendation="Never disable TLS verification; fix the underlying certificate/trust-chain issue instead.",
         suggestion="requests.get(url, verify=True)  # fix the cert instead of verify=False"),
    dict(id="CODE-MISCONFIG-004", agent="misconfig", cwe="CWE-798", severity="critical",
         title="Hardcoded credential / API key in source",
         pattern=r'(?i)(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*[\'"][A-Za-z0-9_\-\/+]{8,}[\'"]',
         recommendation="Move secrets to environment variables or a secrets manager; never commit credentials to source.",
         suggestion="api_key = os.environ['API_KEY']  # not api_key = 'sk-...'"),
]

_COMPILED = [{**r, "regex": re.compile(r["pattern"])} for r in CODE_RULES]

AGENT_LABELS = {
    "xss": "Cross-Site Scripting (XSS)",
    "sqli": "SQL Injection",
    "csrf": "CSRF",
    "idor": "IDOR",
    "path_traversal": "Path Traversal / LFI",
    "auth": "Authentication & Authorization",
    "ssrf_upload": "SSRF & File Upload",
    "misconfig": "Security Misconfiguration",
}


def _walk_files(root_dir: str) -> list:
    files = []
    for dirpath, dirnames, filenames in os.walk(root_dir):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fname in filenames:
            ext = os.path.splitext(fname)[1].lower()
            if ext not in CODE_EXTENSIONS:
                continue
            fpath = os.path.join(dirpath, fname)
            try:
                if os.path.getsize(fpath) > MAX_FILE_BYTES:
                    continue
            except OSError:
                continue
            files.append((fpath, os.path.relpath(fpath, root_dir)))
    return files


def _scan_text_structural(rules, text: str, rel_path: str) -> list:
    findings = []
    lines = text.splitlines()
    for rule in rules:
        for match in rule["regex"].finditer(text):
            line_no = text.count("\n", 0, match.start()) + 1
            snippet = lines[line_no - 1].strip() if 0 < line_no <= len(lines) else match.group(0)
            findings.append({
                "rule_id": rule["id"],
                "agent": rule["agent"],
                "agent_label": AGENT_LABELS[rule["agent"]],
                "cwe": rule["cwe"],
                "title": rule["title"],
                "severity": rule["severity"],
                "description": f'Source code pattern matched for {rule["title"]} ({rule["cwe"]}) at {rel_path}:{line_no}.',
                "recommendation": rule["recommendation"],
                "file_path": rel_path,
                "line": line_no,
                "param": None,
                "method": None,
                "url": None,
                "evidence": {"code_snippet": snippet[:300]},
                "suggested_fix": rule["suggestion"],
                "finding_type": "source_code",
            })
    return findings


def scan_directory(root_dir: str, agent_keys=None) -> list:
    """Scan every real source file under root_dir for all 8 categories
    (or just the ones in agent_keys, if provided). Returns Module-2-shaped
    findings with a real file_path/line, a human-readable taint trace where
    applicable, and a short suggested-fix snippet.
    """
    wanted = set(agent_keys) if agent_keys else set(AGENT_LABELS.keys())
    structural_rules = [r for r in _COMPILED if r["agent"] in wanted]
    taint_agent_keys = wanted & TAINT_TRACKED_AGENTS

    all_findings = []
    for fpath, rel_path in _walk_files(root_dir):
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as fh:
                text = fh.read()
        except OSError:
            continue
        if structural_rules:
            all_findings.extend(_scan_text_structural(structural_rules, text, rel_path))
        if taint_agent_keys:
            all_findings.extend(taint_scanner.scan_file(text, rel_path, agent_keys=taint_agent_keys))
    return all_findings


def scan_category(agent_key: str, root_dir: str) -> list:
    """Convenience wrapper the orchestrator calls once per selected agent
    so it can emit a per-category progress event, same as the live agents."""
    return scan_directory(root_dir, agent_keys={agent_key})
