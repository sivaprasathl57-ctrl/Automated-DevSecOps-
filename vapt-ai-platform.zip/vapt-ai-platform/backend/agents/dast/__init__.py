"""
Module 2 — Active Vulnerability Agents (DAST)

Real, live, black-box testing agents that send actual HTTP requests with
crafted payloads at an authorized target and inspect the real responses for
vulnerability signatures. This is not a simulation/demo — every finding is
backed by a real request/response pair captured from the target, which is
surfaced to the report so a human can reproduce and verify it.

Agents:
  xss_agent              -> Cross-Site Scripting (reflected, DOM-hint, attribute/event, polyglot)
  sqli_agent              -> SQL Injection (error-based, boolean-blind, time-blind, union hints)
  csrf_agent               -> Cross-Site Request Forgery (missing tokens, cookie SameSite)
  idor_agent               -> Insecure Direct Object Reference (object id tampering)
  path_traversal_agent     -> Path Traversal / LFI (../../etc/passwd style payloads)
  auth_agent               -> Authentication & Authorization weaknesses
  ssrf_upload_agent        -> Server-Side Request Forgery + unrestricted file upload
  misconfig_agent          -> Security Misconfiguration (headers, exposed files, CORS, methods)

AUTHORIZATION GATE: exactly like Module 1, the API layer must confirm the
caller attested ownership/authorization for the target before this package
is ever invoked — these agents perform *active* requests, not passive
observation.
"""
