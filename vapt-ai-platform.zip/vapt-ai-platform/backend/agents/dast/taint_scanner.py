"""
Module 2 — Taint-Tracking Engine

Real single-line regex matching (what code_agent.py did originally) flags a
line like `cursor.execute(f"...{name}...")` without ever checking where
`name` came from — it could be a hardcoded constant. A human reviewer
doesn't work that way: they trace the value back to where it entered the
function ("this came from request.args three lines up") and follow it
forward to see whether it reaches something dangerous before it's ever
sanitized.

This module does that, in a bounded, practical way:

  1. Walk the file top-to-bottom, one function/handler at a time (taint
     resets at each new function boundary — matching how request handlers
     are actually scoped in real Flask/Express/etc. code).
  2. SOURCES  — lines that assign a variable from user-controlled input
     (request.args, req.body, $_GET, input(), ...) mark that variable name
     as tainted, remembering *where* it was tainted.
  3. SANITIZERS — lines that reassign a tainted variable through a known
     safe function (escape(), secure_filename(), int(), ...) clear the
     taint — the same way a human reviewer would say "oh, that's handled."
  4. SINKS — dangerous calls (SQL execute, HTML f-string, file open,
     outbound HTTP request, ...) are only reported if a currently-tainted
     variable (or an inline source expression) actually appears in them.

This cuts false positives (a sink using a safe, non-tainted value is not
flagged) and gives a real explanation with both line numbers, like a code
review comment: "tainted at line 12, reaches this sink at line 15."
"""
from __future__ import annotations

import re

FUNC_BOUNDARY_RE = re.compile(
    r'^\s*('
    r'def\s+\w+\s*\('
    r'|function\s+\w+\s*\('
    r'|(async\s+)?function\s*\('
    r'|const\s+\w+\s*=\s*(async\s*)?\([^)]*\)\s*=>'
    r'|(public|private|protected)\s+\w+.*\('
    r'|func\s+\w+\s*\('
    r'|class\s+\w+'
    r')'
)

SOURCE_ASSIGN_RE = re.compile(
    r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*(?::\s*\w+)?\s*=\s*.*?'
    r'(request\.(args|form|json|values|GET|POST|FILES|COOKIES)'
    r'|req\.(query|body|params|cookies|headers)'
    r'|\$_(GET|POST|REQUEST|COOKIE)\['
    r'|input\s*\('
    r')'
)

INLINE_SOURCE_RE = re.compile(
    r'(request\.(args|form|json|values|GET|POST|FILES|COOKIES)'
    r'|req\.(query|body|params|cookies|headers)'
    r'|\$_(GET|POST|REQUEST|COOKIE)\[)'
)

SANITIZE_ASSIGN_RE = re.compile(
    r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*.*?'
    r'(\bescape\s*\(|html\.escape\s*\(|bleach\.clean\s*\(|markupsafe\.escape\s*\('
    r'|secure_filename\s*\(|htmlspecialchars\s*\(|DOMPurify\.sanitize\s*\('
    r'|os\.path\.basename\s*\(|int\s*\(|float\s*\(|parseInt\s*\('
    r'|re\.(match|fullmatch)\s*\('
    r')'
)

GENERIC_ASSIGN_RE = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)$')

PLACEHOLDER_VAR_RE = re.compile(r'\{([A-Za-z_][A-Za-z0-9_]*)')

# ---- Sinks, grouped by the same 4 agent keys the live agents use for these
# data-flow-style categories (csrf/idor/auth/misconfig stay purely
# structural/contextual checks in code_agent.py — taint doesn't apply there
# the same way). ----
SINKS = {
    "xss": [
        (r'\.innerHTML\s*=\s*(?P<expr>[^;]+)', "innerHTML assigned from tainted data"),
        (r'document\.write\s*\(\s*(?P<expr>[^)]+)\)', "document.write() called with tainted data"),
        (r'f[\'"]<[a-z]+[^>]*>.*?(?P<expr>\{[^}]+\}.*)', "Raw HTML f-string response built from tainted data"),
        (r'dangerouslySetInnerHTML\s*=\s*\{\{\s*__html:\s*(?P<expr>[^}]+)\}\}', "dangerouslySetInnerHTML rendered from tainted data"),
        (r'(?:echo|print)\s+(?P<expr>\$[A-Za-z_][A-Za-z0-9_]*)\s*;', "Output of a tainted variable with no escaping"),
    ],
    "sqli": [
        (r'(?:execute|cursor\.execute)\s*\(\s*f[\'"](?P<expr>[^)]*(?:SELECT|INSERT|UPDATE|DELETE)[^)]*)\)',
         "SQL query built from an f-string with tainted data"),
        (r'(?:execute|cursor\.execute|\.query)\s*\(\s*[\'"][^)]*(?:SELECT|INSERT|UPDATE|DELETE)[^)]*[\'"]\s*\+\s*(?P<expr>[A-Za-z_][A-Za-z0-9_.\[\]]*)',
         "SQL query built via string concatenation with tainted data"),
        (r'\.query\s*\(\s*`(?P<expr>[^)]*(?:SELECT|INSERT|UPDATE|DELETE)[^)]*)\)',
         "SQL query (template literal) built from tainted data"),
        (r'(?:mysqli_query|->query)\s*\([^)]*\.\s*(?P<expr>\$[A-Za-z_][A-Za-z0-9_]*)',
         "SQL query built via string concatenation with tainted data"),
        (r'\.raw\s*\(\s*f[\'"](?P<expr>[^)]+)\)',
         "ORM raw query built from an f-string with tainted data"),
    ],
    "path_traversal": [
        (r'\bopen\s*\(\s*(?P<expr>[^)]+)\)', "File opened using a tainted path"),
        (r'fs\.(?:readFile|readFileSync|createReadStream)\s*\(\s*(?P<expr>[^)]+)\)', "File read using a tainted path"),
        (r'(?:include|require)(?:_once)?\s*\(\s*(?P<expr>[^)]+)\)', "File included using a tainted path"),
        (r'send_file\s*\(\s*(?P<expr>[^)]+)\)', "File served using a tainted path"),
    ],
    "ssrf_upload": [
        (r'requests\.(?:get|post|put|head)\s*\(\s*(?P<expr>[^)]+)\)', "Outbound HTTP request built from tainted data"),
        (r'urllib\.request\.urlopen\s*\(\s*(?P<expr>[^)]+)\)', "Outbound HTTP request built from tainted data"),
        (r'axios\.(?:get|post)\s*\(\s*(?P<expr>[^)]+)\)', "Outbound HTTP request built from tainted data"),
        (r'\bfetch\s*\(\s*(?P<expr>[^)]+)\)', "Outbound HTTP request built from tainted data"),
    ],
}

SINK_META = {
    "xss": dict(cwe="CWE-79", severity="high",
                recommendation="Never write tainted data into HTML/DOM sinks without context-aware escaping.",
                suggestion="el.textContent = userInput;  // or DOMPurify.sanitize(html) / template auto-escaping"),
    "sqli": dict(cwe="CWE-89", severity="critical",
                 recommendation="Use parameterized queries / prepared statements — never interpolate tainted values into SQL text.",
                 suggestion='cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))  # not f"...{user_id}"'),
    "path_traversal": dict(cwe="CWE-22", severity="high",
                            recommendation="Never build a filesystem path from tainted input; resolve against a fixed base dir and verify containment.",
                            suggestion="safe = os.path.basename(filename); full = os.path.join(SAFE_DIR, safe); "
                                       "assert os.path.realpath(full).startswith(os.path.realpath(SAFE_DIR))"),
    "ssrf_upload": dict(cwe="CWE-918", severity="high",
                         recommendation="Validate/allow-list the destination host before making any outbound request with tainted input.",
                         suggestion="parsed = urlparse(url); assert parsed.hostname in ALLOWED_HOSTS"),
}

AGENT_LABELS = {
    "xss": "Cross-Site Scripting (XSS)",
    "sqli": "SQL Injection",
    "path_traversal": "Path Traversal / LFI",
    "ssrf_upload": "SSRF & File Upload",
}

_COMPILED_SINKS = {
    agent: [(re.compile(pat), label) for pat, label in patterns]
    for agent, patterns in SINKS.items()
}


def _base_var_names(expr: str) -> set:
    """Pull plausible variable identifiers out of a sink expression so they
    can be checked against the current taint set (handles `foo`, `foo.bar`,
    `foo[0]`, and `{foo}` placeholders inside f-strings/template literals)."""
    names = set(re.findall(r'[A-Za-z_][A-Za-z0-9_]*', expr))
    return names


def scan_file(text: str, rel_path: str, agent_keys=None) -> list:
    """Line-by-line, taint-aware scan of a single file's real source text.
    Returns Module-2-shaped findings, each carrying a human-readable taint
    trace (where the value entered, where it reached a dangerous sink)."""
    wanted = set(agent_keys) if agent_keys else set(SINKS.keys())
    active_sinks = {k: v for k, v in _COMPILED_SINKS.items() if k in wanted}
    if not active_sinks:
        return []

    lines = text.splitlines()
    taint = {}  # var_name -> {"line": n, "text": snippet}
    findings = []

    for i, line in enumerate(lines, start=1):
        if FUNC_BOUNDARY_RE.match(line):
            taint = {}
            continue

        sanitize_m = SANITIZE_ASSIGN_RE.match(line)
        source_m = SOURCE_ASSIGN_RE.match(line) if not sanitize_m else None

        if sanitize_m:
            taint.pop(sanitize_m.group(1), None)
        elif source_m:
            var = source_m.group(1)
            taint[var] = {"line": i, "text": line.strip(), "chain": [var]}
        else:
            # Not a direct source/sanitizer call — but does this assignment
            # build a new variable out of one that's already tainted? (e.g.
            # `path = SAFE_DIR + "/" + filename` where `filename` is tainted.)
            # A real reviewer keeps following the value through variables
            # like this, not just at the exact line it first appeared.
            generic_m = GENERIC_ASSIGN_RE.match(line)
            if generic_m:
                lhs, rhs = generic_m.group(1), generic_m.group(2)
                rhs_vars = set(re.findall(r'[A-Za-z_][A-Za-z0-9_]*', rhs)) & set(taint.keys())
                rhs_vars.discard(lhs)
                if rhs_vars:
                    origin_var = sorted(rhs_vars)[0]
                    origin = taint[origin_var]
                    taint[lhs] = {**origin, "chain": origin["chain"] + [lhs]}

        for agent_key, sink_patterns in active_sinks.items():
            for regex, sink_label in sink_patterns:
                sm = regex.search(line)
                if not sm:
                    continue
                expr = sm.groupdict().get("expr", line)
                candidate_vars = _base_var_names(expr) & set(taint.keys())
                inline_source = bool(INLINE_SOURCE_RE.search(expr))

                if not candidate_vars and not inline_source:
                    continue  # sink present, but nothing tainted reaches it — a human reviewer would move on

                meta = SINK_META[agent_key]
                if candidate_vars:
                    var = sorted(candidate_vars)[0]
                    origin = taint[var]
                    chain = origin.get("chain", [var])
                    if len(chain) > 1:
                        trace = (f"Variable '{chain[0]}' is assigned from user-controlled input at line "
                                  f"{origin['line']} (`{origin['text']}`), then flows through "
                                  f"{' -> '.join(chain[1:])} and reaches this sink at line {i} with no "
                                  f"sanitization observed along the way.")
                    else:
                        trace = (f"Variable '{var}' is assigned from user-controlled input at line {origin['line']} "
                                 f"(`{origin['text']}`), then flows into this sink at line {i} with no sanitization "
                                 f"observed in between.")
                else:
                    trace = f"User-controlled input is referenced directly inside this sink at line {i}."

                findings.append({
                    "rule_id": f"TAINT-{agent_key.upper()}",
                    "agent": agent_key,
                    "agent_label": AGENT_LABELS[agent_key],
                    "cwe": meta["cwe"],
                    "title": sink_label,
                    "severity": meta["severity"],
                    "description": f"{sink_label} at {rel_path}:{i}. {trace}",
                    "recommendation": meta["recommendation"],
                    "file_path": rel_path,
                    "line": i,
                    "param": None,
                    "method": None,
                    "url": None,
                    "evidence": {"code_snippet": line.strip()[:300], "taint_trace": trace},
                    "suggested_fix": meta["suggestion"],
                    "finding_type": "source_code",
                })
                break  # one finding per sink match per line is enough signal

    return findings
