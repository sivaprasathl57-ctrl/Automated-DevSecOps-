"""
Module 2 — Security Misconfiguration Agent

Real, read-only checks against the live target:
  1. Missing/weak security response headers.
  2. Exposed sensitive files (.env, .git/config, backups, etc.) — GET
     requests only, to files a site owner would never intend to publish.
  3. Directory listing enabled on common directories.
  4. Verbose server/framework version banners.
  5. CORS misconfiguration (wildcard origin combined with credentials).
  6. Dangerous HTTP methods enabled (TRACE / PUT / arbitrary method echo).
"""
from __future__ import annotations

import re

from .http_client import request, build_evidence

SECURITY_HEADERS = {
    "content-security-policy": ("high", "No Content-Security-Policy set — reduces defense-in-depth against XSS/data-injection."),
    "x-frame-options": ("medium", "No X-Frame-Options/frame-ancestors — page can be framed for clickjacking."),
    "strict-transport-security": ("medium", "No HSTS header — browsers may be downgraded to plain HTTP by a network attacker."),
    "x-content-type-options": ("low", "No X-Content-Type-Options: nosniff — browsers may MIME-sniff responses."),
    "referrer-policy": ("low", "No Referrer-Policy — full URLs (possibly with tokens) may leak via the Referer header."),
}

SENSITIVE_FILES = [
    "/.env", "/.git/config", "/.git/HEAD", "/.git/index",
    "/backup.zip", "/backup.sql", "/db.sql", "/dump.sql",
    "/config.php.bak", "/web.config.bak", "/.DS_Store",
    "/wp-config.php.bak", "/composer.lock", "/package-lock.json",
]

DIRECTORY_LISTING_DIRS = ["/uploads/", "/images/", "/files/", "/backup/", "/assets/", "/static/"]

DIR_LISTING_MARKERS = ("Index of /", "<title>Index of", "Directory listing for")


def _check_headers(base_url, headers):
    findings = []
    header_keys = {k.lower() for k in headers.keys()}
    for h, (severity, desc) in SECURITY_HEADERS.items():
        if h not in header_keys:
            findings.append({
                "rule_id": f"MISCONFIG-HEADER-{h.upper()}",
                "title": f"Missing security header: {h}",
                "cwe": "CWE-693",
                "severity": severity,
                "param": None,
                "method": "GET",
                "url": base_url,
                "description": desc + f" (checked live response headers from {base_url}.)",
                "recommendation": f"Set the `{h}` response header with an appropriate restrictive policy on every response.",
                "evidence": {"request": f"GET {base_url}", "response_headers_seen": sorted(header_keys)},
            })
    return findings


def _check_sensitive_files(session, base_url):
    findings = []
    for path in SENSITIVE_FILES:
        url = base_url.rstrip("/") + path
        resp = request(session, "GET", url)
        if not resp.get("ok"):
            continue
        if resp["status_code"] == 200 and len(resp.get("body", "")) > 0:
            findings.append({
                "rule_id": "MISCONFIG-SENSITIVE-FILE-EXPOSED",
                "title": f"Sensitive file publicly accessible: {path}",
                "cwe": "CWE-538",
                "severity": "critical" if path in ("/.env", "/.git/config") else "high",
                "param": None,
                "method": "GET",
                "url": url,
                "description": f"{url} is served with HTTP 200, exposing what should be a private/internal file.",
                "recommendation": "Remove the file from the webroot or add a server rule denying access "
                                   "to dotfiles, backups, and version-control directories.",
                "evidence": build_evidence(f"GET {url}", resp),
            })
    return findings


def _check_directory_listing(session, base_url):
    findings = []
    for path in DIRECTORY_LISTING_DIRS:
        url = base_url.rstrip("/") + path
        resp = request(session, "GET", url)
        if not resp.get("ok"):
            continue
        body = resp.get("body", "")
        if resp["status_code"] == 200 and any(m in body for m in DIR_LISTING_MARKERS):
            findings.append({
                "rule_id": "MISCONFIG-DIRECTORY-LISTING",
                "title": f"Directory listing enabled: {path}",
                "cwe": "CWE-548",
                "severity": "medium",
                "param": None,
                "method": "GET",
                "url": url,
                "description": f"{url} returns an auto-generated directory index, exposing the full file listing.",
                "recommendation": "Disable directory indexing on the web server / hosting platform for all directories.",
                "evidence": build_evidence(f"GET {url}", resp),
            })
    return findings


def _check_verbose_banner(headers):
    findings = []
    for h in ("Server", "X-Powered-By"):
        val = headers.get(h)
        if val and re.search(r"\d+\.\d+", val):
            findings.append({
                "rule_id": "MISCONFIG-VERSION-DISCLOSURE",
                "title": f"Verbose version banner in {h} header",
                "cwe": "CWE-200",
                "severity": "low",
                "param": None,
                "method": "GET",
                "url": None,
                "description": f"The `{h}: {val}` response header discloses a specific software version, "
                                "which an attacker can match against known CVEs.",
                "recommendation": f"Suppress or generalize the `{h}` header at the server/proxy level.",
                "evidence": {"request": "GET /", "header_seen": f"{h}: {val}"},
            })
    return findings


def _check_cors(session, base_url):
    findings = []
    resp = request(session, "GET", base_url, headers={"Origin": "https://attacker-controlled.example"})
    if not resp.get("ok"):
        return findings
    headers = {k.lower(): v for k, v in resp["headers"].items()}
    acao = headers.get("access-control-allow-origin")
    acac = headers.get("access-control-allow-credentials", "").lower()
    if acao == "*" and acac == "true":
        findings.append({
            "rule_id": "MISCONFIG-CORS-WILDCARD-CREDENTIALS",
            "title": "CORS misconfiguration: wildcard origin with credentials allowed",
            "cwe": "CWE-942",
            "severity": "critical",
            "param": None,
            "method": "GET",
            "url": base_url,
            "description": (
                "The server reflects Access-Control-Allow-Origin: * together with "
                "Access-Control-Allow-Credentials: true. Combined, any website can read "
                "authenticated, credentialed responses from this API on behalf of a logged-in victim."
            ),
            "recommendation": "Never combine a wildcard origin with credentialed CORS. Echo back a "
                               "specific allow-listed origin only, and only when credentials are required.",
            "evidence": build_evidence(f"GET {base_url} (Origin: https://attacker-controlled.example)", resp),
        })
    elif acao and acao != "*" and "attacker-controlled.example" in acao:
        findings.append({
            "rule_id": "MISCONFIG-CORS-REFLECTS-ARBITRARY-ORIGIN",
            "title": "CORS reflects arbitrary Origin header",
            "cwe": "CWE-942",
            "severity": "high",
            "param": None,
            "method": "GET",
            "url": base_url,
            "description": (
                "The server echoes back whatever Origin header is sent (including a clearly "
                "arbitrary test origin) in Access-Control-Allow-Origin, effectively allow-listing "
                "every origin on the internet."
            ),
            "recommendation": "Validate the Origin header against a fixed allow-list server-side instead of reflecting it.",
            "evidence": build_evidence(f"GET {base_url} (Origin: https://attacker-controlled.example)", resp),
        })
    return findings


def _check_dangerous_methods(session, base_url):
    findings = []
    resp = request(session, "TRACE", base_url)
    if resp.get("ok") and resp["status_code"] < 400:
        findings.append({
            "rule_id": "MISCONFIG-TRACE-METHOD-ENABLED",
            "title": "HTTP TRACE method enabled",
            "cwe": "CWE-16",
            "severity": "low",
            "param": None,
            "method": "TRACE",
            "url": base_url,
            "description": f"{base_url} responds to the TRACE method (HTTP {resp['status_code']}), which can "
                            "be used in Cross-Site Tracing (XST) attacks to help bypass HttpOnly cookie protections.",
            "recommendation": "Disable the TRACE (and TRACK) HTTP method at the web server/load balancer level.",
            "evidence": build_evidence(f"TRACE {base_url}", resp),
        })
    return findings


def run(session, target_report: dict, aggressive: bool = False) -> list:
    base_url = target_report.get("base_url")
    findings = []
    home = request(session, "GET", base_url)
    if home.get("ok"):
        findings.extend(_check_headers(base_url, home["headers"]))
        findings.extend(_check_verbose_banner(home["headers"]))
    findings.extend(_check_sensitive_files(session, base_url))
    findings.extend(_check_directory_listing(session, base_url))
    findings.extend(_check_cors(session, base_url))
    findings.extend(_check_dangerous_methods(session, base_url))
    return findings
