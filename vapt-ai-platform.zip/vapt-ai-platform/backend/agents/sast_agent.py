"""
Agent 3 — Static Analysis (SAST) Agent
Runs the rule set from rules/sast_rules.py against every ingested source file
and returns a list of Finding-shaped dicts. Also used stand-alone by the
Verification Agent to re-check a single patched file.
"""
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rules.sast_rules import get_rules  # noqa: E402

RULES = get_rules()
MAX_FILE_BYTES = 1_500_000  # skip huge/binary-ish files


def scan_text(text: str, file_path: str = None) -> list:
    """Run all rules against a single blob of source text, return raw findings."""
    findings = []
    lines = text.splitlines()
    for rule in RULES:
        for match in rule["regex"].finditer(text):
            # figure out line number from character offset
            line_no = text.count("\n", 0, match.start()) + 1
            snippet = lines[line_no - 1].strip() if 0 < line_no <= len(lines) else match.group(0)
            findings.append({
                "source_agent": "sast",
                "file_path": file_path,
                "line": line_no,
                "rule_id": rule["id"],
                "cwe": rule["cwe"],
                "title": rule["title"],
                "description": f'Pattern matched for {rule["title"]} ({rule["cwe"]}).',
                "severity": rule["severity"],
                "evidence": snippet[:300],
                "recommendation": rule["recommendation"],
            })
    return findings


def scan_directory(root_dir: str, file_inventory: list) -> list:
    """file_inventory: list of {path, language, size} from the ingestion agent."""
    all_findings = []
    for f in file_inventory:
        full_path = os.path.join(root_dir, f["path"])
        if f["size"] > MAX_FILE_BYTES:
            continue
        try:
            with open(full_path, "r", encoding="utf-8", errors="ignore") as fh:
                text = fh.read()
        except OSError:
            continue
        all_findings.extend(scan_text(text, f["path"]))
    return all_findings
