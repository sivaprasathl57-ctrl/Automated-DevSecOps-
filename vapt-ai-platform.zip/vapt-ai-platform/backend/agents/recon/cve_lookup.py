"""
Module 1 — CVE Intelligence Agent (Agent 7)

Takes whatever software/version strings the Network Scan and Web Recon
agents already found (service banners, Server header, tech fingerprints),
extracts clean {product, version} pairs, and checks each one against the
free NVD (National Vulnerability Database) CVE API — the same authoritative,
government-run database every commercial scanner (Nessus, OpenVAS, etc.)
ultimately draws from. No paid key required; set NVD_API_KEY only if you
want a higher rate limit (free to request from nvd.nist.gov).
"""
import os
import re
import time
import json
import urllib.request
import urllib.error
import urllib.parse

NVD_API = "https://services.nvd.nist.gov/rest/json/cves/2.0"

# product-name -> regex that pulls a clean version out of a raw banner/header string
VERSION_PATTERNS = [
    ("Apache", r"Apache/([\d.]+)"),
    ("nginx", r"nginx/([\d.]+)"),
    ("Microsoft IIS", r"Microsoft-IIS/([\d.]+)"),
    ("OpenSSH", r"OpenSSH[_/]([\d.]+\w*)"),
    ("PHP", r"PHP/([\d.]+)"),
    ("vsftpd", r"vsftpd\s*([\d.]+)"),
    ("ProFTPD", r"ProFTPD\s*([\d.]+)"),
    ("MySQL", r"MySQL\s*([\d.]+)"),
    ("OpenSSL", r"OpenSSL/([\d.]+\w*)"),
    ("Exim", r"Exim\s*([\d.]+)"),
    ("Postfix", r"Postfix\s*([\d.]+)"),
    ("Node.js", r"Express|node(?:\.js)?[\/ ]([\d.]+)"),
    ("Tomcat", r"Apache Tomcat/([\d.]+)"),
    ("Jetty", r"Jetty\(([\d.]+)"),
    ("WordPress", r"WordPress[/ ]?([\d.]+)?"),
    ("Redis", r"Redis\s*([\d.]+)?"),
    ("MongoDB", r"MongoDB\s*([\d.]+)?"),
]

_SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "NONE": 4, "UNKNOWN": 5}


def _extract_one(text):
    if not text:
        return None
    for product, pattern in VERSION_PATTERNS:
        m = re.search(pattern, text, re.I)
        if m:
            version = m.group(1) if m.groups() and m.group(1) else None
            return {"product": product, "version": version, "raw": text.strip()[:120]}
    return None


def extract_software(report: dict) -> list:
    """Pull {product, version, source} pairs out of whatever prior agents already found."""
    found = []
    seen = set()

    def add(item, source):
        if not item:
            return
        key = (item["product"], item.get("version"))
        if key in seen:
            return
        seen.add(key)
        found.append({**item, "source": source})

    net = report.get("network_scan", {})
    for p in net.get("open_ports", []):
        add(_extract_one(p.get("version_guess")), f"port {p.get('port')} banner")
        add(_extract_one(p.get("banner")), f"port {p.get('port')} banner")

    web = report.get("web_recon", {})
    add(_extract_one(web.get("server_banner")), "HTTP Server header")
    for tech in web.get("technologies", []) or []:
        add(_extract_one(tech), "technology fingerprint")
    headers = {k.lower(): v for k, v in (web.get("headers", {}) or {}).items()}
    add(_extract_one(headers.get("x-powered-by")), "X-Powered-By header")

    return found


def _severity_from_cve_item(item):
    metrics = item.get("cve", {}).get("metrics", {})
    for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
        if metrics.get(key):
            m = metrics[key][0]
            score = m.get("cvssData", {}).get("baseScore")
            severity = m.get("cvssData", {}).get("baseSeverity") or m.get("baseSeverity")
            return score, (severity or "UNKNOWN").upper()
    return None, "UNKNOWN"


def lookup_nvd(product: str, version: str, timeout=10, results_per_product=5) -> list:
    query = f"{product} {version}" if version else product
    params = urllib.parse.urlencode({"keywordSearch": query, "resultsPerPage": results_per_product})
    url = f"{NVD_API}?{params}"
    headers = {"User-Agent": "Module1-Recon-CVE-Lookup/1.0"}
    api_key = os.environ.get("NVD_API_KEY")
    if api_key:
        headers["apiKey"] = api_key

    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
    except (urllib.error.URLError, TimeoutError, OSError, ValueError):
        return []

    cves = []
    for item in data.get("vulnerabilities", []):
        cve = item.get("cve", {})
        cve_id = cve.get("id")
        descs = cve.get("descriptions", [])
        desc_en = next((d["value"] for d in descs if d.get("lang") == "en"), (descs[0]["value"] if descs else ""))
        score, severity = _severity_from_cve_item(item)
        cves.append({
            "cve_id": cve_id,
            "description": desc_en[:300],
            "cvss_score": score,
            "severity": severity,
            "published": cve.get("published", "")[:10],
            "url": f"https://nvd.nist.gov/vuln/detail/{cve_id}",
        })
    cves.sort(key=lambda c: (_SEVERITY_ORDER.get(c["severity"], 9), -(c["cvss_score"] or 0)))
    return cves


def analyze(report: dict, max_products: int = 6) -> dict:
    software = extract_software(report)
    findings = []
    checked = 0

    for sw in software:
        if checked >= max_products:
            break
        if not sw.get("version"):
            continue  # can't meaningfully CVE-match a product with no version
        cves = lookup_nvd(sw["product"], sw["version"])
        checked += 1
        findings.append({
            "product": sw["product"], "version": sw["version"], "source": sw["source"],
            "cve_count": len(cves), "cves": cves,
        })
        time.sleep(1.6)  # stay under NVD's free-tier rate limit (5 req / 30s without a key)

    all_cves = [c for f in findings for c in f["cves"]]
    severity_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "UNKNOWN": 0}
    for c in all_cves:
        severity_counts[c["severity"] if c["severity"] in severity_counts else "UNKNOWN"] += 1

    return {
        "software_detected": software,
        "software_checked": checked,
        "findings": findings,
        "total_cves_found": len(all_cves),
        "severity_counts": severity_counts,
        "note": "Free NVD API used (no key required). Only products with a clearly parsed version "
                "number are checked; set NVD_API_KEY for a higher rate limit if scanning many hosts.",
    }
