"""
Module 1 — Endpoint Discovery Agent

Three sources, all standard/low-impact:
  1. Parse the homepage itself for <a>, <form>, and <script src> references
     (exactly what a browser's page-load does).
  2. Parse robots.txt and sitemap.xml, which site owners publish specifically
     to list their own paths.
  3. Check a short list of conventional, well-known paths (health checks,
     API docs, common admin panels) — dozens of requests, not a large-scale
     directory brute force.
"""
import re
import urllib.request
import urllib.error
from urllib.parse import urlparse, urljoin

try:
    from bs4 import BeautifulSoup
    _HAS_BS4 = True
except ImportError:
    _HAS_BS4 = False

WELL_KNOWN_PATHS = [
    "/api", "/api/v1", "/api/v2", "/swagger.json", "/swagger-ui.html",
    "/openapi.json", "/graphql", "/health", "/healthz", "/status",
    "/admin", "/login", "/wp-admin", "/wp-login.php", "/.env",
    "/.git/config", "/config.json", "/actuator/health", "/metrics",
    "/.well-known/security.txt",
]


def _fetch(url, timeout=6):
    req = urllib.request.Request(url, headers={"User-Agent": "Module1-Recon/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, resp.read(300_000)


def _crawl_homepage(base_url):
    links, forms, scripts = set(), [], set()
    try:
        status, body = _fetch(base_url)
        text = body.decode(errors="ignore")
    except (urllib.error.URLError, TimeoutError, OSError):
        return {"links": [], "forms": [], "scripts": []}

    if _HAS_BS4:
        soup = BeautifulSoup(text, "html.parser")
        for a in soup.find_all("a", href=True):
            links.add(urljoin(base_url, a["href"]))
        for s in soup.find_all("script", src=True):
            scripts.add(urljoin(base_url, s["src"]))
        for f in soup.find_all("form"):
            forms.append({
                "action": urljoin(base_url, f.get("action", "")),
                "method": (f.get("method") or "GET").upper(),
                "inputs": [i.get("name") for i in f.find_all("input") if i.get("name")],
            })
    else:
        for href in re.findall(r'href=["\']([^"\']+)["\']', text):
            links.add(urljoin(base_url, href))
        for src in re.findall(r'<script[^>]+src=["\']([^"\']+)["\']', text):
            scripts.add(urljoin(base_url, src))

    same_host = urlparse(base_url).hostname
    links = [l for l in links if urlparse(l).hostname in (same_host, None)]
    return {"links": sorted(links)[:200], "forms": forms, "scripts": sorted(scripts)[:100]}


def _parse_robots_sitemap(base_url):
    disclosed = []
    try:
        _, body = _fetch(urljoin(base_url, "/robots.txt"))
        text = body.decode(errors="ignore")
        for line in text.splitlines():
            m = re.match(r'(?i)(disallow|allow|sitemap)\s*:\s*(\S+)', line.strip())
            if m:
                disclosed.append({"source": "robots.txt", "directive": m.group(1), "path": m.group(2)})
    except (urllib.error.URLError, TimeoutError, OSError):
        pass

    try:
        _, body = _fetch(urljoin(base_url, "/sitemap.xml"))
        text = body.decode(errors="ignore")
        for loc in re.findall(r'<loc>([^<]+)</loc>', text):
            disclosed.append({"source": "sitemap.xml", "directive": "url", "path": loc})
    except (urllib.error.URLError, TimeoutError, OSError):
        pass

    return disclosed


def _check_well_known(base_url):
    found = []
    for path in WELL_KNOWN_PATHS:
        try:
            status, body = _fetch(urljoin(base_url, path), timeout=4)
            if status < 400:
                found.append({"path": path, "status": status, "size_bytes": len(body)})
        except (urllib.error.URLError, TimeoutError, OSError):
            continue
    return found


def discover(url: str) -> dict:
    parsed = urlparse(url if "://" in url else f"https://{url}")
    base_url = f"{parsed.scheme or 'https'}://{parsed.hostname}"
    crawl = _crawl_homepage(base_url)
    disclosed = _parse_robots_sitemap(base_url)
    well_known = _check_well_known(base_url)
    return {
        "base_url": base_url,
        "crawled_links": crawl["links"],
        "forms_found": crawl["forms"],
        "scripts_found": crawl["scripts"],
        "disclosed_via_robots_sitemap": disclosed,
        "well_known_paths_present": well_known,
        "total_endpoints": len(set(crawl["links"]) | {d["path"] for d in disclosed} | {w["path"] for w in well_known}),
    }
