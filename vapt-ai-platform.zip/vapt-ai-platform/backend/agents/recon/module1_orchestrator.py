"""
Module 1 Orchestrator — full top-to-bottom reconnaissance & OSINT pipeline.

Runs, in order:
  1. DNS & WHOIS Agent        -> domain info, all record types, registrar/dates
  2. Subdomain Agent          -> crt.sh + common-name DNS resolution
  3. Network Scan Agent       -> open ports, services, versions, OS guess
  4. Web Recon Agent          -> headers, cookies (session/JWT), SSL cert, WAF, tech stack
  5. Endpoint Discovery Agent -> crawled links, forms, scripts, well-known paths
  6. OSINT Agent              -> GitHub org, search dorks, email patterns, breach check

AUTHORIZATION GATE: the caller (API layer) must confirm the user attested
they own or are authorized to test the target before this is invoked —
this module intentionally does not skip that check.
"""
import asyncio
import time
from typing import AsyncGenerator
from urllib.parse import urlparse

from . import dns_whois, subdomains, network_scan, web_recon, endpoints, osint, cve_lookup


def _normalize_target(target: str):
    if "://" not in target:
        target = f"https://{target}"
    parsed = urlparse(target)
    return parsed.hostname, target


async def run_recon(job, target: str, aggressive: bool, run_osint: bool,
                     company_name: str = None) -> AsyncGenerator[dict, None]:

    def emit(agent, status, message, extra=None):
        ev = {"job_id": job["id"], "agent": agent, "status": status,
              "message": message, "timestamp": time.time()}
        job["events"].append(ev)
        return ev

    domain, base_url = _normalize_target(target)
    job["status"] = "running"
    job["report"]["target"] = {"input": target, "domain": domain, "url": base_url}

    # 1. DNS & WHOIS
    yield emit("dns_whois", "started", f"Resolving DNS records + WHOIS for {domain}...")
    await asyncio.sleep(0.05)
    try:
        job["report"]["dns_whois"] = await asyncio.to_thread(dns_whois.analyze, domain)
        yield emit("dns_whois", "completed", "DNS/WHOIS complete.")
    except Exception as e:
        job["report"]["dns_whois"] = {"error": str(e)}
        yield emit("dns_whois", "error", str(e))

    # 2. Subdomains
    yield emit("subdomains", "started", "Enumerating subdomains (crt.sh + common names)...")
    await asyncio.sleep(0.05)
    try:
        sub_result = await asyncio.to_thread(subdomains.enumerate, domain)
        job["report"]["subdomains"] = sub_result
        yield emit("subdomains", "completed", f"Found {sub_result['total_found']} subdomain(s).")
    except Exception as e:
        job["report"]["subdomains"] = {"error": str(e)}
        yield emit("subdomains", "error", str(e))

    # 3. Network scan
    ip = job["report"].get("dns_whois", {}).get("primary_ip") or domain
    yield emit("network_scan", "started",
                f"{'Aggressive' if aggressive else 'Standard'} port scan + service/OS detection on {ip}...")
    await asyncio.sleep(0.05)
    try:
        net_result = await asyncio.to_thread(network_scan.scan, ip, aggressive)
        job["report"]["network_scan"] = net_result
        yield emit("network_scan", "completed",
                    f"{len(net_result.get('open_ports', []))} open port(s) found. Engine: {net_result.get('engine')}.")
    except Exception as e:
        job["report"]["network_scan"] = {"error": str(e)}
        yield emit("network_scan", "error", str(e))

    # 4. Web recon
    yield emit("web_recon", "started", "Fetching headers, cookies, SSL cert, tech fingerprint...")
    await asyncio.sleep(0.05)
    try:
        web_result = await asyncio.to_thread(web_recon.analyze, base_url)
        job["report"]["web_recon"] = web_result
        n_cookies = len(web_result.get("cookies", []))
        yield emit("web_recon", "completed", f"Web recon complete. {n_cookies} cookie(s) analyzed.")
    except Exception as e:
        job["report"]["web_recon"] = {"error": str(e)}
        yield emit("web_recon", "error", str(e))

    # 5. Endpoint discovery
    yield emit("endpoints", "started", "Crawling homepage, robots.txt, sitemap.xml, well-known paths...")
    await asyncio.sleep(0.05)
    try:
        ep_result = await asyncio.to_thread(endpoints.discover, base_url)
        job["report"]["endpoints"] = ep_result
        yield emit("endpoints", "completed", f"{ep_result['total_endpoints']} endpoint(s) discovered.")
    except Exception as e:
        job["report"]["endpoints"] = {"error": str(e)}
        yield emit("endpoints", "error", str(e))

    # 6. OSINT (optional — off by default since it fans out to several external calls)
    if run_osint:
        yield emit("osint", "started", "Gathering company/GitHub/OSINT intel...")
        await asyncio.sleep(0.05)
        try:
            osint_result = await asyncio.to_thread(osint.gather, company_name or domain, domain)
            job["report"]["osint"] = osint_result
            yield emit("osint", "completed", "OSINT gathering complete.")
        except Exception as e:
            job["report"]["osint"] = {"error": str(e)}
            yield emit("osint", "error", str(e))

    # 7. CVE Intelligence — matches detected software versions against free NVD data
    yield emit("cve_lookup", "started", "Extracting software/versions and checking free NVD CVE database...")
    await asyncio.sleep(0.05)
    try:
        cve_result = await asyncio.to_thread(cve_lookup.analyze, job["report"])
        job["report"]["cve_lookup"] = cve_result
        yield emit("cve_lookup", "completed",
                    f"{cve_result['total_cves_found']} CVE(s) found across {cve_result['software_checked']} software version(s) checked.")
    except Exception as e:
        job["report"]["cve_lookup"] = {"error": str(e)}
        yield emit("cve_lookup", "error", str(e))

    # ---- Executive summary / risk score (computed, not a separate network call) ----
    job["report"]["executive_summary"] = _build_executive_summary(job["report"])

    job["status"] = "completed"
    yield emit("cve_lookup", "completed", "Module 1 reconnaissance pipeline finished.")


def _build_executive_summary(report: dict) -> dict:
    net = report.get("network_scan", {}) or {}
    web = report.get("web_recon", {}) or {}
    sub = report.get("subdomains", {}) or {}
    ep = report.get("endpoints", {}) or {}
    cve = report.get("cve_lookup", {}) or {}

    sev_counts = cve.get("severity_counts", {})
    open_ports = len(net.get("open_ports", []))
    jwt_or_session_cookies = sum(1 for c in web.get("cookies", []) if c.get("type") in ("JWT", "Session ID"))
    header_keys_lower = {k.lower() for k in (web.get("headers") or {}).keys()}
    missing_headers = sum(1 for k in ("content-security-policy", "strict-transport-security", "x-frame-options")
                           if k not in header_keys_lower)

    # simple, transparent 0-100 risk score — not a substitute for manual analysis
    score = 100
    score -= sev_counts.get("CRITICAL", 0) * 25
    score -= sev_counts.get("HIGH", 0) * 12
    score -= sev_counts.get("MEDIUM", 0) * 5
    score -= missing_headers * 5
    score -= (5 if web.get("waf_detected") == [] else 0)
    score = max(0, min(100, score))

    if score >= 80:
        rating = "Good"
    elif score >= 55:
        rating = "Needs Attention"
    else:
        rating = "At Risk"

    return {
        "risk_score": score,
        "risk_rating": rating,
        "open_ports": open_ports,
        "subdomains_found": sub.get("total_found", 0),
        "endpoints_found": ep.get("total_endpoints", 0),
        "cve_critical": sev_counts.get("CRITICAL", 0),
        "cve_high": sev_counts.get("HIGH", 0),
        "cve_medium": sev_counts.get("MEDIUM", 0),
        "cve_low": sev_counts.get("LOW", 0),
        "total_cves": cve.get("total_cves_found", 0),
        "session_or_jwt_cookies": jwt_or_session_cookies,
        "missing_security_headers": missing_headers,
        "waf_detected": bool(web.get("waf_detected")),
    }
