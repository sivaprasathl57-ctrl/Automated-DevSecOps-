"""
Module 1 — Network Scan Agent

Port scanning, service/version detection, OS fingerprinting, and banner
grabbing against a target you own or are authorized to test.

Two engines:
  - If `nmap` is installed on the host running this backend, it is used
    directly (`nmap -sV -O` / `-A` in aggressive mode) for accurate,
    industry-standard service/version and OS detection.
  - Otherwise, a pure-Python fallback does a TCP-connect scan + banner grab
    over a curated port list, and a TTL-based OS guess via the system ping
    command. Less accurate than nmap, but needs no extra install or
    elevated privileges, so the module always produces real output.

AUTHORIZATION: only point this at hosts you own or have written permission
to test. A TCP connect scan and version probes are active techniques —
running them against systems you don't control may be illegal in your
jurisdiction.
"""
import re
import shutil
import socket
import subprocess
import platform

COMMON_PORTS = [21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445,
                587, 993, 995, 1433, 1521, 3306, 3389, 5432, 5900, 6379,
                8000, 8080, 8443, 9200, 27017]

AGGRESSIVE_PORTS = COMMON_PORTS + [20, 69, 88, 161, 162, 389, 465, 514,
                                    636, 902, 1723, 2049, 2375, 3000, 5000,
                                    5601, 6000, 8081, 8888, 9000, 9090, 9300, 11211]

SERVICE_GUESS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 80: "HTTP",
    110: "POP3", 111: "RPCbind", 135: "MSRPC", 139: "NetBIOS", 143: "IMAP",
    443: "HTTPS", 445: "SMB", 587: "SMTP-Submission", 993: "IMAPS",
    995: "POP3S", 1433: "MSSQL", 1521: "Oracle-DB", 3306: "MySQL",
    3389: "RDP", 5432: "PostgreSQL", 5900: "VNC", 6379: "Redis",
    8000: "HTTP-Alt", 8080: "HTTP-Proxy", 8443: "HTTPS-Alt",
    9200: "Elasticsearch", 27017: "MongoDB",
}


def _grab_banner(sock) -> str:
    try:
        sock.settimeout(1.5)
        data = sock.recv(256)
        return data.decode(errors="ignore").strip()
    except Exception:
        return ""


def _probe_port(host, port, timeout=1.2):
    try:
        with socket.create_connection((host, port), timeout=timeout) as sock:
            service = SERVICE_GUESS.get(port, "unknown")
            if port in (80, 8000, 8080, 443, 8443):
                try:
                    sock.sendall(b"HEAD / HTTP/1.0\r\n\r\n")
                except OSError:
                    pass
            banner = _grab_banner(sock)
            version = None
            m = re.search(r"Server:\s*([^\r\n]+)", banner, re.I)
            if m:
                version = m.group(1)
            elif banner:
                version = banner[:80]
            return {"port": port, "state": "open", "service": service,
                    "banner": banner[:200] if banner else None, "version_guess": version}
    except (ConnectionRefusedError, socket.timeout, OSError):
        return None


def _ttl_os_guess(host) -> str:
    try:
        param = "-n" if platform.system().lower() == "windows" else "-c"
        out = subprocess.run(["ping", param, "1", host], capture_output=True,
                              text=True, timeout=5).stdout
        m = re.search(r"ttl[=:](\d+)", out, re.I)
        if not m:
            return "Unknown (no ICMP reply / ping unavailable)"
        ttl = int(m.group(1))
        if ttl <= 64:
            return f"Likely Linux/Unix (TTL={ttl}, default 64)"
        if ttl <= 128:
            return f"Likely Windows (TTL={ttl}, default 128)"
        return f"Likely network device / Solaris (TTL={ttl}, default 255)"
    except Exception:
        return "Unknown (ping unavailable in this environment)"


def _pure_python_scan(host, aggressive):
    ports = AGGRESSIVE_PORTS if aggressive else COMMON_PORTS
    open_ports = []
    for port in ports:
        result = _probe_port(host, port)
        if result:
            open_ports.append(result)
    return {
        "engine": "python-socket-fallback",
        "os_guess": _ttl_os_guess(host),
        "open_ports": open_ports,
        "ports_scanned": len(ports),
    }


def _nmap_scan(host, aggressive):
    flags = ["-sV", "-O", "-T4"] if not aggressive else ["-A", "-T4", "-p-"]
    try:
        proc = subprocess.run(["nmap"] + flags + [host], capture_output=True,
                               text=True, timeout=180)
        raw = proc.stdout
        open_ports = []
        for line in raw.splitlines():
            m = re.match(r"(\d+)/(tcp|udp)\s+open\s+(\S+)\s*(.*)", line.strip())
            if m:
                open_ports.append({
                    "port": int(m.group(1)), "protocol": m.group(2), "state": "open",
                    "service": m.group(3), "version_guess": m.group(4).strip() or None,
                })
        os_match = re.search(r"OS details:\s*(.+)", raw) or re.search(r"Aggressive OS guesses:\s*(.+)", raw)
        return {
            "engine": "nmap",
            "os_guess": os_match.group(1) if os_match else "Not determined (see raw_output)",
            "open_ports": open_ports,
            "raw_output": raw,
        }
    except Exception as e:
        return {"engine": "nmap", "error": str(e)}


def scan(host: str, aggressive: bool = False) -> dict:
    """host: IP address or hostname. Only scan authorized targets."""
    if shutil.which("nmap"):
        result = _nmap_scan(host, aggressive)
        if "error" not in result:
            return result
    return _pure_python_scan(host, aggressive)
