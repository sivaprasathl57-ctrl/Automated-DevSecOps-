"""
Module 1 — Web Recon Agent
Fetches the target's homepage once (a normal HTTP GET, exactly what a
browser does) and extracts: server banner, technology fingerprints, cookie
types (session vs JWT vs other), TLS certificate details, and WAF/CDN
detection from response signatures. Fully passive.
"""
import re
import ssl
import socket
import urllib.request
import urllib.error
from datetime import datetime, timezone
from urllib.parse import urlparse

TECH_SIGNATURES = [
    ("X-Powered-By", None, "header"),
    ("Server", None, "header"),
    (r'name=["\']generator["\']\s+content=["\']([^"\']+)', None, "meta"),
    (r'wp-content|wp-includes', "WordPress", "body"),
    (r'/sites/default/files|Drupal.settings', "Drupal", "body"),
    (r'Joomla!', "Joomla", "body"),
    (r'react(?:-dom)?[.\-]', "React", "body"),
    (r'ng-version|angular', "Angular", "body"),
    (r'__NEXT_DATA__', "Next.js", "body"),
    (r'vue(?:\.js)?', "Vue.js", "body"),
    (r'jquery(?:-[\d.]+)?\.min\.js|jquery\.js', "jQuery", "body"),
    (r'laravel_session', "Laravel (PHP)", "cookie"),
    (r'django', "Django (Python)", "cookie_or_header"),
    (r'express', "Express (Node.js)", "header"),
]

WAF_SIGNATURES = {
    "cloudflare": ["cf-ray", "__cfduid", "cloudflare"],
    "akamai": ["akamai", "x-akamai"],
    "sucuri": ["x-sucuri-id", "sucuri"],
    "imperva/incapsula": ["incap_ses", "visid_incap", "x-iinfo"],
    "aws waf / cloudfront": ["x-amz-cf-id", "cloudfront"],
    "f5 big-ip": ["bigipserver", "f5-"],
}

JWT_PATTERN = re.compile(r'^eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*$')
SESSION_COOKIE_NAMES = {"phpsessid", "jsessionid", "connect.sid", "asp.net_sessionid",
                         "sessionid", "session", "sid", "_session_id", "laravel_session"}


def _classify_cookie(name, value):
    name_l = name.lower()
    if JWT_PATTERN.match(value or ""):
        return "JWT"
    if name_l in SESSION_COOKIE_NAMES or "sess" in name_l or name_l.endswith(".sid") or name_l == "sid":
        return "Session ID"
    if name_l in ("csrftoken", "csrf_token", "xsrf-token", "x-csrf-token") or "csrf" in name_l:
        return "CSRF Token"
    if name_l in ("_ga", "_gid", "_fbp", "_gcl_au") or name_l.startswith("_ga"):
        return "Analytics/Tracking"
    if name_l in ("logged_in", "auth", "authenticated"):
        return "Auth Flag"
    return "Other"


def _parse_set_cookie(headers):
    cookies = []
    raw_cookies = headers.get_all("Set-Cookie") if hasattr(headers, "get_all") else (
        [headers["Set-Cookie"]] if headers.get("Set-Cookie") else [])
    for raw in (raw_cookies or []):
        first = raw.split(";")[0]
        if "=" not in first:
            continue
        name, value = first.split("=", 1)
        attrs = [a.strip() for a in raw.split(";")[1:]]
        cookies.append({
            "name": name.strip(),
            "type": _classify_cookie(name.strip(), value.strip()),
            "http_only": any(a.lower() == "httponly" for a in attrs),
            "secure": any(a.lower() == "secure" for a in attrs),
            "same_site": next((a.split("=")[1] for a in attrs if a.lower().startswith("samesite")), None),
            "value_preview": (value[:24] + "...") if len(value) > 24 else value,
        })
    return cookies


def _detect_waf(headers_dict, body_sample):
    hits = []
    blob = (" ".join(f"{k}:{v}" for k, v in headers_dict.items()) + " " + body_sample).lower()
    for name, sigs in WAF_SIGNATURES.items():
        if any(sig in blob for sig in sigs):
            hits.append(name)
    return hits


def _detect_tech(headers_dict, body):
    found = set()
    if headers_dict.get("X-Powered-By"):
        found.add(headers_dict["X-Powered-By"])
    if headers_dict.get("Server"):
        found.add(headers_dict["Server"])
    for pattern, label, kind in TECH_SIGNATURES:
        if kind == "meta":
            m = re.search(pattern, body, re.I)
            if m:
                found.add(m.group(1))
        elif kind in ("body", "cookie_or_header"):
            if re.search(pattern, body, re.I):
                found.add(label)
    return sorted(found)


def _tls_cert(hostname, port=443, timeout=5):
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((hostname, port), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                subject = dict(x[0] for x in cert.get("subject", []))
                issuer = dict(x[0] for x in cert.get("issuer", []))
                not_after = datetime.strptime(cert["notAfter"], "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
                sans = [v for k, v in cert.get("subjectAltName", []) if k == "DNS"]
                return {
                    "subject_cn": subject.get("commonName"),
                    "issuer": issuer.get("organizationName") or issuer.get("commonName"),
                    "valid_until": str(not_after.date()),
                    "days_until_expiry": (not_after - datetime.now(timezone.utc)).days,
                    "san_domains": sans,
                    "tls_version": ssock.version(),
                }
    except Exception as e:
        return {"error": str(e)}


def analyze(url: str) -> dict:
    parsed = urlparse(url if "://" in url else f"https://{url}")
    hostname = parsed.hostname
    scheme = parsed.scheme or "https"
    result = {"target": f"{scheme}://{hostname}"}

    try:
        req = urllib.request.Request(f"{scheme}://{hostname}{parsed.path or '/'}",
                                      headers={"User-Agent": "Module1-Recon/1.0"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            headers_obj = resp.headers
            headers_dict = dict(headers_obj.items())
            body = resp.read(200_000).decode(errors="ignore")

        result["status_code"] = resp.status
        result["headers"] = headers_dict
        result["server_banner"] = headers_dict.get("Server", "Not disclosed")
        result["cookies"] = _parse_set_cookie(headers_obj)
        result["technologies"] = _detect_tech(headers_dict, body)
        result["waf_detected"] = _detect_waf(headers_dict, body)
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        result["error"] = str(e)
        return result

    if scheme == "https":
        result["ssl_certificate"] = _tls_cert(hostname)

    return result
