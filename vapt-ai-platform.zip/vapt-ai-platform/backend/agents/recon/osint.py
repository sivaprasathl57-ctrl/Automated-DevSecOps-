"""
Module 1 — OSINT Agent

Gathers company/employee-adjacent intelligence using only sources that don't
require scraping a platform in violation of its Terms of Service:

  - GitHub: uses GitHub's public REST API (no auth needed for basic org/user
    lookups) — fully legitimate, this is what the API is for.
  - LinkedIn / general web: LinkedIn's ToS prohibits automated scraping, and
    doing so can carry legal risk (breach of contract / CFAA-adjacent
    exposure in some jurisdictions). Instead of scraping, this agent
    generates ready-to-click search-engine "dork" queries (Google/Bing) that
    a human analyst opens manually — the standard, ToS-safe way real OSINT
    engagements gather this category of data.
  - Email pattern: given any employee names discovered elsewhere, proposes
    the likely corporate email convention (firstname.lastname@domain, etc.)
    — labelled clearly as an unverified pattern guess, not a confirmed address.
  - Data breach exposure: wraps the Have I Been Pwned API. HIBP's
    programmatic API requires a paid key (env var HIBP_API_KEY) — if it's
    not set, this returns manual-check instructions instead of failing.
"""
import json
import os
import urllib.request
import urllib.error
import urllib.parse

GITHUB_API = "https://api.github.com"


def github_org_lookup(org_or_domain: str, timeout=8) -> dict:
    """Looks up a GitHub organization matching the company/domain name."""
    guess = org_or_domain.split(".")[0]
    try:
        req = urllib.request.Request(f"{GITHUB_API}/orgs/{guess}",
                                      headers={"Accept": "application/vnd.github+json",
                                               "User-Agent": "Module1-Recon/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
        org_info = {
            "login": data.get("login"), "name": data.get("name"),
            "blog": data.get("blog"), "public_repos": data.get("public_repos"),
            "location": data.get("location"), "email": data.get("email"),
            "html_url": data.get("html_url"),
        }
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError):
        return {"found": False, "note": f"No GitHub org found at guessed slug '{guess}' — try the exact org name."}

    members = []
    try:
        req = urllib.request.Request(f"{GITHUB_API}/orgs/{guess}/members",
                                      headers={"Accept": "application/vnd.github+json",
                                               "User-Agent": "Module1-Recon/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
        members = [{"username": m.get("login"), "profile": m.get("html_url")} for m in data[:30]]
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError):
        pass  # member list is often private — not fatal

    return {"found": True, "org": org_info, "public_members": members}


def search_dorks(company_name: str, domain: str) -> dict:
    """Ready-to-open search engine dork links (ToS-safe substitute for scraping)."""
    q = urllib.parse.quote

    def google(query):
        return f"https://www.google.com/search?q={q(query)}"

    def bing(query):
        return f"https://www.bing.com/search?q={q(query)}"

    return {
        "employees_linkedin": google(f'site:linkedin.com/in "{company_name}"'),
        "employees_linkedin_bing": bing(f'site:linkedin.com/in "{company_name}"'),
        "company_linkedin_page": google(f'site:linkedin.com/company "{company_name}"'),
        "twitter_x_account": google(f'site:twitter.com OR site:x.com "{company_name}"'),
        "facebook_page": google(f'site:facebook.com "{company_name}"'),
        "instagram_account": google(f'site:instagram.com "{company_name}"'),
        "public_pdfs": google(f'site:{domain} filetype:pdf'),
        "public_docx": google(f'site:{domain} filetype:docx'),
        "public_xlsx": google(f'site:{domain} filetype:xlsx'),
        "exposed_config_files": google(f'site:{domain} (ext:env OR ext:log OR ext:sql OR ext:bak)'),
        "job_postings_tech_stack": google(f'site:{domain} careers OR jobs "requirements"'),
        "pastebin_mentions": google(f'site:pastebin.com "{domain}"'),
    }


def guess_email_patterns(domain: str, sample_name: str = "First Last") -> list:
    first, *rest = sample_name.strip().split(" ")
    last = rest[-1] if rest else ""
    first, last = first.lower(), last.lower()
    if not last:
        return []
    patterns = [
        f"{first}.{last}@{domain}", f"{first}{last}@{domain}",
        f"{first[0]}{last}@{domain}", f"{first}@{domain}",
        f"{first}_{last}@{domain}", f"{last}.{first}@{domain}",
    ]
    return [{"pattern": p, "confidence": "unverified — common convention guess only"} for p in patterns]


def check_breaches(domain: str, timeout=8) -> dict:
    api_key = os.environ.get("HIBP_API_KEY")
    if not api_key:
        return {
            "checked": False,
            "note": "Set HIBP_API_KEY to enable automated Have I Been Pwned domain checks "
                    "(their API requires a paid key). Manual check available at:",
            "manual_check_url": f"https://haveibeenpwned.com/DomainSearch",
        }
    try:
        req = urllib.request.Request(
            f"https://haveibeenpwned.com/api/v3/breacheddomain/{domain}",
            headers={"hibp-api-key": api_key, "User-Agent": "Module1-Recon/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return {"checked": True, "breaches": json.loads(resp.read())}
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return {"checked": True, "breaches": [], "note": "No breaches found for this domain."}
        return {"checked": False, "error": str(e)}
    except Exception as e:
        return {"checked": False, "error": str(e)}


def gather(company_name: str, domain: str) -> dict:
    return {
        "github": github_org_lookup(domain),
        "search_dorks": search_dorks(company_name, domain),
        "email_pattern_examples": guess_email_patterns(domain),
        "breach_check": check_breaches(domain),
    }
