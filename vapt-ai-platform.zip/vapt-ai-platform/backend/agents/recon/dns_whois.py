"""
Module 1 — DNS & WHOIS Agent
Fully passive: standard DNS resolution + a WHOIS lookup, exactly what any
`dig`/`whois` command does. Gathers domain registration info and every
common DNS record type.
"""
import socket
from datetime import datetime

try:
    import dns.resolver
    _HAS_DNSPYTHON = True
except ImportError:
    _HAS_DNSPYTHON = False

try:
    import whois as whois_lib
    _HAS_WHOIS = True
except ImportError:
    _HAS_WHOIS = False

RECORD_TYPES = ["A", "AAAA", "MX", "TXT", "NS", "CNAME", "SOA"]


def _resolve(domain, rtype):
    try:
        resolver = dns.resolver.Resolver()
        resolver.timeout = 4
        resolver.lifetime = 4
        answers = resolver.resolve(domain, rtype)
        return [str(r).strip() for r in answers]
    except Exception:
        return []


def get_dns_records(domain: str) -> dict:
    records = {}
    if not _HAS_DNSPYTHON:
        return {"error": "dnspython not installed"}
    for rtype in RECORD_TYPES:
        vals = _resolve(domain, rtype)
        if vals:
            records[rtype] = vals
    return records


def get_whois(domain: str) -> dict:
    if not _HAS_WHOIS:
        return {"error": "python-whois not installed"}
    try:
        w = whois_lib.whois(domain)

        def fmt(v):
            if isinstance(v, list):
                v = v[0] if v else None
            if isinstance(v, datetime):
                return v.isoformat()
            return v

        return {
            "domain_name": fmt(w.get("domain_name")),
            "registrar": fmt(w.get("registrar")),
            "registration_date": fmt(w.get("creation_date")),
            "expiration_date": fmt(w.get("expiration_date")),
            "updated_date": fmt(w.get("updated_date")),
            "name_servers": w.get("name_servers") if isinstance(w.get("name_servers"), list) else ([w.get("name_servers")] if w.get("name_servers") else []),
            "status": w.get("status"),
            "emails": w.get("emails") if isinstance(w.get("emails"), list) else ([w.get("emails")] if w.get("emails") else []),
            "org": fmt(w.get("org")),
            "country": fmt(w.get("country")),
        }
    except Exception as e:
        return {"error": str(e)}


def resolve_ip(domain: str) -> str:
    try:
        return socket.gethostbyname(domain)
    except socket.gaierror:
        return None


def analyze(domain: str) -> dict:
    ip = resolve_ip(domain)
    return {
        "domain": domain,
        "primary_ip": ip,
        "dns_records": get_dns_records(domain),
        "whois": get_whois(domain),
    }
