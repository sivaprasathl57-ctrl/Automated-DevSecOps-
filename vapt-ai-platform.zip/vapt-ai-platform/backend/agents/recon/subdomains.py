"""
Module 1 — Subdomain Enumeration Agent

Two techniques, both standard and low-impact:
  1. Certificate Transparency search (crt.sh) — fully passive, queries a
     public log of issued certificates, touches the target zero times.
  2. A short common-subdomain wordlist resolved via plain DNS lookups
     (www, mail, api, ...) — the same kind of lookup any DNS resolver does
     constantly; not a brute-force fuzz of thousands of names.
"""
import json
import socket
import urllib.request
import urllib.error

COMMON_SUBDOMAINS = [
    "www", "mail", "webmail", "smtp", "ftp", "api", "dev", "staging", "test",
    "admin", "portal", "vpn", "blog", "shop", "app", "cdn", "static", "docs",
    "support", "status", "ns1", "ns2", "mx", "git", "ci", "dashboard",
]


def from_certificate_transparency(domain: str, timeout=8) -> list:
    url = f"https://crt.sh/?q=%25.{domain}&output=json"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Module1-Recon/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
        names = set()
        for entry in data:
            for n in entry.get("name_value", "").split("\n"):
                n = n.strip().lstrip("*.")
                if n and n.endswith(domain):
                    names.add(n)
        return sorted(names)
    except (urllib.error.URLError, TimeoutError, OSError, ValueError, json.JSONDecodeError):
        return []


def from_common_names(domain: str) -> list:
    found = []
    for sub in COMMON_SUBDOMAINS:
        fqdn = f"{sub}.{domain}"
        try:
            ip = socket.gethostbyname(fqdn)
            found.append({"subdomain": fqdn, "ip": ip})
        except socket.gaierror:
            continue
    return found


def enumerate(domain: str) -> dict:
    ct_names = from_certificate_transparency(domain)
    resolved = from_common_names(domain)
    resolved_names = {r["subdomain"] for r in resolved}
    all_names = sorted(set(ct_names) | resolved_names)
    return {
        "total_found": len(all_names),
        "subdomains": all_names,
        "resolved_with_ip": resolved,
        "source": "crt.sh (certificate transparency) + common-name DNS resolution",
    }
