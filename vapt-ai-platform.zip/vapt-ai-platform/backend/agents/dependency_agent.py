"""
Agent 4 — Dependency / SCA (Software Composition Analysis) Agent
Parses dependency manifests (requirements.txt, package.json, ...) and flags
packages pinned to known-vulnerable versions. Ships with a small embedded
reference dataset so it works fully offline; if internet access is available
at runtime it will additionally query the free OSV.dev API for a live check.
"""
import json
import os
import re
import urllib.request
import urllib.error

# Small illustrative offline dataset: {ecosystem: {package: {vulnerable_below: version, cve, severity}}}
KNOWN_VULNERABLE = {
    "pip": {
        "django": {"vulnerable_below": "3.2.18", "cve": "CVE-2023-31047", "severity": "high"},
        "flask": {"vulnerable_below": "2.2.5", "cve": "CVE-2023-30861", "severity": "high"},
        "requests": {"vulnerable_below": "2.31.0", "cve": "CVE-2023-32681", "severity": "medium"},
        "pyyaml": {"vulnerable_below": "5.4", "cve": "CVE-2020-14343", "severity": "high"},
        "pillow": {"vulnerable_below": "10.0.1", "cve": "CVE-2023-44271", "severity": "high"},
        "jinja2": {"vulnerable_below": "3.1.3", "cve": "CVE-2024-22195", "severity": "medium"},
    },
    "npm": {
        "lodash": {"vulnerable_below": "4.17.21", "cve": "CVE-2021-23337", "severity": "high"},
        "express": {"vulnerable_below": "4.19.2", "cve": "CVE-2024-29041", "severity": "medium"},
        "axios": {"vulnerable_below": "1.6.0", "cve": "CVE-2023-45857", "severity": "medium"},
        "minimist": {"vulnerable_below": "1.2.6", "cve": "CVE-2021-44906", "severity": "critical"},
        "jsonwebtoken": {"vulnerable_below": "9.0.0", "cve": "CVE-2022-23529", "severity": "critical"},
    },
}


def _version_lt(a: str, b: str) -> bool:
    def parts(v):
        return [int(x) for x in re.findall(r"\d+", v)][:3] or [0]
    pa, pb = parts(a), parts(b)
    pa += [0] * (3 - len(pa))
    pb += [0] * (3 - len(pb))
    return pa < pb


def _parse_requirements_txt(text: str):
    deps = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = re.match(r'^([A-Za-z0-9_.\-]+)\s*==\s*([0-9][0-9A-Za-z.\-]*)', line)
        if m:
            deps.append((m.group(1).lower(), m.group(2)))
    return deps


def _parse_package_json(text: str):
    deps = []
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return deps
    for section in ("dependencies", "devDependencies"):
        for name, ver in (data.get(section) or {}).items():
            ver_clean = re.sub(r"[^\d.]", "", ver.split("||")[0])
            if ver_clean:
                deps.append((name.lower(), ver_clean))
    return deps


def check_osv(package: str, version: str, ecosystem: str, timeout=3):
    """Optional live check against OSV.dev. Silently no-ops if offline."""
    try:
        payload = json.dumps({
            "version": version,
            "package": {"name": package, "ecosystem": "PyPI" if ecosystem == "pip" else "npm"},
        }).encode()
        req = urllib.request.Request(
            "https://api.osv.dev/v1/query", data=payload,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
            return data.get("vulns", [])
    except (urllib.error.URLError, TimeoutError, OSError, ValueError):
        return None  # offline / blocked — fall back to local dataset only


def analyze(root_dir: str, manifests: list, use_live_lookup: bool = True) -> list:
    findings = []
    for m in manifests:
        full_path = os.path.join(root_dir, m["path"])
        try:
            with open(full_path, "r", encoding="utf-8", errors="ignore") as fh:
                text = fh.read()
        except OSError:
            continue

        if m["ecosystem"] == "pip" and os.path.basename(m["path"]) == "requirements.txt":
            deps = _parse_requirements_txt(text)
        elif m["ecosystem"] == "npm":
            deps = _parse_package_json(text)
        else:
            deps = []

        for name, version in deps:
            local = KNOWN_VULNERABLE.get(m["ecosystem"], {}).get(name)
            live_vulns = check_osv(name, version, m["ecosystem"]) if use_live_lookup else None

            if local and _version_lt(version, local["vulnerable_below"]):
                findings.append({
                    "source_agent": "dependency",
                    "file_path": m["path"],
                    "line": None,
                    "rule_id": "DEP-KNOWN",
                    "cwe": "CWE-1104",
                    "title": f'Outdated dependency: {name}=={version}',
                    "description": f'{name} {version} is below the patched version '
                                    f'{local["vulnerable_below"]} for {local["cve"]}.',
                    "severity": local["severity"],
                    "evidence": f"{name}=={version}",
                    "recommendation": f'Upgrade {name} to >= {local["vulnerable_below"]}.',
                })
            elif live_vulns:
                ids = ", ".join(v.get("id", "?") for v in live_vulns[:3])
                findings.append({
                    "source_agent": "dependency",
                    "file_path": m["path"],
                    "line": None,
                    "rule_id": "DEP-OSV",
                    "cwe": "CWE-1104",
                    "title": f'Known vulnerability in {name}=={version} (OSV)',
                    "description": f'OSV.dev reports {len(live_vulns)} advisory(ies): {ids}.',
                    "severity": "high",
                    "evidence": f"{name}=={version}",
                    "recommendation": f"Review advisories {ids} and upgrade {name}.",
                })
    return findings
