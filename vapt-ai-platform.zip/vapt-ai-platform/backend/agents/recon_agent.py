"""
Agent 2 — Recon Agent (PASSIVE ONLY)

Scope & ethics note: this agent only performs the same kind of request any
ordinary browser or crawler makes — a normal GET to the site's root, and a
GET to a handful of *conventionally public* paths (robots.txt, security.txt).
It does NOT brute-force, fuzz, port-scan, or attempt to exploit anything.
Only run this against a URL you own or are explicitly authorized to test —
unauthorized scanning of third-party systems may be illegal in your
jurisdiction (e.g. under the Computer Fraud and Abuse Act / IT Act Sec. 43,66).
"""
import socket
import ssl
import urllib.request
import urllib.error
from datetime import datetime, timezone
from urllib.parse import urlparse

SECURITY_HEADERS = {
    "Content-Security-Policy": "medium",
    "Strict-Transport-Security": "medium",
    "X-Frame-Options": "medium",
    "X-Content-Type-Options": "low",
    "Referrer-Policy": "low",
    "Permissions-Policy": "low",
}

# Conventionally-public well-known paths only — not a directory brute force.
PUBLIC_PATHS = ["/robots.txt", "/.well-known/security.txt"]


def _fetch(url, timeout=6):
    req = urllib.request.Request(url, headers={"User-Agent": "VAPT-AI-Recon/1.0 (passive-scan)"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, dict(resp.headers), resp.read(2000)


def _check_tls(hostname, port=443, timeout=5):
    ctx = ssl.create_default_context()
    with socket.create_connection((hostname, port), timeout=timeout) as sock:
        with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            not_after = datetime.strptime(cert["notAfter"], "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
            days_left = (not_after - datetime.now(timezone.utc)).days
            return {"tls_version": ssock.version(), "cert_expires": str(not_after.date()), "days_until_expiry": days_left}


def analyze(url: str) -> list:
    findings = []
    parsed = urlparse(url if "://" in url else f"https://{url}")
    hostname = parsed.hostname
    scheme = parsed.scheme or "https"

    # 1. Headers check
    try:
        status, headers, body = _fetch(f"{scheme}://{hostname}{parsed.path or '/'}")
        for h, sev in SECURITY_HEADERS.items():
            if h not in headers:
                findings.append({
                    "source_agent": "recon", "file_path": None, "line": None,
                    "rule_id": f"HDR-{h.upper().replace('-', '_')}",
                    "cwe": "CWE-693", "title": f"Missing security header: {h}",
                    "description": f"The response did not include a '{h}' header.",
                    "severity": sev, "evidence": f"HTTP {status} response headers",
                    "recommendation": f"Add the '{h}' header at the web server/reverse-proxy or app framework level.",
                })
        server_hdr = headers.get("Server")
        if server_hdr:
            findings.append({
                "source_agent": "recon", "file_path": None, "line": None,
                "rule_id": "HDR-SERVER-DISCLOSURE", "cwe": "CWE-200",
                "title": "Server header discloses software/version",
                "description": f"Server header value: {server_hdr}",
                "severity": "low", "evidence": server_hdr,
                "recommendation": "Suppress or generalize the Server header to avoid fingerprinting.",
            })
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        findings.append({
            "source_agent": "recon", "file_path": None, "line": None,
            "rule_id": "RECON-UNREACHABLE", "cwe": None,
            "title": "Target unreachable", "description": str(e),
            "severity": "info", "evidence": url, "recommendation": "Verify the URL is correct and publicly reachable.",
        })
        return findings

    # 2. TLS check (best-effort)
    try:
        tls_info = _check_tls(hostname)
        if tls_info["days_until_expiry"] < 30:
            findings.append({
                "source_agent": "recon", "file_path": None, "line": None,
                "rule_id": "TLS-EXPIRY", "cwe": "CWE-295",
                "title": "TLS certificate expiring soon",
                "description": f"Certificate expires in {tls_info['days_until_expiry']} days "
                                f"({tls_info['cert_expires']}).",
                "severity": "medium", "evidence": str(tls_info),
                "recommendation": "Renew the TLS certificate before expiry, ideally via automated renewal (ACME/Let's Encrypt).",
            })
        if tls_info["tls_version"] in ("TLSv1", "TLSv1.1"):
            findings.append({
                "source_agent": "recon", "file_path": None, "line": None,
                "rule_id": "TLS-OLD-VERSION", "cwe": "CWE-326",
                "title": f"Outdated TLS version negotiated: {tls_info['tls_version']}",
                "description": "Server negotiated a deprecated TLS version.",
                "severity": "high", "evidence": tls_info["tls_version"],
                "recommendation": "Disable TLS 1.0/1.1 and require TLS 1.2+ (ideally 1.3) in your server config.",
            })
    except Exception:
        pass  # non-HTTPS or unreachable on 443 — not fatal for a passive scan

    # 3. Conventionally-public paths only
    for path in PUBLIC_PATHS:
        try:
            status, headers, body = _fetch(f"{scheme}://{hostname}{path}")
            if status == 200 and path == "/robots.txt" and b"Disallow" in body:
                findings.append({
                    "source_agent": "recon", "file_path": None, "line": None,
                    "rule_id": "INFO-ROBOTS", "cwe": "CWE-200",
                    "title": "robots.txt discloses internal paths",
                    "description": "robots.txt lists paths the site owner considers sensitive enough to hide from crawlers "
                                    "— review that these aren't relying on robots.txt alone for protection.",
                    "severity": "info", "evidence": body[:200].decode(errors="ignore"),
                    "recommendation": "Ensure sensitive paths are protected by authentication, not just excluded from robots.txt.",
                })
        except (urllib.error.URLError, TimeoutError, OSError):
            continue

    return findings
