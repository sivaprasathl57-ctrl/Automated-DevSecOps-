import ipaddress
import re
from urllib.parse import urlparse, urlunparse

VALID_SCHEMES = {"http", "https"}
HOSTNAME_RE = re.compile(
    r"^(?=.{1,253}$)(?!-)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)(?:\.(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?))*$"
)


def normalize_target_url(target: str) -> str:
    """Normalize and validate a target domain or URL for recon/scan input."""
    if target is None:
        raise ValueError("Target URL is required.")
    target = target.strip()
    if not target:
        raise ValueError("Target URL is required.")
    if " " in target:
        raise ValueError("Target URL must not contain spaces.")

    if "://" not in target:
        target = f"https://{target}"

    parsed = urlparse(target)
    scheme = parsed.scheme.lower()
    if scheme not in VALID_SCHEMES:
        raise ValueError("Only http:// and https:// targets are allowed.")
    if parsed.username or parsed.password:
        raise ValueError("Target URL must not contain embedded credentials.")
    if not parsed.netloc:
        raise ValueError("Target must include a hostname.")

    hostname = parsed.hostname
    if not hostname:
        raise ValueError("Target must include a valid hostname.")
    if hostname.endswith(".") or hostname.startswith("-") or hostname.endswith("-"):
        raise ValueError("Target hostname is not valid.")

    if hostname.lower() != "localhost":
        try:
            ipaddress.ip_address(hostname)
        except ValueError:
            if not HOSTNAME_RE.match(hostname):
                raise ValueError("Target hostname is not valid.")

    normalized = urlunparse((scheme, parsed.netloc, parsed.path or "/", "", parsed.query or "", parsed.fragment or ""))
    return normalized
