"""
Lightweight multi-language static-analysis rule set.

Each rule = (rule_id, cwe, title, severity, compiled_regex, recommendation)
This is a pattern-based scanner (similar in spirit to semgrep/bandit "grep with
context") — good enough to find real, common classes of vulnerabilities in an
academic VAPT project, and easy to extend with new rules.
"""
import re

RULES = [
    # ---- Secrets & credentials ----
    dict(
        id="SEC-001", cwe="CWE-798", title="Hardcoded credential / API key",
        severity="critical",
        pattern=r'(?i)(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*["\'][A-Za-z0-9_\-\/+]{8,}["\']',
        recommendation="Move secrets to environment variables or a secrets manager (e.g. Vault, AWS Secrets Manager). Never commit credentials to source control.",
    ),
    dict(
        id="SEC-002", cwe="CWE-798", title="Hardcoded private key material",
        severity="critical",
        pattern=r'-----BEGIN (RSA|EC|DSA|OPENSSH|PRIVATE) KEY-----',
        recommendation="Remove the embedded private key from source and rotate it immediately; load keys from a secure key store at runtime.",
    ),

    # ---- Injection ----
    dict(
        id="INJ-001", cwe="CWE-89", title="Possible SQL Injection (string concatenation in query)",
        severity="high",
        pattern=r'(?i)(execute|cursor\.execute|query)\s*\(\s*[\'"].*(%s|\+|f["\']).*(SELECT|INSERT|UPDATE|DELETE)',
        recommendation="Use parameterized queries / prepared statements instead of concatenating user input into SQL strings.",
    ),
    dict(
        id="INJ-002", cwe="CWE-89", title="Possible SQL Injection (f-string / template query)",
        severity="high",
        pattern=r'(?i)f["\'].*(SELECT|INSERT|UPDATE|DELETE)\s+.*\{.*\}',
        recommendation="Never interpolate variables directly into SQL text. Use parameter binding provided by your DB driver/ORM.",
    ),
    dict(
        id="INJ-003", cwe="CWE-78", title="OS command injection risk (shell=True / os.system with variables)",
        severity="critical",
        pattern=r'(?i)(os\.system|subprocess\.(call|run|Popen)\([^)]*shell\s*=\s*True|popen)\s*\(.*\+',
        recommendation="Avoid shell=True with concatenated input. Pass arguments as a list and validate/allowlist input.",
    ),
    dict(
        id="INJ-004", cwe="CWE-95", title="Use of eval()/exec() on dynamic input",
        severity="critical",
        pattern=r'(?i)\b(eval|exec)\s*\(',
        recommendation="Avoid eval/exec entirely. Use safe parsers (ast.literal_eval, json.loads) or an explicit allowlist of operations.",
    ),
    dict(
        id="INJ-005", cwe="CWE-643", title="Possible XPath/LDAP injection via string building",
        severity="medium",
        pattern=r'(?i)(xpath|ldap_search)\s*\(.*\+',
        recommendation="Use parameterized queries/APIs for XPath and LDAP instead of building queries with string concatenation.",
    ),

    # ---- XSS / output encoding ----
    dict(
        id="XSS-001", cwe="CWE-79", title="Potential DOM-based XSS via innerHTML with variable",
        severity="high",
        pattern=r'(?i)\.innerHTML\s*=\s*[^;]*[\+`]',
        recommendation="Use textContent for plain text, or sanitize with a library like DOMPurify before assigning HTML.",
    ),
    dict(
        id="XSS-002", cwe="CWE-79", title="Flask/Jinja autoescape disabled or |safe filter used on variable",
        severity="high",
        pattern=r'(?i)(\|\s*safe\b|autoescape\s*=\s*False)',
        recommendation="Keep autoescaping on. Only mark trusted, sanitized content as safe, never raw user input.",
    ),
    dict(
        id="XSS-003", cwe="CWE-79", title="React dangerouslySetInnerHTML usage",
        severity="high",
        pattern=r'dangerouslySetInnerHTML',
        recommendation="Avoid dangerouslySetInnerHTML with unsanitized data; sanitize with DOMPurify first if HTML rendering is required.",
    ),

    # ---- Deserialization ----
    dict(
        id="DES-001", cwe="CWE-502", title="Insecure deserialization (pickle.load on untrusted data)",
        severity="critical",
        pattern=r'(?i)pickle\.(load|loads)\s*\(',
        recommendation="Never unpickle untrusted data. Use JSON or a safe schema-validated serialization format instead.",
    ),
    dict(
        id="DES-002", cwe="CWE-502", title="Unsafe YAML load (yaml.load without SafeLoader)",
        severity="high",
        pattern=r'yaml\.load\s*\((?!.*SafeLoader)',
        recommendation="Use yaml.safe_load() instead of yaml.load(), or pass Loader=yaml.SafeLoader explicitly.",
    ),

    # ---- Crypto & randomness ----
    dict(
        id="CRY-001", cwe="CWE-327", title="Use of weak hash algorithm (MD5/SHA1) for security purposes",
        severity="medium",
        pattern=r'(?i)hashlib\.(md5|sha1)\s*\(',
        recommendation="Use SHA-256 or better; for passwords use a dedicated slow hash (bcrypt, scrypt, Argon2).",
    ),
    dict(
        id="CRY-002", cwe="CWE-338", title="Use of insecure random number generator for security-sensitive value",
        severity="medium",
        pattern=r'(?i)\brandom\.(random|randint|choice)\s*\(.*(token|password|secret|otp)',
        recommendation="Use the `secrets` module (Python) or a CSPRNG for tokens, passwords, and OTPs.",
    ),

    # ---- Auth / access control ----
    dict(
        id="AUTH-001", cwe="CWE-347", title="JWT verification disabled or alg=none accepted",
        severity="critical",
        pattern=r'(?i)(verify_signature["\']?\s*:\s*False|algorithms\s*=\s*\[\s*["\']none["\'])',
        recommendation="Always verify JWT signatures and explicitly allowlist strong algorithms (e.g. RS256); reject 'none'.",
    ),
    dict(
        id="AUTH-002", cwe="CWE-798", title="Hardcoded default admin credentials",
        severity="critical",
        pattern=r'(?i)(username|user)\s*==\s*["\']admin["\'].{0,40}(password|pass)\s*==\s*["\']',
        recommendation="Remove hardcoded credential checks; use a proper identity provider / hashed credential store.",
    ),

    # ---- Config / misconfig ----
    dict(
        id="CFG-001", cwe="CWE-16", title="Debug mode enabled in production framework config",
        severity="medium",
        pattern=r'(?i)(DEBUG\s*=\s*True|app\.run\([^)]*debug\s*=\s*True)',
        recommendation="Disable debug mode in production; it can leak stack traces, source code, and secrets.",
    ),
    dict(
        id="CFG-002", cwe="CWE-942", title="Overly permissive CORS policy (wildcard origin)",
        severity="medium",
        pattern=r'(?i)(Access-Control-Allow-Origin["\']?\s*[:=]\s*["\']\*|allow_origins\s*=\s*\[\s*["\']\*["\'])',
        recommendation="Restrict CORS to an explicit allowlist of trusted origins instead of '*', especially if credentials are allowed.",
    ),
    dict(
        id="CFG-003", cwe="CWE-489", title="TODO/FIXME referencing security bypass left in code",
        severity="low",
        pattern=r'(?i)#\s*(TODO|FIXME).{0,60}(auth|security|bypass|disable)',
        recommendation="Resolve security-related TODOs before shipping; track them in an issue tracker with an owner and deadline.",
    ),

    # ---- Path traversal ----
    dict(
        id="PATH-001", cwe="CWE-22", title="Possible path traversal (user input concatenated into file path)",
        severity="high",
        pattern=r'(?i)open\s*\(\s*[^)]*\+\s*(request\.|input\(|args\.)',
        recommendation="Validate and normalize file paths; use os.path.basename and an allowlisted base directory.",
    ),
]

_compiled = [
    {**r, "regex": re.compile(r["pattern"])} for r in RULES
]


def get_rules():
    return _compiled
