"""
MongoDB database connection and queries for VAPT-AI Platform.
Uses pymongo.
"""
import os
import json
import hashlib
import uuid
from typing import Optional, List, Dict, Any
from datetime import datetime

import pymongo
from pymongo import MongoClient

def _get_env(*keys, default=None):
    for key in keys:
        value = os.getenv(key)
        if value is not None and value != "":
            return value
    return default


# Read MongoDB URI from environment. Default to local MongoDB Compass.
MONGO_URI = _get_env("MONGO_URI", "MONGODB_URI", default="mongodb://localhost:27017/")
DB_NAME = _get_env("DB_NAME", "loginDB_NAME", "LOGINDB_NAME", default="VAPT")

# Fallback compatibility check for legacy environment variables
_host = _get_env("DB_HOST", "loginDB_HOST", "LOGINDB_HOST")
_port = _get_env("DB_PORT", "loginDB_PORT", "LOGINDB_PORT")
_user = _get_env("DB_USER", "loginDB_USER", "LOGINDB_USER")
_pass = _get_env("DB_PASSWORD", "loginDB_PASSWORD", "LOGINDB_PASSWORD")

if not os.getenv("MONGO_URI") and not os.getenv("MONGODB_URI"):
    if _host or _port or _user or _pass:
        # Default port for MongoDB is 27017. If DB_PORT is 5432 (Postgres default), override it.
        port_val = 27017
        if _port and _port != "5432":
            try:
                port_val = int(_port)
            except ValueError:
                pass
        host_val = _host if _host else "localhost"
        if _user and _pass and _user != "postgres" and _pass != "12345":
            MONGO_URI = f"mongodb://{_user}:{_pass}@{host_val}:{port_val}/"
        else:
            MONGO_URI = f"mongodb://{host_val}:{port_val}/"

_client = None


def get_client() -> MongoClient:
    global _client
    if _client is None:
        try:
            # serverSelectionTimeoutMS is 3 seconds so connection check fails fast if offline
            _client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000)
            # Force a connection check
            _client.admin.command('ping')
        except Exception as e:
            raise RuntimeError(
                f"Cannot connect to MongoDB at {MONGO_URI}. "
                f"Please ensure MongoDB is running. "
                f"Error: {e}"
            )
    return _client


def get_db():
    return get_client()[DB_NAME]


# PostgreSQL pool compatibility stubs for tests and diagnostic scripts
def get_pool():
    return None


def get_conn():
    return MockConn()


def put_conn(conn):
    pass


class MockCursor:
    def __init__(self):
        self.result = []
    
    def execute(self, query, params=None):
        query = query.strip().lower()
        db = get_db()
        # Mocking for list_roles.py and diagnose_admin_login.py
        if "from users" in query:
            if "where email" in query:
                email = params[0] if params else None
                user = db.users.find_one({"email": email})
                self.result = [user] if user else []
            else:
                self.result = list(db.users.find().sort("user_id", 1))
    
    def fetchall(self):
        return [self._format_user(u) for u in self.result]
    
    def fetchone(self):
        return self._format_user(self.result[0]) if self.result else None
    
    def _format_user(self, user):
        if not user:
            return None
        return {
            "user_id": user.get("user_id"),
            "email": user.get("email"),
            "role": user.get("role"),
            "account_status": user.get("account_status")
        }


class MockConn:
    def cursor(self, cursor_factory=None):
        return MockCursor()
    
    def commit(self):
        pass


RealDictCursor = object


def _get_next_sequence_value(sequence_name: str) -> int:
    db = get_db()
    # Find max user_id to ensure sequence is always greater than or equal to existing user IDs
    max_user = db.users.find_one(sort=[("user_id", -1)])
    max_user_id = max_user["user_id"] if max_user else 0

    result = db.counters.find_one_and_update(
        {"_id": sequence_name},
        {"$inc": {"sequence_value": 1}},
        upsert=True,
        return_document=pymongo.ReturnDocument.AFTER
    )
    val = result["sequence_value"]
    if val <= max_user_id:
        val = max_user_id + 1
        db.counters.update_one({"_id": sequence_name}, {"$set": {"sequence_value": val}})
    return val


def init_db():
    """Verify MongoDB connection and set up indices/seed data."""
    try:
        db = get_db()
        # Setup indices
        db.users.create_index("email", unique=True)
        db.users.create_index("user_id", unique=True)
        db.recon_jobs.create_index("job_id", unique=True)
        db.module2_jobs.create_index("job_id", unique=True)
        db.platform_settings.create_index("key", unique=True)
        db.revoked_tokens.create_index("token", unique=True)

        # Convert any legacy uppercase status to Title Case to satisfy MongoDB schema validation
        db.users.update_many({"account_status": "ACTIVE"}, {"$set": {"account_status": "Active"}})
        db.users.update_many({"account_status": "SUSPENDED"}, {"$set": {"account_status": "Suspended"}})
        db.users.update_many({"account_status": "INACTIVE"}, {"$set": {"account_status": "Inactive"}})

        # Seed the demo admin (id 42, siva@gmail.com / 1234)
        demo_hash = hash_password("1234")
        
        # Delete user with email siva@gmail.com that is NOT 42 to avoid unique conflict
        db.users.delete_many({"email": "siva@gmail.com", "user_id": {"$ne": 42}})
        
        db.users.update_one(
            {"user_id": 42},
            {
                "$set": {
                    "email": "siva@gmail.com",
                    "password_hash": demo_hash,
                    "first_name": "Siva",
                    "last_name": "Admin",
                    "organization": "CYVERION",
                    "college": "CYVERION",
                    "role": "Administrator",
                    "account_status": "Active",
                    "email_verified": False,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                }
            },
            upsert=True
        )

        # Seed default settings
        for key, value in DEFAULT_SETTINGS.items():
            if db.platform_settings.find_one({"key": key}) is None:
                db.platform_settings.insert_one({
                    "key": key,
                    "value": value,
                    "updated_at": datetime.utcnow()
                })
    except Exception as e:
        raise RuntimeError(f"Failed to initialize database: {e}")


def add_revoked_token(token: str) -> None:
    """Persist a revoked token in the database."""
    try:
        db = get_db()
        db.revoked_tokens.update_one(
            {"token": token},
            {"$set": {"revoked_at": datetime.utcnow()}},
            upsert=True
        )
    except Exception as e:
        raise RuntimeError(f"Failed to persist revoked token: {e}")


def is_token_revoked_db(token: str) -> bool:
    try:
        db = get_db()
        return db.revoked_tokens.find_one({"token": token}) is not None
    except Exception:
        return False


def hash_password(password: str) -> str:
    """Hash a password using SHA-256 with salt."""
    salt = uuid.uuid4().hex
    return f"{salt}${hashlib.sha256((salt + password).encode()).hexdigest()}"


def verify_password(password: str, stored_hash: str) -> bool:
    """Verify a password against a stored hash."""
    try:
        salt, h = stored_hash.split("$", 1)
        return h == hashlib.sha256((salt + password).encode()).hexdigest()
    except (ValueError, AttributeError):
        return False


def register_user(first_name: str, last_name: str, email: str, phone_number: str,
                  organization: str, role: str, password: str) -> dict:
    """Register a new user. Returns user dict or raises on duplicate email."""
    try:
        db = get_db()
        # Check if email exists
        if db.users.find_one({"email": email}) is not None:
            raise ValueError("Email already registered")

        user_id = _get_next_sequence_value("user_id")
        password_hash = hash_password(password)
        created_at = datetime.utcnow()

        user_doc = {
            "user_id": user_id,
            "email": email,
            "first_name": first_name,
            "last_name": last_name,
            "phone_number": phone_number or "",
            "organization": organization or "",
            "college": organization or "",
            "role": role or "",
            "password_hash": password_hash,
            "account_status": "Active",
            "email_verified": False,
            "created_at": created_at,
            "updated_at": created_at
        }

        db.users.insert_one(user_doc)
        return {
            "id": user_id,
            "email": email,
            "first_name": first_name,
            "last_name": last_name,
            "created_at": created_at
        }
    except ValueError:
        raise
    except Exception as e:
        raise RuntimeError(f"Registration failed: {e}")


def login_user(email: str, password: str) -> Optional[dict]:
    """Authenticate a user. Returns user dict on success, None on failure."""
    try:
        db = get_db()
        user = db.users.find_one({"email": email})
        if not user:
            return None
        if not verify_password(password, user["password_hash"]):
            return None
        return {
            "id": user["user_id"],
            "email": user["email"],
            "first_name": user["first_name"],
            "last_name": user["last_name"],
            "role": user.get("role"),
        }
    except Exception as e:
        raise RuntimeError(f"Login failed: {e}")


def save_recon_job(user_id: int, job_id: str, target: str, company_name: str,
                  aggressive: bool, run_osint: bool, authorized: bool,
                  status: str = "queued") -> None:
    try:
        db = get_db()
        job_doc = {
            "job_id": job_id,
            "user_id": int(user_id),
            "target": target,
            "company_name": company_name or "",
            "aggressive": aggressive,
            "run_osint": run_osint,
            "authorized": authorized,
            "status": status,
            "report": None,
            "created_at": datetime.utcnow(),
            "completed_at": None
        }
        db.recon_jobs.insert_one(job_doc)
    except Exception as e:
        raise RuntimeError(f"Failed to save recon job: {e}")


def update_recon_job(job_id: str, status: str, report: Optional[dict] = None) -> None:
    try:
        db = get_db()
        update_doc = {"status": status}
        if report is not None:
            update_doc["report"] = report
            update_doc["completed_at"] = datetime.utcnow()
        db.recon_jobs.update_one(
            {"job_id": job_id},
            {"$set": update_doc}
        )
    except Exception as e:
        raise RuntimeError(f"Failed to update recon job: {e}")


def get_recon_history(user_id: int) -> list[dict]:
    try:
        db = get_db()
        jobs = list(db.recon_jobs.find({"user_id": int(user_id)}).sort("created_at", pymongo.DESCENDING))
        result = []
        for job in jobs:
            result.append({
                "job_id": job["job_id"],
                "target": job["target"],
                "company_name": job.get("company_name", ""),
                "status": job["status"],
                "aggressive": job.get("aggressive", False),
                "run_osint": job.get("run_osint", False),
                "authorized": job.get("authorized", False),
                "created_at": job["created_at"],
                "completed_at": job.get("completed_at")
            })
        return result
    except Exception as e:
        raise RuntimeError(f"Failed to load recon history: {e}")


def get_recon_job(job_id: str, user_id: int) -> Optional[dict]:
    try:
        db = get_db()
        job = db.recon_jobs.find_one({"job_id": job_id, "user_id": int(user_id)})
        if not job:
            return None
        return {
            "job_id": job["job_id"],
            "user_id": job["user_id"],
            "target": job["target"],
            "company_name": job.get("company_name", ""),
            "status": job["status"],
            "report": job.get("report"),
            "created_at": job["created_at"],
            "completed_at": job.get("completed_at")
        }
    except Exception as e:
        raise RuntimeError(f"Failed to load recon job: {e}")


def get_recon_job_any(job_id: str) -> Optional[dict]:
    """Load a recon job by id regardless of owner (admin use only)."""
    try:
        db = get_db()
        job = db.recon_jobs.find_one({"job_id": job_id})
        if not job:
            return None
        return {
            "job_id": job["job_id"],
            "user_id": job["user_id"],
            "target": job["target"],
            "company_name": job.get("company_name", ""),
            "status": job["status"],
            "report": job.get("report"),
            "created_at": job["created_at"],
            "completed_at": job.get("completed_at")
        }
    except Exception as e:
        raise RuntimeError(f"Failed to load recon job: {e}")


def save_module2_job(user_id: int, job_id: str, target: Optional[str],
                     has_uploaded_code: bool, agents: list, aggressive: bool,
                     authorized: bool, status: str = "queued") -> None:
    try:
        db = get_db()
        job_doc = {
            "job_id": job_id,
            "user_id": int(user_id),
            "target": target,
            "has_uploaded_code": has_uploaded_code,
            "agents": agents or [],
            "aggressive": aggressive,
            "authorized": authorized,
            "status": status,
            "report": None,
            "created_at": datetime.utcnow(),
            "completed_at": None
        }
        db.module2_jobs.insert_one(job_doc)
    except Exception as e:
        raise RuntimeError(f"Failed to save module2 job: {e}")


def update_module2_job(job_id: str, status: str, report: Optional[dict] = None) -> None:
    try:
        db = get_db()
        update_doc = {"status": status}
        if report is not None:
            update_doc["report"] = report
            update_doc["completed_at"] = datetime.utcnow()
        db.module2_jobs.update_one(
            {"job_id": job_id},
            {"$set": update_doc}
        )
    except Exception as e:
        raise RuntimeError(f"Failed to update module2 job: {e}")


def get_module2_history(user_id: int) -> list[dict]:
    try:
        db = get_db()
        jobs = list(db.module2_jobs.find({"user_id": int(user_id)}).sort("created_at", pymongo.DESCENDING))
        result = []
        for job in jobs:
            result.append({
                "job_id": job["job_id"],
                "target": job.get("target"),
                "has_uploaded_code": job.get("has_uploaded_code", False),
                "agents": job.get("agents", []),
                "status": job["status"],
                "aggressive": job.get("aggressive", False),
                "authorized": job.get("authorized", False),
                "created_at": job["created_at"],
                "completed_at": job.get("completed_at")
            })
        return result
    except Exception as e:
        raise RuntimeError(f"Failed to load module2 history: {e}")


def get_module2_job(job_id: str, user_id: int) -> Optional[dict]:
    try:
        db = get_db()
        job = db.module2_jobs.find_one({"job_id": job_id, "user_id": int(user_id)})
        if not job:
            return None
        return {
            "job_id": job["job_id"],
            "user_id": job["user_id"],
            "target": job.get("target"),
            "has_uploaded_code": job.get("has_uploaded_code", False),
            "agents": job.get("agents", []),
            "status": job["status"],
            "aggressive": job.get("aggressive", False),
            "authorized": job.get("authorized", False),
            "report": job.get("report"),
            "created_at": job["created_at"],
            "completed_at": job.get("completed_at")
        }
    except Exception as e:
        raise RuntimeError(f"Failed to load module2 job: {e}")


def get_module2_job_any(job_id: str) -> Optional[dict]:
    """Load a module2 job by id regardless of owner (admin use only)."""
    try:
        db = get_db()
        job = db.module2_jobs.find_one({"job_id": job_id})
        if not job:
            return None
        return {
            "job_id": job["job_id"],
            "user_id": job["user_id"],
            "target": job.get("target"),
            "has_uploaded_code": job.get("has_uploaded_code", False),
            "agents": job.get("agents", []),
            "status": job["status"],
            "aggressive": job.get("aggressive", False),
            "authorized": job.get("authorized", False),
            "report": job.get("report"),
            "created_at": job["created_at"],
            "completed_at": job.get("completed_at")
        }
    except Exception as e:
        raise RuntimeError(f"Failed to load module2 job: {e}")


def get_all_module2_jobs(limit: int = 200) -> list[dict]:
    """Return recent Module 2 jobs across all users, joined with the owning user's email."""
    try:
        db = get_db()
        jobs = list(db.module2_jobs.find().sort("created_at", pymongo.DESCENDING).limit(limit))
        user_ids = list(set(job["user_id"] for job in jobs))
        users = {u["user_id"]: u for u in db.users.find({"user_id": {"$in": user_ids}})}
        
        result = []
        for job in jobs:
            user = users.get(job["user_id"], {})
            result.append({
                "job_id": job["job_id"],
                "user_id": job["user_id"],
                "user_email": user.get("email", ""),
                "first_name": user.get("first_name", ""),
                "last_name": user.get("last_name", ""),
                "target": job.get("target"),
                "status": job["status"],
                "aggressive": job.get("aggressive", False),
                "authorized": job.get("authorized", False),
                "created_at": job["created_at"],
                "completed_at": job.get("completed_at")
            })
        return result
    except Exception as e:
        raise RuntimeError(f"Failed to load module2 jobs: {e}")


def get_user_by_id(user_id: int) -> Optional[dict]:
    """Return a user record by id."""
    try:
        db = get_db()
        user = db.users.find_one({"user_id": int(user_id)})
        if not user:
            return None
        return {
            "id": user["user_id"],
            "email": user["email"],
            "first_name": user["first_name"],
            "last_name": user["last_name"],
            "role": user.get("role")
        }
    except Exception as e:
        raise RuntimeError(f"Failed to load user: {e}")


def get_all_users() -> list[dict]:
    """Return a list of all users."""
    try:
        db = get_db()
        users = list(db.users.find().sort("user_id", pymongo.DESCENDING))
        return [{
            "id": u["user_id"],
            "email": u["email"],
            "first_name": u["first_name"],
            "last_name": u["last_name"],
            "role": u.get("role"),
            "organization": u.get("organization"),
            "account_status": u.get("account_status", "Active"),
            "created_at": u.get("created_at")
        } for u in users]
    except Exception as e:
        raise RuntimeError(f"Failed to list users: {e}")


def update_user_role(user_id: int, role: str) -> Optional[dict]:
    """Update a user's role. Returns the updated user or None if not found."""
    try:
        db = get_db()
        result = db.users.find_one_and_update(
            {"user_id": int(user_id)},
            {"$set": {"role": role, "updated_at": datetime.utcnow()}},
            return_document=pymongo.ReturnDocument.AFTER
        )
        if not result:
            return None
        return {
            "user_id": result["user_id"],
            "email": result["email"],
            "first_name": result["first_name"],
            "last_name": result["last_name"],
            "role": result.get("role")
        }
    except Exception as e:
        raise RuntimeError(f"Failed to update user role: {e}")


def update_user_status(user_id: int, status: str) -> Optional[dict]:
    """Update a user's account status."""
    try:
        db = get_db()
        db_status = status.strip().title()
        result = db.users.find_one_and_update(
            {"user_id": int(user_id)},
            {"$set": {"account_status": db_status, "updated_at": datetime.utcnow()}},
            return_document=pymongo.ReturnDocument.AFTER
        )
        if not result:
            return None
        return {
            "id": result["user_id"],
            "email": result["email"],
            "first_name": result["first_name"],
            "last_name": result["last_name"],
            "role": result.get("role"),
            "account_status": result.get("account_status")
        }
    except Exception as e:
        raise RuntimeError(f"Failed to update user status: {e}")


def delete_user_by_id(user_id: int) -> bool:
    """Delete a user and cascade delete their recon/module2 jobs."""
    try:
        db = get_db()
        res = db.users.delete_one({"user_id": int(user_id)})
        deleted = res.deleted_count > 0
        if deleted:
            db.recon_jobs.delete_many({"user_id": int(user_id)})
            db.module2_jobs.delete_many({"user_id": int(user_id)})
        return deleted
    except Exception as e:
        raise RuntimeError(f"Failed to delete user: {e}")


def get_all_recon_jobs(limit: int = 200) -> list[dict]:
    """Return recent recon jobs across all users, joined with the owning user's email."""
    try:
        db = get_db()
        jobs = list(db.recon_jobs.find().sort("created_at", pymongo.DESCENDING).limit(limit))
        user_ids = list(set(job["user_id"] for job in jobs))
        users = {u["user_id"]: u for u in db.users.find({"user_id": {"$in": user_ids}})}

        result = []
        for job in jobs:
            user = users.get(job["user_id"], {})
            result.append({
                "job_id": job["job_id"],
                "user_id": job["user_id"],
                "user_email": user.get("email", ""),
                "first_name": user.get("first_name", ""),
                "last_name": user.get("last_name", ""),
                "target": job["target"],
                "company_name": job.get("company_name", ""),
                "status": job["status"],
                "aggressive": job.get("aggressive", False),
                "run_osint": job.get("run_osint", False),
                "authorized": job.get("authorized", False),
                "created_at": job["created_at"],
                "completed_at": job.get("completed_at")
            })
        return result
    except Exception as e:
        raise RuntimeError(f"Failed to load recon jobs: {e}")


def get_admin_stats() -> dict:
    """Aggregate counts for the admin dashboard overview."""
    try:
        db = get_db()
        total_users = db.users.count_documents({})
        total_admins = db.users.count_documents({"role": {"$regex": "^admin$", "$options": "i"}})

        from datetime import timedelta
        seven_days_ago = datetime.utcnow() - timedelta(days=7)
        new_users_7d = db.users.count_documents({"created_at": {"$gte": seven_days_ago}})

        total_recon_jobs = db.recon_jobs.count_documents({})
        
        pipeline = [
            {"$group": {"_id": "$status", "count": {"$sum": 1}}}
        ]
        status_groups = list(db.recon_jobs.aggregate(pipeline))
        recon_by_status = {group["_id"]: group["count"] for group in status_groups}

        scans_7d = db.recon_jobs.count_documents({"created_at": {"$gte": seven_days_ago}})

        return {
            "total_users": total_users,
            "total_admins": total_admins,
            "new_users_7d": new_users_7d,
            "total_recon_jobs": total_recon_jobs,
            "recon_by_status": recon_by_status,
            "scans_7d": scans_7d,
        }
    except Exception as e:
        raise RuntimeError(f"Failed to load admin stats: {e}")


# =============================================================================
# Platform settings (server-authoritative)
# =============================================================================

DEFAULT_SETTINGS = {
    "maintenance_mode": False,
    "two_fa": False,
    "session_timeout_minutes": 60,
    "brute_force_protection": True,
    "strong_passwords": True,
    "admin_login_notify": False,
    "encrypt_reports": False,
    "audit_retention_days": 90,
    "autobackup": False,
    "backup_schedule": "daily",
    "rate_limiting": False,
    "scan_approval": False,
    "email_alerts": False,
    "video_retention_days": 30,
    "lock_scan_config": False,
    "compliance_mode": False,
    "cloud_sync": False,
    "restrict_admin_creation": False,
    "google_client_id": "",
}


def get_all_settings() -> dict:
    """Return all platform settings merged with defaults."""
    try:
        db = get_db()
        rows = list(db.platform_settings.find())
        settings = dict(DEFAULT_SETTINGS)
        for r in rows:
            settings[r["key"]] = r["value"]
        return settings
    except Exception as e:
        raise RuntimeError(f"Failed to load platform settings: {e}")


def get_setting(key: str, default=None):
    """Fetch a single setting value."""
    try:
        return get_all_settings().get(key, default)
    except Exception:
        return default


def set_setting(key: str, value) -> None:
    """Upsert a single platform setting."""
    try:
        db = get_db()
        db.platform_settings.update_one(
            {"key": key},
            {"$set": {"value": value, "updated_at": datetime.utcnow()}},
            upsert=True
        )
    except Exception as e:
        raise RuntimeError(f"Failed to set platform setting '{key}': {e}")


def log_audit(actor_id, actor_email: str, action: str, detail: Optional[dict] = None) -> None:
    """Append an entry to the audit log. Never raises."""
    try:
        db = get_db()
        db.audit_log.insert_one({
            "actor_id": int(actor_id) if actor_id is not None else None,
            "actor_email": actor_email,
            "action": action,
            "detail": detail or {},
            "created_at": datetime.utcnow()
        })
    except Exception:
        pass


def get_audit_logs(limit: int = 200) -> list[dict]:
    """Return the most recent audit log entries."""
    try:
        db = get_db()
        logs = list(db.audit_log.find().sort("created_at", pymongo.DESCENDING).limit(limit))
        result = []
        for l in logs:
            result.append({
                "id": str(l["_id"]),
                "actor_id": l.get("actor_id"),
                "actor_email": l.get("actor_email"),
                "action": l["action"],
                "detail": l.get("detail", {}),
                "created_at": l["created_at"]
            })
        return result
    except Exception as e:
        raise RuntimeError(f"Failed to load audit logs: {e}")


def update_recon_assessment(job_id: str, assessment: dict) -> None:
    """Update the custom analyst risk assessment on a recon job in MongoDB."""
    try:
        db = get_db()
        db.recon_jobs.update_one(
            {"job_id": job_id},
            {"$set": {"report.analyst_assessment": assessment}}
        )
    except Exception as e:
        raise RuntimeError(f"Failed to update recon assessment: {e}")

