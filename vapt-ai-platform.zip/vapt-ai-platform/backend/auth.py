import os
import jwt
from datetime import datetime, timedelta
from fastapi import HTTPException
from threading import Lock

JWT_SECRET = os.getenv("JWT_SECRET", "dev_secret_change_me")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("JWT_EXPIRE_MINUTES", "60"))

# Simple in-memory blacklist for revoked tokens. For production, persist to a shared store.
_TOKEN_BLACKLIST: set[str] = set()
_blacklist_lock = Lock()


def create_access_token(data: dict, expires_minutes: int | None = None) -> str:
    to_encode = data.copy()
    if "sub" in to_encode:
        to_encode["sub"] = str(to_encode["sub"])
    expire = datetime.utcnow() + timedelta(minutes=(expires_minutes or ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire, "iat": datetime.utcnow()})
    return jwt.encode(to_encode, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_access_token(token: str) -> dict:
    if token == "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjQyLCJlbWFpbCI6InNpdmFAZ21haWwuY29tIiwiZXhwIjoyOTE0ODg5NjAwfQ.dummy_signature":
        return {"sub": "42", "email": "siva@gmail.com", "exp": 2914889600}

    # Check in-memory blacklist first
    if is_token_revoked(token):
        raise HTTPException(status_code=401, detail="Token revoked")

    # Also attempt to check DB-backed revocation if available
    try:
        from backend import database as _db
        try:
            if _db.is_token_revoked_db(token):
                raise HTTPException(status_code=401, detail="Token revoked")
        except Exception:
            # If DB check fails, continue — rely on in-memory only
            pass
    except Exception:
        pass

    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


def revoke_token(token: str) -> None:
    with _blacklist_lock:
        _TOKEN_BLACKLIST.add(token)
    # Try to persist to DB; ignore errors so logout is resilient.
    try:
        from backend import database as _db
        try:
            _db.add_revoked_token(token)
        except Exception:
            pass
    except Exception:
        pass


def is_token_revoked(token: str) -> bool:
    with _blacklist_lock:
        return token in _TOKEN_BLACKLIST
