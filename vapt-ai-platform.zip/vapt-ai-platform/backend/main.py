"""
VAPT-AI Platform — API layer
Endpoints:
  POST /api/scan            -> start a Module 1(b) static scan job (url and/or uploaded files), returns job_id
  GET  /api/stream/{job_id} -> Server-Sent Events stream of live agent activity
  GET  /api/report/{job_id} -> full JSON report for a job
  POST /api/auth/register   -> register a new user (stores in PostgreSQL)
  POST /api/auth/login      -> authenticate user (validates against PostgreSQL)

  Module 2 — Active Vulnerability Agents (real-time, live-target testing):
  POST /api/module2/start          -> launch the agent suite against an authorized target
  GET  /api/module2/stream/{job_id}-> SSE stream of live agent activity
  GET  /api/module2/report/{job_id}-> full JSON report for a Module 2 job
"""
import asyncio
import json
import os
import shutil
import tempfile
import time
import uuid
from typing import List, Optional
import traceback
from pydantic import BaseModel

from fastapi import FastAPI, UploadFile, File, Form, Header, HTTPException, Request, Body, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles

from models import ScanJob, Finding
from orchestrator import run_pipeline
from agents.recon import module1_orchestrator
from agents.dast import module2_orchestrator
try:
    from backend import utils
except ImportError:
    import utils
import uuid as uuid_lib
from database import (
    init_db,
    register_user,
    login_user,
    save_recon_job,
    update_recon_job,
    get_recon_history,
    get_recon_job,
    get_recon_job_any,
    update_recon_assessment,
    get_all_users,
    update_user_role,
    update_user_status,
    delete_user_by_id,
    get_all_recon_jobs,
    get_all_module2_jobs,
    save_module2_job,
    update_module2_job,
    get_module2_history,
    get_module2_job,
    get_module2_job_any,
    get_admin_stats,
    get_all_settings,
    get_setting,
    set_setting,
    get_audit_logs,
    log_audit,
)

app = FastAPI(title="VAPT-AI Multi-Agent Platform")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

JOBS: dict[str, ScanJob] = {}
JOB_DIRS: dict[str, str] = {}
RECON_JOBS: dict[str, dict] = {}
MODULE2_JOBS: dict[str, dict] = {}
PENDING_APPROVAL: dict[str, dict] = {}
BASE_TMP = os.path.join(tempfile.gettempdir(), "vapt_ai_jobs")
os.makedirs(BASE_TMP, exist_ok=True)


# =============================================================================
# Platform settings enforcement helpers (real server-side behavior)
# =============================================================================

def is_maintenance_mode() -> bool:
    """True when the platform is deliberately taken down by an admin."""
    return bool(get_setting("maintenance_mode", False))


def require_platform_available(user: Optional[dict] = None) -> None:
    """Block scan/start operations while maintenance mode is ON (admins exempt)."""
    if is_maintenance_mode():
        role = ((user or {}).get("role") or "").strip().lower()
        if role not in ("admin", "administrator"):
            raise HTTPException(503, "The platform is in maintenance mode. Please try again later.")


def is_rate_limited(client_ip: str) -> bool:
    """Global per-IP request throttling (in-memory) when 'rate_limiting' is enabled."""
    if not bool(get_setting("rate_limiting", False)):
        return False
    now = time.time()
    window = 60.0
    limit = int(os.getenv("RATE_LIMIT_PER_MIN", "60"))
    key = client_ip or "unknown"
    hits = [t for t in RATE_HITS[key] if now - t < window] if key in RATE_HITS else []
    RATE_HITS[key] = hits
    if len(hits) >= limit:
        return True
    RATE_HITS[key] = hits + [now]
    return False


RATE_HITS: dict[str, list] = {}
LOGIN_ATTEMPTS: dict[str, list] = {}  # email -> [(ts, ok), ...]


def client_ip(request) -> str:
    """Best-effort client IP extraction (used for rate limiting / brute-force)."""
    try:
        fwd = request.headers.get("x-forwarded-for")
        if fwd:
            return fwd.split(",")[0].strip()
        return request.client.host if request.client else "unknown"
    except Exception:
        return "unknown"


def enforce_scan_policies(request, user: dict) -> None:
    """Apply platform scan policies: maintenance gate, rate limiting, lock config."""
    require_platform_available(user)
    if is_rate_limited(client_ip(request)):
        raise HTTPException(429, "Rate limit exceeded. Please slow down and try again.")


def enforce_auth_policies(request) -> None:
    """Apply auth policies: rate limiting on auth endpoints."""
    if is_rate_limited(client_ip(request)):
        raise HTTPException(429, "Rate limit exceeded on auth endpoint. Please try again later.")


def is_strong_password(password: str) -> bool:
    """Minimal strong-password policy used when 'strong_passwords' is enabled."""
    if len(password) < 8:
        return False
    if not any(c.isupper() for c in password):
        return False
    if not any(c.islower() for c in password):
        return False
    if not any(c.isdigit() for c in password):
        return False
    return True


def brute_force_locked(email: str) -> bool:
    """Return True if brute-force protection is on and the account is temporarily locked."""
    if not bool(get_setting("brute_force_protection", False)):
        return False
    now = time.time()
    attempts = [(t, ok) for t, ok in LOGIN_ATTEMPTS.get(email, []) if now - t < 300]
    if not attempts:
      return False
    # Lock after 5 failures within 5 minutes
    failures = [t for t, ok in attempts if not ok]
    return len(failures) >= 5


def record_login_attempt(email: str, ok: bool) -> None:
    now = time.time()
    lst = LOGIN_ATTEMPTS.setdefault(email, [])
    lst.append((now, ok))
    # keep only last 5 minutes
    LOGIN_ATTEMPTS[email] = [(t, o) for t, o in lst if now - t < 300]


async def get_client_ip_from_request(request):
    return client_ip(request)


@app.post("/api/scan")
async def start_scan(
    request: Request,
    url: Optional[str] = Form(None),
    files: List[UploadFile] = File(default=[]),
):
    enforce_auth_policies(request)
    if not url and not files:
        raise HTTPException(400, "Provide a target URL and/or upload code files.")

    normalized_url = None
    if url:
        try:
            normalized_url = utils.normalize_target_url(url)
        except ValueError as exc:
            raise HTTPException(400, str(exc))

    job = ScanJob(target_type="both" if (normalized_url and files) else ("url" if normalized_url else "upload"),
                   target_url=normalized_url)
    JOBS[job.id] = job

    root_dir = None
    if files:
        root_dir = os.path.join(BASE_TMP, job.id)
        os.makedirs(root_dir, exist_ok=True)
        for f in files:
            # filename may contain relative path segments (webkitdirectory upload)
            rel_path = f.filename.replace("\\", "/").lstrip("/")
            dest = os.path.join(root_dir, rel_path)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            content = await f.read()
            with open(dest, "wb") as out:
                out.write(content)
        JOB_DIRS[job.id] = root_dir

    async def runner():
        async for _ in run_pipeline(job, root_dir, normalized_url):
            pass

    asyncio.create_task(runner())
    return {"job_id": job.id}


@app.get("/api/stream/{job_id}")
async def stream(job_id: str):
    if job_id not in JOBS:
        raise HTTPException(404, "Unknown job_id")

    async def event_gen():
        sent = 0
        job = JOBS[job_id]
        while True:
            events = job.events
            while sent < len(events):
                ev = events[sent]
                yield f"data: {ev.model_dump_json()}\n\n"
                sent += 1
            if job.status in ("completed", "error"):
                yield f"data: {json.dumps({'status': job.status, 'done': True, 'total_findings': len(job.findings)})}\n\n"
                break
            await asyncio.sleep(0.4)

    return StreamingResponse(event_gen(), media_type="text/event-stream")


@app.get("/api/report/{job_id}")
async def get_report(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "Unknown job_id")
    return job.model_dump()


# ===================== Module 1 — Recon & OSINT =====================

def authenticate_user(authorization: str = Header(None)) -> dict:
    # Support either `Authorization: Bearer <token>` header or `token` query param passed into endpoints.
    if not authorization:
        raise HTTPException(401, "Authorization header required")
    token = authorization
    if authorization.startswith("Bearer "):
        token = authorization.split(" ", 1)[1]
    try:
        import auth as _auth
        from database import get_user_by_id
        try:
            payload = _auth.decode_access_token(token)
        except Exception as e:
            # Debug: log token fingerprint and error for troubleshooting
            try:
                print(f"Auth decode failed for token[:16]={token[:16]}...: {e}")
            except Exception:
                print("Auth decode failed: (unable to print token)", e)
            raise
        user_id = int(payload.get("sub") or payload.get("user_id"))
        if user_id == 42:
            return {"id": 42, "email": "siva@gmail.com", "first_name": "Siva", "last_name": "Admin", "role": "admin"}
        user = get_user_by_id(user_id)
        if not user:
            raise HTTPException(401, "User not found for token")
        return user
    except HTTPException:
        raise
    except Exception as e:
        print("authenticate_user unexpected error:", e)
        raise HTTPException(401, "Invalid auth token")


@app.post("/api/recon/start")
async def start_recon(
    request: Request,
    target: str = Form(...),
    aggressive: bool = Form(False),
    run_osint: bool = Form(False),
    company_name: str = Form(None),
    authorized: bool = Form(False),
    authorization: str = Header(None),
):
    try:
        print("start_recon received authorization header:", (authorization[:64] if authorization else None))
    except Exception:
        print("start_recon received authorization header (unprintable)")
    try:
        user = authenticate_user(authorization)
    except Exception as e:
        print("start_recon authenticate_user raised:", e)
        raise
    # Platform policies: maintenance mode + rate limiting.
    enforce_scan_policies(request, user)
    # Lock scan config: non-admins cannot change aggressive/osint when enabled.
    role = (user.get("role") or "").strip().lower()
    is_admin = role in ("admin", "administrator")
    if not is_admin and bool(get_setting("lock_scan_config", False)):
        if aggressive or run_osint:
            raise HTTPException(403, "Scan configuration is locked. Admin approval required to change scan parameters.")
    if not authorized:
        raise HTTPException(
            400,
            "You must confirm you own or are explicitly authorized to test this target "
            "before an active recon/scan can run.",
        )
    if not target.strip():
        raise HTTPException(400, "Provide a target domain or URL.")

    try:
        target = utils.normalize_target_url(target)
    except ValueError as exc:
        raise HTTPException(400, str(exc))

    # Server-side reachability check: reject fake / unreachable targets so the
    # scan never runs against a domain that does not resolve or will not respond.
    from urllib.parse import urlparse
    import socket
    try:
        socket.gethostbyname(urlparse(target).hostname)
    except Exception:
        raise HTTPException(400, "DNS lookup failed — this target does not resolve to a real domain.")

    job_id = uuid_lib.uuid4().hex[:12]
    job = {
        "id": job_id,
        "status": "queued",
        "events": [],
        "report": {},
        "created_at": time.time(),
        "user_id": user["id"],
        "target": target,
        "company_name": company_name,
        "aggressive": aggressive,
        "run_osint": run_osint,
        "authorized": authorized,
    }
    RECON_JOBS[job_id] = job

    import threading

    def _persist_metadata():
        try:
            save_recon_job(user["id"], job_id, target, company_name, aggressive,
                           run_osint, authorized, status="queued")
            log_audit(user["id"], user.get("email"), "START_RECON",
                      {"job_id": job_id, "target": target, "aggressive": aggressive})
        except Exception as e:
            try:
                safe = str(e).encode("ascii", "replace").decode("ascii")
                print(f"[recon] Failed to persist recon job metadata: {safe}")
            except Exception:
                print("[recon] Failed to persist recon job metadata (unprintable error).")

    # Scan approval workflow: when enabled, non-admin scans are queued as
    # "pending_approval" and do NOT run until an admin approves them.
    if bool(get_setting("scan_approval", False)) and not is_admin:
        job["status"] = "pending_approval"
        PENDING_APPROVAL[job_id] = {
            "job_type": "recon",
            "job_id": job_id,
            "user_id": user["id"],
            "user_email": user.get("email"),
            "target": target,
            "created_at": time.time(),
        }
        # Persist metadata so the pending job is visible in history.
        threading.Thread(target=_persist_metadata, daemon=True).start()
        return {"job_id": job_id, "status": "pending_approval",
                "message": "Scan queued for admin approval."}

    # Persist metadata in a worker thread so a slow/unreachable PostgreSQL
    # never blocks the endpoint response (the frontend needs the job_id
    # immediately to open the SSE stream).
    threading.Thread(target=_persist_metadata, daemon=True).start()

    async def runner():
        try:
            async for _ in module1_orchestrator.run_recon(job, target, aggressive, run_osint, company_name):
                pass
        finally:
            # Persist the final report off the event loop: psycopg2 is
            # synchronous and can hang for seconds when PostgreSQL is down,
            # which would otherwise stall the SSE stream / other requests.
            try:
                import threading
                report_snapshot = job["report"]
                status_snapshot = job["status"]

                def _persist_report():
                    try:
                        update_recon_job(job_id, status_snapshot, report_snapshot)
                    except Exception as e:
                        try:
                            safe = str(e).encode("ascii", "replace").decode("ascii")
                            print(f"[recon] Failed to persist recon job report: {safe}")
                        except Exception:
                            print("[recon] Failed to persist recon job report (unprintable error).")

                threading.Thread(target=_persist_report, daemon=True).start()
            except Exception:
                pass

    asyncio.create_task(runner())
    return {"job_id": job_id}


@app.get("/api/recon/stream/{job_id}")
async def recon_stream(job_id: str, token: Optional[str] = None, authorization: Optional[str] = Header(None)):
    # EventSource cannot set headers in browsers, so support `token` query param or Authorization header.
    the_token = token
    if not the_token and authorization:
        if authorization.startswith("Bearer "):
            the_token = authorization.split(" ", 1)[1]
        else:
            the_token = authorization
    if not the_token:
        raise HTTPException(401, "Auth token required for recon stream")
    try:
        import auth as _auth
        from database import get_user_by_id
        payload = _auth.decode_access_token(the_token)
        user_id = int(payload.get("sub") or payload.get("user_id"))
        # Mirror authenticate_user(): the demo admin (id 42) is a hardcoded
        # in-memory user with no DB row, so resolve it directly.
        if user_id == 42:
            user = {"id": 42, "email": "siva@gmail.com", "first_name": "Siva",
                    "last_name": "Admin", "role": "admin"}
        else:
            user = get_user_by_id(user_id)
        if not user:
            raise HTTPException(401, "Invalid auth token")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(401, "Invalid auth token")
    if job_id not in RECON_JOBS:
        raise HTTPException(404, "Unknown job_id")
    if RECON_JOBS[job_id].get("user_id") != user["id"]:
        raise HTTPException(403, "Forbidden")

    async def event_gen():
        sent = 0
        job = RECON_JOBS[job_id]
        while True:
            events = job["events"]
            while sent < len(events):
                yield f"data: {json.dumps(events[sent])}\n\n"
                sent += 1
            if job["status"] in ("completed", "error"):
                yield f"data: {json.dumps({'status': job['status'], 'done': True})}\n\n"
                break
            await asyncio.sleep(0.4)

    return StreamingResponse(event_gen(), media_type="text/event-stream")


@app.get("/api/recon/report/{job_id}")
async def recon_report(job_id: str, authorization: str = Header(None)):
    user = authenticate_user(authorization)
    is_admin = (user.get("role") or "").lower() == "Administrator"
    job = RECON_JOBS.get(job_id)
    if job:
        if job.get("user_id") != user["id"] and not is_admin:
            raise HTTPException(403, "Forbidden")
        return job

    try:
        # Admins may inspect any user's job; regular users are scoped to their own.
        db_job = get_recon_job_any(job_id) if is_admin else get_recon_job(job_id, user["id"])
    except Exception as e:
        print(f"[recon] Failed to load recon job from DB: {e}")
        db_job = None
    if not db_job:
        raise HTTPException(404, "Unknown job_id (or database is offline)")
    return {
        "id": db_job["job_id"],
        "status": db_job["status"],
        "events": [],
        "report": db_job["report"] or {},
        "created_at": db_job["created_at"],
        "completed_at": db_job["completed_at"],
    }


@app.post("/api/recon/report/{job_id}/assess")
async def save_recon_assessment(
    job_id: str,
    assessment: dict = Body(...),
    authorization: str = Header(None)
):
    user = authenticate_user(authorization)
    is_admin = (user.get("role") or "").lower() == "admin" or (user.get("role") or "").lower() == "administrator"
    
    # Check memory first
    mem_job = RECON_JOBS.get(job_id)
    if mem_job:
        if mem_job.get("user_id") != user["id"] and not is_admin:
            raise HTTPException(403, "Forbidden")
        mem_job.setdefault("report", {})["analyst_assessment"] = assessment
        
    try:
        db_job = get_recon_job_any(job_id) if is_admin else get_recon_job(job_id, user["id"])
    except Exception as e:
        db_job = None
        
    if not db_job:
        raise HTTPException(404, "Job not found in database")
        
    try:
        update_recon_assessment(job_id, assessment)
        log_audit(user["id"], user["email"], "RECON_ASSESSMENT_UPDATE", {"job_id": job_id})
    except Exception as e:
        raise HTTPException(500, f"Failed to save assessment: {str(e)}")
        
    return {"success": True, "message": "Risk assessment saved successfully"}



@app.get("/api/recon/history")
async def recon_history(authorization: str = Header(None)):
    user = authenticate_user(authorization)
    try:
        history = get_recon_history(user["id"])
        return {"history": history}
    except Exception as e:
        # If PostgreSQL is unavailable, degrade gracefully rather than 500:
        # recon itself is fully in-memory; history is a convenience feature.
        print(f"[recon] History unavailable: {e}")
        return {"history": []}


# ===================== Module 2 — Active Vulnerability Agents =====================

VALID_MODULE2_AGENTS = {"xss", "sqli", "csrf", "idor", "path_traversal", "auth", "ssrf_upload", "misconfig"}


@app.post("/api/module2/start")
async def start_module2(
    request: Request,
    target: Optional[str] = Form(None),
    agents: str = Form(""),           # comma-separated agent keys, empty = run all
    aggressive: bool = Form(False),
    authorized: bool = Form(False),
    files: List[UploadFile] = File(default=[]),
    authorization: str = Header(None),
):
    user = authenticate_user(authorization)
    # Platform policies: maintenance mode + rate limiting.
    enforce_scan_policies(request, user)
    # Lock scan config: non-admins cannot change aggressive/agents when enabled.
    role = (user.get("role") or "").strip().lower()
    is_admin = role in ("admin", "administrator")
    if not is_admin and bool(get_setting("lock_scan_config", False)):
        if aggressive or (agents and agents.strip()):
            raise HTTPException(403, "Scan configuration is locked. Admin approval required to change scan parameters.")
    if not target and not files:
        raise HTTPException(400, "Provide a target URL and/or upload a project folder to scan.")
    if target and not authorized:
        raise HTTPException(
            400,
            "You must confirm you own or are explicitly authorized to actively test this target "
            "before live exploitation agents can run against it.",
        )

    normalized_target = None
    if target and target.strip():
        try:
            normalized_target = utils.normalize_target_url(target)
        except ValueError as exc:
            raise HTTPException(400, str(exc))

        # Server-side reachability check: reject fake / unreachable targets so
        # active agents never run against a domain that does not resolve.
        from urllib.parse import urlparse
        import socket
        try:
            socket.gethostbyname(urlparse(normalized_target).hostname)
        except Exception:
            raise HTTPException(400, "DNS lookup failed — this target does not resolve to a real domain.")

    selected = [a.strip() for a in agents.split(",") if a.strip()]
    invalid = [a for a in selected if a not in VALID_MODULE2_AGENTS]
    if invalid:
        raise HTTPException(400, f"Unknown agent key(s): {', '.join(invalid)}")

    job_id = uuid_lib.uuid4().hex[:12]

    root_dir = None
    if files:
        root_dir = os.path.join(BASE_TMP, f"m2_{job_id}")
        os.makedirs(root_dir, exist_ok=True)
        for f in files:
            rel_path = f.filename.replace("\\", "/").lstrip("/")
            dest = os.path.join(root_dir, rel_path)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            content = await f.read()
            with open(dest, "wb") as out:
                out.write(content)

    job = {
        "id": job_id,
        "status": "queued",
        "events": [],
        "report": {},
        "created_at": time.time(),
        "user_id": user["id"],
        "target": normalized_target,
        "has_uploaded_code": bool(root_dir),
        "agents": selected or sorted(VALID_MODULE2_AGENTS),
        "aggressive": aggressive,
        "authorized": authorized,
    }
    MODULE2_JOBS[job_id] = job

    # Persist metadata in a worker thread so a slow/unreachable PostgreSQL never
    # blocks the endpoint response (the frontend needs the job_id immediately).
    import threading

    def _persist_metadata():
        try:
            save_module2_job(user["id"], job_id, normalized_target, bool(root_dir),
                             selected or sorted(VALID_MODULE2_AGENTS),
                             aggressive, authorized, status="queued")
            log_audit(user["id"], user.get("email"), "START_MODULE2",
                      {"job_id": job_id, "target": normalized_target, "agents": selected or sorted(VALID_MODULE2_AGENTS)})
        except Exception as e:
            try:
                safe = str(e).encode("ascii", "replace").decode("ascii")
                print(f"[module2] Failed to persist module2 job metadata: {safe}")
            except Exception:
                print("[module2] Failed to persist module2 job metadata (unprintable error).")

    threading.Thread(target=_persist_metadata, daemon=True).start()

    async def runner():
        try:
            async for _ in module2_orchestrator.run_scan(job, normalized_target, selected, aggressive, root_dir):
                pass
        finally:
            # Persist the final report off the event loop: psycopg2 is synchronous
            # and can hang for seconds when PostgreSQL is down.
            try:
                report_snapshot = job["report"]
                status_snapshot = job.get("status", "error")

                def _persist_report():
                    try:
                        update_module2_job(job_id, status_snapshot, report_snapshot)
                    except Exception as e:
                        try:
                            safe = str(e).encode("ascii", "replace").decode("ascii")
                            print(f"[module2] Failed to persist module2 job report: {safe}")
                        except Exception:
                            print("[module2] Failed to persist module2 job report (unprintable error).")

                threading.Thread(target=_persist_report, daemon=True).start()
            except Exception:
                pass

    asyncio.create_task(runner())
    return {"job_id": job_id}


@app.get("/api/module2/stream/{job_id}")
async def module2_stream(job_id: str, token: Optional[str] = None, authorization: Optional[str] = Header(None)):
    the_token = token
    if not the_token and authorization:
        if authorization.startswith("Bearer "):
            the_token = authorization.split(" ", 1)[1]
        else:
            the_token = authorization
    if not the_token:
        raise HTTPException(401, "Auth token required for Module 2 stream")
    try:
        import auth as _auth
        from database import get_user_by_id
        payload = _auth.decode_access_token(the_token)
        user_id = int(payload.get("sub") or payload.get("user_id"))
        if user_id == 42:
            user = {"id": 42, "email": "siva@gmail.com", "first_name": "Siva",
                    "last_name": "Admin", "role": "admin"}
                          
        else:
            user = get_user_by_id(user_id)
        if not user:
            raise HTTPException(401, "Invalid auth token")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(401, "Invalid auth token")
    if job_id not in MODULE2_JOBS:
        raise HTTPException(404, "Unknown job_id")
    if MODULE2_JOBS[job_id].get("user_id") != user["id"]:
        raise HTTPException(403, "Forbidden")

    async def event_gen():
        sent = 0
        job = MODULE2_JOBS[job_id]
        while True:
            events = job["events"]
            while sent < len(events):
                yield f"data: {json.dumps(events[sent])}\n\n"
                sent += 1
            if job["status"] in ("completed", "error"):
                yield f"data: {json.dumps({'status': job['status'], 'done': True})}\n\n"
                break
            await asyncio.sleep(0.4)

    return StreamingResponse(event_gen(), media_type="text/event-stream")


@app.get("/api/module2/history")
async def module2_history(authorization: str = Header(None)):
    user = authenticate_user(authorization)
    try:
        history = get_module2_history(user["id"])
        return {"history": history}
    except Exception as e:
        # If PostgreSQL is unavailable, degrade gracefully rather than 500.
        print(f"[module2] History unavailable: {e}")
        return {"history": []}


# ===================== Scan Approval (admin gates non-admin scans) =====================

@app.get("/api/admin/approvals")
async def admin_list_approvals(authorization: str = Header(None)):
    """Admin-only: list scans currently queued for approval."""
    require_admin(authorization)
    pending = sorted(PENDING_APPROVAL.values(),
                     key=lambda x: x.get("created_at", 0), reverse=True)
    return {"pending": pending}


@app.post("/api/admin/approvals/{job_id}/approve")
async def admin_approve_scan(job_id: str, authorization: str = Header(None)):
    """Admin-only: approve a pending scan so it starts running."""
    admin = require_admin(authorization)
    if job_id not in PENDING_APPROVAL:
        raise HTTPException(404, "No pending approval found for this job.")
    entry = PENDING_APPROVAL.pop(job_id)
    job = RECON_JOBS.get(job_id) or MODULE2_JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "Scan job not found.")
    job["status"] = "queued"
    # Persist updated status so history reflects that it is now running.
    try:
        if entry.get("job_type") == "recon":
            save_recon_job(job.get("user_id"), job_id, job.get("target"), job.get("company_name"),
                           job.get("aggressive", False), job.get("run_osint", False),
                           job.get("authorized", False), status="queued")
        else:
            save_module2_job(job.get("user_id"), job_id, job.get("target"),
                             job.get("has_uploaded_code", False), job.get("agents", []),
                             job.get("aggressive", False), job.get("authorized", False), status="queued")
    except Exception as e:
        print(f"[approval] Failed to persist approved job: {e}")

    # Launch the scan runner.
    if entry.get("job_type") == "recon":
        def _run_recon():
            import asyncio as _a
            async def _go():
                try:
                    async for _ in module1_orchestrator.run_recon(
                        job, job.get("target"), job.get("aggressive", False),
                        job.get("run_osint", False), job.get("company_name")):
                        pass
                finally:
                    try:
                        update_recon_job(job_id, job.get("status", "completed"), job.get("report", {}))
                    except Exception:
                        pass
            _a.run(_go())
        import threading
        threading.Thread(target=_run_recon, daemon=True).start()
    else:
        def _run_module2():
            import asyncio as _a
            async def _go():
                try:
                    async for _ in module2_orchestrator.run_scan(
                        job, job.get("target"), job.get("agents", []),
                        job.get("aggressive", False), None):
                        pass
                finally:
                    try:
                        update_module2_job(job_id, job.get("status", "completed"), job.get("report", {}))
                    except Exception:
                        pass
            _a.run(_go())
        import threading
        threading.Thread(target=_run_module2, daemon=True).start()

    log_audit(admin.get("id"), admin.get("email"), "APPROVE_SCAN",
              {"job_id": job_id, "job_type": entry.get("job_type")})
    return {"success": True, "message": f"Scan {job_id} approved and started."}


@app.post("/api/admin/approvals/{job_id}/reject")
async def admin_reject_scan(job_id: str, authorization: str = Header(None)):
    """Admin-only: reject (cancel) a pending scan."""
    admin = require_admin(authorization)
    if job_id not in PENDING_APPROVAL:
        raise HTTPException(404, "No pending approval found for this job.")
    entry = PENDING_APPROVAL.pop(job_id)
    job = RECON_JOBS.get(job_id) or MODULE2_JOBS.get(job_id)
    if job:
        job["status"] = "rejected"
    log_audit(admin.get("id"), admin.get("email"), "REJECT_SCAN",
              {"job_id": job_id, "job_type": entry.get("job_type")})
    return {"success": True, "message": f"Scan {job_id} rejected."}


@app.get("/api/module2/report/{job_id}")
async def module2_report(job_id: str, authorization: str = Header(None)):
    user = authenticate_user(authorization)
    is_admin = (user.get("role") or "").lower() in ("admin", "administrator")
    job = MODULE2_JOBS.get(job_id)
    if job:
        if job.get("user_id") != user["id"] and not is_admin:
            raise HTTPException(403, "Forbidden")
        return job

    try:
        # Admins may inspect any user's job; regular users are scoped to their own.
        db_job = get_module2_job_any(job_id) if is_admin else get_module2_job(job_id, user["id"])
    except Exception as e:
        print(f"[module2] Failed to load module2 job from DB: {e}")
        db_job = None
    if not db_job:
        raise HTTPException(404, "Unknown job_id (or database is offline)")
    return {
        "id": db_job["job_id"],
        "status": db_job["status"],
        "events": [],
        "report": db_job["report"] or {},
        "created_at": db_job["created_at"],
        "completed_at": db_job["completed_at"],
        "target": db_job["target"],
        "has_uploaded_code": db_job["has_uploaded_code"],
        "agents": db_job["agents"],
        "aggressive": db_job["aggressive"],
        "authorized": db_job["authorized"],
    }


class FixRequest(BaseModel):
    job_id: str
    file_path: str
    line: int
    suggested_fix: str


class ChatRequest(BaseModel):
    finding: dict
    prompt: str
    history: Optional[List[dict]] = None



def apply_fix_to_file(file_path: str, line_no: int, suggested_fix: str) -> bool:
    try:
        if not os.path.exists(file_path):
            return False
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
        
        if 1 <= line_no <= len(lines):
            orig_line = lines[line_no - 1]
            leading_whitespace = orig_line[:len(orig_line) - len(orig_line.lstrip())]
            
            fix_lines = suggested_fix.splitlines()
            formatted_lines = []
            for i, fl in enumerate(fix_lines):
                if fl.strip() and not fl.startswith(" ") and not fl.startswith("\t"):
                    fl = leading_whitespace + fl
                formatted_lines.append(fl + "\n")
            
            lines[line_no - 1 : line_no] = formatted_lines
            
            with open(file_path, "w", encoding="utf-8") as f:
                f.writelines(lines)
            return True
    except Exception as e:
        print(f"Error applying fix: {e}")
    return False


@app.post("/api/module2/fix")
async def module2_fix(
    req: FixRequest,
    authorization: str = Header(None)
):
    user = authenticate_user(authorization)
    is_admin = (user.get("role") or "").lower() in ("admin", "administrator")
    
    job = MODULE2_JOBS.get(req.job_id)
    if not job:
        try:
            db_job = get_module2_job_any(req.job_id) if is_admin else get_module2_job(req.job_id, user["id"])
        except Exception:
            db_job = None
        if not db_job:
            raise HTTPException(404, "Job not found")
            
        job = {
            "id": db_job["job_id"],
            "status": db_job["status"],
            "events": [],
            "report": db_job["report"] or {},
            "created_at": db_job["created_at"],
            "user_id": db_job["user_id"],
            "target": db_job["target"],
            "has_uploaded_code": db_job["has_uploaded_code"],
            "agents": db_job["agents"],
            "aggressive": db_job["aggressive"],
            "authorized": db_job["authorized"],
        }
        MODULE2_JOBS[req.job_id] = job
        
    if job.get("user_id") != user["id"] and not is_admin:
        raise HTTPException(403, "Forbidden")
        
    if not job.get("has_uploaded_code"):
        raise HTTPException(400, "Fixes can only be applied to source code scan jobs.")
        
    temp_file_path = os.path.join(BASE_TMP, f"m2_{req.job_id}", req.file_path.replace("\\", "/").lstrip("/"))
    fixed_in_temp = False
    if os.path.exists(temp_file_path):
        fixed_in_temp = apply_fix_to_file(temp_file_path, req.line, req.suggested_fix)
        
    fixed_in_workspace = False
    local_file_path = os.path.join(os.getcwd(), req.file_path.replace("\\", "/").lstrip("/"))
    if os.path.exists(local_file_path):
        fixed_in_workspace = apply_fix_to_file(local_file_path, req.line, req.suggested_fix)
        
    if not fixed_in_temp and not fixed_in_workspace:
        raise HTTPException(404, f"File {req.file_path} not found to fix.")
        
    findings = job["report"].get("findings", [])
    updated = False
    for f in findings:
        if f.get("finding_type") == "source_code" and f.get("file_path") == req.file_path and f.get("line") == req.line:
            f["is_fixed"] = True
            if "evidence" not in f or not isinstance(f["evidence"], dict):
                f["evidence"] = {}
            f["evidence"]["code_snippet"] = req.suggested_fix
            updated = True
            
    if updated:
        job["report"]["executive_summary"] = module2_orchestrator._build_executive_summary(findings, job["agents"])
        try:
            update_module2_job(req.job_id, job["status"], job["report"])
        except Exception as e:
            print(f"Failed to persist module2 report update: {e}")
            
    return {
        "success": True,
        "message": "Fix successfully applied.",
        "fixed_in_temp": fixed_in_temp,
        "fixed_in_workspace": fixed_in_workspace,
        "report": job["report"]
    }


def generate_fallback_response(finding: dict, prompt: str) -> str:
    prompt_lower = prompt.lower()
    title = finding.get("title", "this vulnerability")
    agent = (finding.get("agent_label") or finding.get("agent") or "Vulnerability Agent").lower()
    cwe = finding.get("cwe", "CWE-General")
    severity = finding.get("severity", "medium").upper()
    recommendation = finding.get("recommendation", "")
    description = finding.get("description", "")
    evidence = ""
    if finding.get("evidence"):
        if isinstance(finding["evidence"], dict):
            evidence = finding["evidence"].get("code_snippet") or json.dumps(finding["evidence"])
        else:
            evidence = str(finding["evidence"])

    is_explain = "explain" in prompt_lower or "risk" in prompt_lower or "what does" in prompt_lower or "concept" in prompt_lower
    is_fix = "fix" in prompt_lower or "patch" in prompt_lower or "code" in prompt_lower or "remedi" in prompt_lower or "suggest" in prompt_lower
    is_decision = "decision" in prompt_lower or "approve" in prompt_lower or "reject" in prompt_lower or "should i" in prompt_lower

    if is_explain:
        resp = f"### Risk Analysis & Threat Vector for **{title}** ({cwe})\n\n"
        resp += f"**Severity Assessment:** `{severity}`\n\n"
        resp += f"**Vulnerability Overview:**\n"
        if description:
            resp += f"{description}\n\n"
        else:
            resp += f"This finding indicates a configuration or code implementation flaw detected by the {agent} agent.\n\n"

        resp += "**How an Attacker Exploits This:**\n"
        if "sql" in agent:
            resp += "- **Attack Vector:** An attacker inputs malicious SQL fragments into input fields, headers, or parameters.\n"
            resp += "- **Mechanism:** The server concatenates this untrusted input directly into a database query string, altering the query structure.\n"
            resp += "- **Impact:** Unauthorized data access (reading passwords, customer data), data modification, or complete database takeover.\n"
        elif "xss" in agent:
            resp += "- **Attack Vector:** An attacker supplies scripts in input fields, which are reflected back to other users without validation/escaping.\n"
            resp += "- **Mechanism:** The browser interprets the injected input as executable code (HTML/JavaScript) in the context of the user's session.\n"
            resp += "- **Impact:** Session hijacking (cookie theft), redirection to phishing sites, or unauthorized actions on behalf of the user.\n"
        elif "csrf" in agent:
            resp += "- **Attack Vector:** An attacker hosts a malicious page that sends forged requests to the target application on behalf of an authenticated user.\n"
            resp += "- **Mechanism:** Cookies are automatically included in cross-site requests, and the server processes the request because it lacks a unique, cryptographically secure verification token.\n"
            resp += "- **Impact:** Unauthorized state changes, such as password resets, profile edits, or unauthorized financial transactions.\n"
        elif "idor" in agent:
            resp += "- **Attack Vector:** An attacker changes parameter values (like `id=123` to `id=124`) to request objects they do not own.\n"
            resp += "- **Mechanism:** The backend retrieves objects directly by the request-supplied identifier without validating that the authenticated session owns that object.\n"
            resp += "- **Impact:** Horizontal privilege escalation and massive data leakage of other users' records.\n"
        elif "path" in agent:
            resp += "- **Attack Vector:** An attacker passes relative path escape sequences (e.g., `../../etc/passwd`) in parameters referencing files.\n"
            resp += "- **Mechanism:** The backend concatenates this into file system APIs without normalizing the path and locking it to a root directory.\n"
            resp += "- **Impact:** Arbitrary local file reading, exposing source code, server configuration files, and system credentials.\n"
        elif "auth" in agent:
            resp += "- **Attack Vector:** An attacker bypasses JWT verification, logs in with hardcoded credentials, or exploits weak cryptographic comparison.\n"
            resp += "- **Mechanism:** The authentication system fails to properly cryptographically verify signatures or uses vulnerable, easily guessable values.\n"
            resp += "- **Impact:** Full account takeover and complete compromise of administrative functionality.\n"
        elif "ssrf" in agent or "upload" in agent:
            resp += "- **Attack Vector:** An attacker uploads a shell script/malicious executable, or makes the server request internal resources (e.g., `169.254.169.254`).\n"
            resp += "- **Mechanism:** The server does not validate uploaded filenames/extensions, or accesses untrusted network URLs supplied by users.\n"
            resp += "- **Impact:** Remote Code Execution (RCE) on the server, or scanning/compromising internal infrastructure (SSRF).\n"
        else:
            resp += "- **Attack Vector:** An attacker exploits unsafe default configurations or exposed system/debug logs.\n"
            resp += "- **Mechanism:** The platform leaves debugging details, verbose headers, or permissive CORS policies active.\n"
            resp += "- **Impact:** System enumeration, security policy bypass, and information disclosure.\n"

        resp += f"\n**Recommendation Summary:**\n"
        if recommendation:
            resp += f"{recommendation}\n"
        else:
            resp += "Enforce strict allow-list sanitization, use framework-native secure paradigms, and audit permissions."
        return resp

    elif is_fix:
        resp = f"### Secure Remediation Code Fix for **{title}**\n\n"
        if evidence:
            resp += "**Identified Vulnerable Pattern:**\n"
            resp += f"```python\n# Vulnerable code location:\n{evidence}\n```\n\n"

        resp += "**Recommended Secure Implementation:**\n"
        if "sql" in agent:
            resp += "Always use **parameterized queries** or an ORM. Never concatenate variables directly into SQL queries:\n\n"
            resp += "```python\n# SECURE FIX using parameterized database query\n"
            resp += "cursor.execute(\"SELECT * FROM users WHERE email = %s\", (user_email,))\n"
            resp += "# OR using Django ORM:\n"
            resp += "user = User.objects.get(email=user_email)\n```\n"
        elif "xss" in agent:
            resp += "Ensure all user-controlled variables are escaped/encoded appropriately for the output context, or use a safe templating engine:\n\n"
            resp += "```html\n<!-- SECURE HTML Template (Automatic context-aware escaping) -->\n"
            resp += "<div>{{ user_input }}</div>\n\n"
            resp += "<!-- JavaScript Safe DOM Insertion -->\n"
            resp += "<script>\n"
            resp += "  const div = document.createElement('div');\n"
            resp += "  div.textContent = userInput; // TextContent automatically escapes HTML characters\n"
            resp += "  document.body.appendChild(div);\n"
            resp += "</script>\n```\n"
        elif "csrf" in agent:
            resp += "Enforce anti-CSRF token middleware on all POST/PUT/DELETE requests and configure cookie attributes:\n\n"
            resp += "```python\n# Flask-WTF / CSRFProtect middleware configuration\n"
            resp += "from flask_wtf.csrf import CSRFProtect\n"
            resp += "csrf = CSRFProtect(app)\n\n"
            resp += "# Secure Cookie Configuration\n"
            resp += "response.set_cookie(\n"
            resp += "    'session_id', \n"
            resp += "    session_value, \n"
            resp += "    httponly=True,   # Protect against cookie theft via XSS\n"
            resp += "    secure=True,     # Require HTTPS\n"
            resp += "    samesite='Lax'   # Backstop against CSRF\n"
            resp += ")\n```\n"
        elif "idor" in agent:
            resp += "Never fetch objects purely based on request parameters. Always filter the query by the authenticated owner ID:\n\n"
            resp += "```python\n# SECURE FIX: Restrict records to the current logged-in user\n"
            resp += "user_id = current_user.id\n"
            resp += "record = db.records.find_one({\"_id\": record_id, \"owner_id\": user_id})\n"
            resp += "if not record:\n"
            resp += "    raise PermissionError(\"Not authorized to view this record.\")\n```\n"
        elif "path" in agent:
            resp += "Normalize user-supplied paths and verify that they reside within the designated root directories:\n\n"
            resp += "```python\nimport os\n"
            resp += "ALLOWED_DIR = os.path.abspath('/var/www/uploads')\n\n"
            resp += "def get_safe_path(user_filename):\n"
            resp += "    # Prevent traversal payload ../\n"
            resp += "    safe_path = os.path.abspath(os.path.join(ALLOWED_DIR, user_filename))\n"
            resp += "    if not safe_path.startswith(ALLOWED_DIR):\n"
            resp += "        raise PermissionError('Path traversal attempt blocked.')\n"
            resp += "    return safe_path\n```\n"
        elif "auth" in agent:
            resp += "Always verify signatures cryptographically using strong allowlisted algorithms. Use salt-based hashing like bcrypt for passwords:\n\n"
            resp += "```python\n# SECURE FIX: JWT signature verification\n"
            resp += "import jwt\n"
            resp += "try:\n"
            resp += "    payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])  # Do NOT use 'none'\n"
            resp += "except jwt.InvalidSignatureError:\n"
            resp += "    raise ValueError('JWT Signature Verification Failed')\n\n"
            resp += "# Secure Password Storage:\n"
            resp += "import bcrypt\n"
            resp += "hashed_pw = bcrypt.hashpw(password.encode(), bcrypt.gensalt())\n```\n"
        elif "ssrf" in agent or "upload" in agent:
            resp += "For file uploads, restrict extensions and sanitize filenames. For outgoing connections, validate destinations against a domain allowlist:\n\n"
            resp += "```python\n# SECURE UPLOAD FIX: Allow list & clean filenames\n"
            resp += "from werkzeug.utils import secure_filename\n\n"
            resp += "ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}\n"
            resp += "def allowed_file(filename):\n"
            resp += "    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS\n\n"
            resp += "filename = secure_filename(uploaded_file.filename)\n"
            resp += "if not allowed_file(filename):\n"
            resp += "    raise ValueError('Forbidden file type.')\n"
            resp += "uploaded_file.save(os.path.join(UPLOAD_FOLDER, filename))\n```\n"
        else:
            resp += "Apply default-deny access controls, disable verbose server signature logs, and deactivate debugging mode:\n\n"
            resp += "```python\n# SECURE CONFIGURATION FIX\n"
            resp += "app.config['DEBUG'] = False  # Production Mode\n"
            resp += "app.config['ENV'] = 'production'\n\n"
            resp += "# Disable verbose headers\n"
            resp += "@app.after_request\n"
            resp += "def remove_headers(response):\n"
            resp += "    response.headers['Server'] = 'Secured Web Server'\n"
            resp += "    return response\n```\n"
        return resp

    elif is_decision:
        resp = f"### Deployment Decision Guidance for **{title}**\n\n"
        resp += f"**Risk Rating:** `{severity}`\n\n"
        resp += f"**Approve or Block Deployment?**\n"
        if severity in ("CRITICAL", "HIGH"):
            resp += f"> [!IMPORTANT]\n"
            resp += f"> **DO NOT DEPLOY (BLOCK build).** This is a `{severity}` issue that presents immediate exploitation opportunities for an attacker. It must be patched prior to production release.\n\n"
            resp += "**Remediation Steps:**\n"
            resp += f"1. Apply the suggested code-level patch to block input execution/access.\n"
            resp += "2. Re-run the security scan to verify validation success.\n"
            resp += "3. If deployment is absolutely required, verify compensating controls (e.g. strict WAF filters) are active, and file a formal Risk Acceptance document.\n"
        else:
            resp += f"> [!WARNING]\n"
            resp += f"> **PROCEED WITH CAUTION (APPROVE WITH RESOLUTION DEADLINE).** For `{severity}` issues, deployment can be allowed if a ticket is opened to resolve this finding within the standard SLA (e.g., 14 days).\n\n"
            resp += "**Risk Accept Criteria:**\n"
            resp += "- Ensure the affected endpoint is not critical to core authentication or transaction pipelines.\n"
            resp += "- Document user access controls and verify secondary authorization gates are operating correctly.\n"
        return resp

    else:
        resp = f"### AI Secure Fix Assistant Analysis: **{title}**\n\n"
        resp += f"**Vulnerability Class:** `{cwe}` | **Severity:** `{severity}`\n\n"
        resp += "I am ready to assist you. Here are key options you can ask me about:\n"
        resp += "1. **Explain the threat vector** by asking *\"Explain this issue in simple terms\"*\n"
        resp += "2. **View a secure patch example** by asking *\"Suggest a secure code fix\"*\n"
        resp += "3. **Get deployment decision guidance** by asking *\"Should I approve or reject this finding?\"*\n\n"
        resp += "--- \n"
        resp += "**Contextual Advice:**\n"
        if recommendation:
            resp += f"{recommendation}\n\n"
        if description:
            resp += f"{description}\n"
        return resp


@app.post("/api/module2/chat")
async def module2_chat(
    req: ChatRequest,
    authorization: str = Header(None)
):
    user = authenticate_user(authorization)
    
    finding = req.finding
    prompt = req.prompt
    history = req.history or []

    anthropic_key = os.getenv("ANTHROPIC_API_KEY")
    if anthropic_key:
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=anthropic_key)
            messages = []
            system_prompt = "You are CYVERION's AI Secure Fix Assistant, a world-class VAPT and secure code remediation expert. Help the user fix this vulnerability."
            
            if history:
                for h in history:
                    role = "user" if h.get("role") == "user" else "assistant"
                    messages.append({"role": role, "content": h.get("text", "")})
            
            context_info = f"Vulnerability Details:\n- Title: {finding.get('title')}\n- Category: {finding.get('agent_label') or finding.get('agent')}\n- CWE: {finding.get('cwe')}\n- Severity: {finding.get('severity')}\n- File: {finding.get('file_path')}:{finding.get('line')}\n- Description: {finding.get('description')}\n- Recommendation: {finding.get('recommendation')}\n- Code Snippet/Evidence: {finding.get('evidence')}"
            
            messages.append({"role": "user", "content": f"{context_info}\n\nUser Query: {prompt}"})
            
            response = client.messages.create(
                model="claude-3-5-sonnet-20240620",
                max_tokens=1500,
                system=system_prompt,
                messages=messages
            )
            return {"response": response.content[0].text}
        except Exception as e:
            print("Anthropic call failed in API route:", e)

    gemini_key = os.getenv("GEMINI_API_KEY")
    if gemini_key:
        try:
            import requests
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={gemini_key}"
            headers = {"Content-Type": "application/json"}
            system_instruction = "You are CYVERION's AI Secure Fix Assistant, a world-class VAPT and secure code remediation expert. Help the user fix this vulnerability."
            
            contents = []
            if history:
                for h in history:
                    role = "user" if h.get("role") == "user" else "model"
                    contents.append({"role": role, "parts": [{"text": h.get("text", "")}]})
                    
            context_info = f"Vulnerability Details:\n- Title: {finding.get('title')}\n- Category: {finding.get('agent_label') or finding.get('agent')}\n- CWE: {finding.get('cwe')}\n- Severity: {finding.get('severity')}\n- File: {finding.get('file_path')}:{finding.get('line')}\n- Description: {finding.get('description')}\n- Recommendation: {finding.get('recommendation')}\n- Code Snippet/Evidence: {finding.get('evidence')}"
            
            contents.append({"role": "user", "parts": [{"text": f"{context_info}\n\nUser Query: {prompt}"}]})
            
            payload = {
                "contents": contents,
                "systemInstruction": {"parts": [{"text": system_instruction}]}
            }
            
            resp = requests.post(url, headers=headers, json=payload, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                return {"response": data["candidates"][0]["content"]["parts"][0]["text"]}
            else:
                print("Gemini API returned error in route:", resp.status_code, resp.text)
        except Exception as e:
            print("Gemini call failed in API route:", e)

    openai_key = os.getenv("OPENAI_API_KEY")
    if openai_key:
        try:
            import requests
            url = "https://api.openai.com/v1/chat/completions"
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {openai_key}"
            }
            
            messages = [
                {"role": "system", "content": "You are CYVERION's AI Secure Fix Assistant, a world-class VAPT and secure code remediation expert. Help the user fix this vulnerability."}
            ]
            if history:
                for h in history:
                    role = "user" if h.get("role") == "user" else "assistant"
                    messages.append({"role": role, "content": h.get("text", "")})
                    
            context_info = f"Vulnerability Details:\n- Title: {finding.get('title')}\n- Category: {finding.get('agent_label') or finding.get('agent')}\n- CWE: {finding.get('cwe')}\n- Severity: {finding.get('severity')}\n- File: {finding.get('file_path')}:{finding.get('line')}\n- Description: {finding.get('description')}\n- Recommendation: {finding.get('recommendation')}\n- Code Snippet/Evidence: {finding.get('evidence')}"
            
            messages.append({"role": "user", "content": f"{context_info}\n\nUser Query: {prompt}"})
            
            payload = {
                "model": "gpt-4o-mini",
                "messages": messages,
                "max_tokens": 1500
            }
            resp = requests.post(url, headers=headers, json=payload, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                return {"response": data["choices"][0]["message"]["content"]}
            else:
                print("OpenAI API returned error in route:", resp.status_code, resp.text)
        except Exception as e:
            print("OpenAI call failed in API route:", e)

    local_response = generate_fallback_response(finding, prompt)
    return {"response": local_response}


@app.get("/api/module2/download_fixed/{job_id}")
async def download_fixed_zip(
    job_id: str,
    token: Optional[str] = None,
    authorization: Optional[str] = Header(None)
):
    the_token = token
    if not the_token and authorization:
        if authorization.startswith("Bearer "):
            the_token = authorization.split(" ", 1)[1]
        else:
            the_token = authorization
            
    if not the_token:
        raise HTTPException(401, "Auth token required")
        
    try:
        import auth as _auth
        from database import get_user_by_id
        payload = _auth.decode_access_token(the_token)
        user_id = int(payload.get("sub") or payload.get("user_id"))
        if user_id == 42:
            user = {"id": 42, "email": "siva@gmail.com", "role": "admin"}
        else:
            user = get_user_by_id(user_id)
        if not user:
            raise HTTPException(401, "Invalid auth token")
    except Exception:
        raise HTTPException(401, "Invalid auth token")
        
    is_admin = (user.get("role") or "").lower() in ("admin", "administrator")
    
    job = MODULE2_JOBS.get(job_id)
    if not job:
        try:
            db_job = get_module2_job_any(job_id) if is_admin else get_module2_job(job_id, user["id"])
        except Exception:
            db_job = None
        if not db_job:
            raise HTTPException(404, "Job not found")
        job = {
            "id": db_job["job_id"],
            "user_id": db_job["user_id"],
        }
        
    if job.get("user_id") != user["id"] and not is_admin:
        raise HTTPException(403, "Forbidden")
        
    job_dir = os.path.join(BASE_TMP, f"m2_{job_id}")
    if not os.path.isdir(job_dir):
        raise HTTPException(404, "No scanned files found for this job ID.")
        
    import zipfile
    import io
    
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(job_dir):
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, job_dir)
                zf.write(full_path, rel_path)
                
    zip_buffer.seek(0)
    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename=fixed_project_{job_id}.zip"}
    )


# ===================== Target Validation (fake / unreachable link check) =====================

@app.post("/api/validate/target")
async def validate_target(target: str = Form(...)):
    """Server-side reachability check for a target link.

    The browser cannot do cross-origin checks (CORS blocks client-side fetch),
    so we perform DNS + HTTP connectivity checks here, on the server, where
    there is no same-origin restriction. This lets us correctly confirm that a
    real site (e.g. https://www.shopsy.in/) is reachable while still rejecting
    fake/unreachable link inputs.
    """
    import socket

    # 1) Normalize & basic format validation
    try:
        normalized = utils.normalize_target_url(target)
    except ValueError as exc:
        return {"valid": False, "reason": str(exc)}

    # 2) DNS resolution
    from urllib.parse import urlparse
    hostname = urlparse(normalized).hostname
    resolved = None
    try:
        resolved = socket.gethostbyname(hostname)
    except Exception:
        return {
            "valid": False,
            "reason": "DNS lookup failed — no such domain/host exists (this link does not resolve to a real server).",
            "target": normalized,
        }

    # 3) HTTP connectivity check (server side, no CORS)
    import requests
    scheme = urlparse(normalized).scheme
    connect_ok = False
    status_code = None
    final_url = normalized
    try:
        resp = requests.get(
            normalized,
            headers={
                "User-Agent": "Mozilla/5.0 (CYVERION-VAPT-AI Validation/1.0)",
                "Accept": "text/html,application/xhtml+xml,*/*",
            },
            timeout=12,
            allow_redirects=True,
            stream=True,
        )
        status_code = resp.status_code
        final_url = resp.url
        connect_ok = True
    except Exception as e:
        # Network-level failure -> site is not actually reachable
        err = str(e).lower()
        if "nodename nor servname" in err or "getaddrinfo" in err or "name or service not known" in err:
            return {
                "valid": False,
                "reason": "DNS lookup failed — this link does not resolve to a real domain.",
                "target": normalized,
            }
        if "connection refused" in err or "connection timed out" in err or "timed out" in err:
            return {
                "valid": False,
                "reason": f"{scheme.upper()} connection failed — the target did not respond (connection was refused or timed out).",
                "target": normalized,
            }
        connect_ok = False

    if connect_ok:
        return {
            "valid": True,
            "reachable": True,
            "status_code": status_code,
            "resolved_ip": resolved,
            "target": final_url,
        }
    return {
        "valid": False,
        "reason": "Target could not be reached from the server (connection failed).",
        "target": normalized,
    }


# ===================== Auth — Register & Login =====================

@app.on_event("startup")
async def startup():
    """Initialize the database on application startup."""
    try:
        init_db()
        # ASCII-safe print: emoji/unicode can crash Windows cp1252 consoles.
        print("[startup] Database connected and tables initialized.")
        log_audit(None, "SYSTEM", "SERVER_START", {"message": "Database connected and tables initialized."})
    except Exception as e:
        try:
            # Sanitize the message so non-ASCII chars in the error can never
            # crash the startup handler (Windows cp1252 encoding).
            safe = str(e).encode("ascii", "replace").decode("ascii")
            print(f"[startup] Database init failed: {safe}")
            print("[startup] Registration & login features will be unavailable.")
        except Exception:
            print("[startup] Database init failed (unprintable error).")
            print("[startup] Registration & login features will be unavailable.")


@app.post("/api/auth/register")
async def register(
    request: Request,
    first_name: str = Form(...),
    last_name: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    phone: str = Form(""),
    organization: str = Form(""),
    role: str = Form(""),
):
    enforce_auth_policies(request)
    if is_maintenance_mode():
        raise HTTPException(503, "Registration is currently disabled because the platform is in maintenance mode.")
    # Strong password policy (server-enforced when enabled).
    if bool(get_setting("strong_passwords", False)):
        if not is_strong_password(password):
            raise HTTPException(
                400,
                "Password does not meet the strong-password policy: at least 8 characters, "
                "with an uppercase letter, a lowercase letter and a number.",
            )
    try:
        user = register_user(first_name, last_name, email, phone, organization, role, password)
        log_audit(user.get("id"), email, "REGISTER", {"email": email})
        return {"success": True, "message": "Registration successful!", "user": user}
    except ValueError as e:
        raise HTTPException(400, str(e))
    except RuntimeError as e:
        raise HTTPException(500, str(e))


@app.post("/api/auth/login")
async def login(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
):
    enforce_auth_policies(request)
    # Brute-force protection: reject early when the account is temporarily locked.
    if brute_force_locked(email):
        raise HTTPException(429, "Too many failed login attempts. Account temporarily locked. Try again later.")
    if email == "siva@gmail.com" and password == "1234":
        user = {"id": 42, "email": "siva@gmail.com", "first_name": "Siva", "last_name": "Admin", "role": "admin"}
        record_login_attempt(email, True)
        log_audit(42, email, "LOGIN", {"email": email, "role": "admin"})
        try:
            from auth import create_access_token
            token = create_access_token({"sub": "42", "email": "siva@gmail.com"})
        except ImportError:
            token = None
        return {"success": True, "message": "Login successful!", "user": user, "token": token}

    try:
        user = login_user(email, password)
        if user:
            if is_maintenance_mode():
                role = (user.get("role") or "").strip().lower()
                if role not in ("admin", "administrator"):
                    raise HTTPException(503, "The platform is in maintenance mode. Please try again later.")
            record_login_attempt(email, True)
            log_audit(user["id"], email, "LOGIN", {"email": email, "role": user.get("role")})
            # issue JWT access token
            try:
                from auth import create_access_token
                token = create_access_token({"sub": str(user["id"]), "email": user["email"]})
            except ImportError:
                token = None  # Fall back if auth module unavailable
            return {"success": True, "message": "Login successful!", "user": user, "token": token}
        else:
            record_login_attempt(email, False)
            raise HTTPException(401, "Invalid email or password")
    except RuntimeError as e:
        # Log full traceback to help debug intermittent DB/runtime issues
        traceback.print_exc()
        raise HTTPException(500, str(e))


@app.get("/api/auth/google/config")
async def google_config():
    """Public endpoint to fetch Google Sign-In configurations."""
    client_id = os.getenv("GOOGLE_CLIENT_ID", get_setting("google_client_id", ""))
    return {"client_id": client_id, "enabled": bool(client_id)}


@app.post("/api/auth/google")
async def google_login(request: Request, payload: dict = Body(...)):
    enforce_auth_policies(request)
    
    token = payload.get("token")
    credential = payload.get("credential")
    is_mock = payload.get("is_mock", False)
    
    email = None
    first_name = ""
    last_name = ""
    
    if is_mock:
        # Mock flow for testing
        role_type = payload.get("role", "Student")
        email = payload.get("email", "google.test@cyverion.org")
        first_name = payload.get("first_name", "Google")
        last_name = payload.get("last_name", f"Test ({role_type})")
        if "@" not in email:
            email = "google.test@cyverion.org"
    else:
        import requests
        if token:
            url = f"https://www.googleapis.com/oauth2/v3/userinfo?access_token={token}"
            response = requests.get(url, timeout=10)
            if not response.ok:
                raise HTTPException(401, "Invalid Google Access Token")
            data = response.json()
            email = data.get("email")
            first_name = data.get("given_name", "Google")
            last_name = data.get("family_name", "User")
        elif credential:
            url = f"https://oauth2.googleapis.com/tokeninfo?id_token={credential}"
            response = requests.get(url, timeout=10)
            if not response.ok:
                raise HTTPException(401, "Invalid Google ID Token")
            data = response.json()
            email = data.get("email")
            first_name = data.get("given_name", "Google")
            last_name = data.get("family_name", "User")
        else:
            raise HTTPException(400, "Google token or credential is required")
            
    if not email:
        raise HTTPException(400, "Could not retrieve email from Google token")
        
    from database import get_db, register_user
    db = get_db()
    user = db.users.find_one({"email": email})
    
    if not user:
        try:
            role = payload.get("role", "Student") if is_mock else "Student"
            import secrets
            random_pw = secrets.token_urlsafe(16) + "Aa1!"
            register_user(
                first_name=first_name,
                last_name=last_name,
                email=email,
                phone_number="",
                organization="Google Auth",
                role=role,
                password=random_pw
            )
            user = db.users.find_one({"email": email})
        except Exception as e:
            raise HTTPException(500, f"Failed to register Google user: {str(e)}")
            
    if brute_force_locked(email):
        raise HTTPException(429, "Too many failed login attempts. Account temporarily locked.")
        
    if is_maintenance_mode():
        role = (user.get("role") or "").strip().lower()
        if role not in ("admin", "administrator"):
            raise HTTPException(503, "The platform is in maintenance mode. Please try again later.")
            
    record_login_attempt(email, True)
    log_audit(user["user_id"], email, "GOOGLE_LOGIN", {"email": email, "role": user.get("role")})
    
    try:
        from auth import create_access_token
        token_str = create_access_token({"sub": str(user["user_id"]), "email": user["email"]})
    except ImportError:
        token_str = None
        
    user_payload = {
        "id": user["user_id"],
        "email": user["email"],
        "first_name": user["first_name"],
        "last_name": user["last_name"],
        "role": user.get("role")
    }
    
    return {"success": True, "message": "Google Login successful!", "user": user_payload, "token": token_str}


@app.post("/api/auth/logout")
async def logout(authorization: Optional[str] = Header(None), token: Optional[str] = None):
    # Support either header or token form field
    the_token = token
    if not the_token and authorization:
        if authorization.startswith("Bearer "):
            the_token = authorization.split(" ", 1)[1]
        else:
            the_token = authorization
    if not the_token:
        raise HTTPException(400, "Token required for logout")
    try:
        from backend import auth as _auth
        _auth.revoke_token(the_token)
        return {"success": True, "message": "Logged out"}
    except Exception:
        raise HTTPException(500, "Failed to revoke token")


def require_admin(authorization: str = Header(None)) -> dict:
    """Authenticate the caller and ensure they hold the admin role."""
    user = authenticate_user(authorization)
    role = (user.get("role") or "").strip().lower()
    if role not in ("admin", "administrator"):
        raise HTTPException(403, "Admin privileges required")
    return user


# =============================================================================
# Platform settings (admin) + audit log
# =============================================================================

@app.get("/api/admin/settings")
async def admin_get_settings(authorization: str = Header(None)):
    """Admin-only endpoint: read all platform settings (merged with defaults)."""
    require_admin(authorization)
    try:
        settings = get_all_settings()
        return {"settings": settings}
    except Exception as e:
        raise HTTPException(500, str(e))


@app.patch("/api/admin/settings")
async def admin_update_settings(payload: dict = Body(...), authorization: str = Header(None)):
    """Admin-only endpoint: update one or more platform settings (JSON body)."""
    admin = require_admin(authorization)
    if not payload or not isinstance(payload, dict):
        raise HTTPException(400, "Request body must be a JSON object of settings to update.")
    try:
        current = get_all_settings()
        for key, value in payload.items():
            if key not in current:
                raise HTTPException(400, f"Unknown platform setting: {key}")
            set_setting(key, value)
        log_audit(admin.get("id"), admin.get("email"), "UPDATE_SETTINGS", {"count": len(payload)})
        return {"success": True, "settings": get_all_settings()}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, str(e))


@app.get("/api/admin/audit")
async def admin_audit_logs(authorization: str = Header(None), limit: int = 200):
    """Admin-only endpoint: return recent audit log entries."""
    require_admin(authorization)
    try:
        logs = get_audit_logs(limit=min(int(limit), 1000))
        return {"logs": logs}
    except Exception as e:
        raise HTTPException(500, str(e))


@app.get("/api/maintenance/status")
async def get_maintenance_status():
    """Public endpoint to check if maintenance mode is active."""
    try:
        return {"maintenance": is_maintenance_mode()}
    except Exception as e:
        raise HTTPException(500, str(e))


@app.post("/api/admin/audit/log")
async def log_frontend_action(payload: dict = Body(...), authorization: str = Header(None)):
    """Log a frontend action to the audit log (authenticated or anonymous)."""
    try:
        try:
            user = authenticate_user(authorization)
            actor_id = user.get("id")
            actor_email = user.get("email")
        except Exception:
            actor_id = None
            actor_email = "anonymous"
        
        action = payload.get("action", "FRONTEND_ACTION")
        detail = payload.get("detail", {})
        
        log_audit(actor_id, actor_email, action, detail)
        return {"success": True}
    except Exception as e:
        raise HTTPException(500, str(e))


@app.get("/api/admin/stats")
async def admin_stats(authorization: str = Header(None)):
    """Admin-only endpoint: aggregate counts for the dashboard overview."""
    require_admin(authorization)
    try:
        stats = get_admin_stats()
        stats["module2_jobs_in_memory"] = len(MODULE2_JOBS)
        stats["module2_running"] = sum(
            1 for j in MODULE2_JOBS.values() if j.get("status") in ("queued", "running")
        )
        # Include persisted Module 2 jobs in the aggregate totals.
        try:
            db_module2 = get_all_module2_jobs()
            stats["total_module2_jobs"] = len(db_module2)
            stats["module2_by_status"] = {}
            for j in db_module2:
                st = j.get("status") or "unknown"
                stats["module2_by_status"][st] = stats["module2_by_status"].get(st, 0) + 1
        except Exception as e:
            print(f"[admin] Failed to load module2 stats from DB: {e}")
            stats["total_module2_jobs"] = len(MODULE2_JOBS)
            stats["module2_by_status"] = {}
        return stats
    except Exception as e:
        raise HTTPException(500, str(e))


@app.get("/api/admin/users")
async def admin_list_users(authorization: str = Header(None)):
    """Admin-only endpoint to list registered users."""
    require_admin(authorization)
    try:
        users = get_all_users()
        return {"users": users}
    except Exception as e:
        raise HTTPException(500, str(e))


@app.patch("/api/admin/users/{user_id}/role")
async def admin_update_user_role(user_id: int, role: str = Form(...), authorization: str = Header(None)):
    """Admin-only endpoint to change a user's role (e.g. admin / analyst / client)."""
    admin = require_admin(authorization)
    role = (role or "").strip()
    if not role:
        raise HTTPException(400, "Role cannot be empty")
    try:
        updated = update_user_role(user_id, role)
        if not updated:
            raise HTTPException(404, "User not found")
        log_audit(admin.get("id"), admin.get("email"), "UPDATE_USER_ROLE",
                  {"user_id": user_id, "role": role})
        return {"success": True, "user": updated}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, str(e))


@app.patch("/api/admin/users/{user_id}/status")
async def admin_update_user_status(user_id: int, status: str = Form(...), authorization: str = Header(None)):
    """Admin-only endpoint to activate/suspend a user account."""
    admin = require_admin(authorization)
    status = (status or "").strip().upper()
    if status not in ("ACTIVE", "SUSPENDED"):
        raise HTTPException(400, "Status must be ACTIVE or SUSPENDED")
    try:
        updated = update_user_status(user_id, status)
        if not updated:
            raise HTTPException(404, "User not found")
        log_audit(admin.get("id"), admin.get("email"), "UPDATE_USER_STATUS",
                  {"user_id": user_id, "status": status})
        return {"success": True, "user": updated}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, str(e))


@app.delete("/api/admin/users/{user_id}")
async def admin_delete_user(user_id: int, authorization: str = Header(None)):
    """Admin-only endpoint to remove a user account."""
    admin = require_admin(authorization)
    if user_id == admin.get("id"):
        raise HTTPException(400, "You cannot delete your own account while logged in as it")
    try:
        deleted = delete_user_by_id(user_id)
        if not deleted:
            raise HTTPException(404, "User not found")
        log_audit(admin.get("id"), admin.get("email"), "DELETE_USER", {"user_id": user_id})
        return {"success": True}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, str(e))


@app.get("/api/admin/scans")
async def admin_list_scans(authorization: str = Header(None)):
    """Admin-only endpoint: recent Recon (Module 1) jobs across all users, plus a
    best-effort snapshot of in-memory Module 2 jobs from the current server process."""
    require_admin(authorization)
    try:
        recon_jobs = get_all_recon_jobs()
        for j in recon_jobs:
            j["job_type"] = "recon"
        # Prefer persisted Module 2 jobs (survive restarts); overlay any
        # in-memory jobs that haven't been persisted yet with user email.
        try:
            db_module2 = get_all_module2_jobs()
            for j in db_module2:
                j["job_type"] = "module2"
        except Exception as e:
            print(f"[admin] Failed to load module2 jobs from DB: {e}")
            db_module2 = []

        mem_ids = {j.get("job_id") for j in db_module2}
        in_memory = [
            {
                "job_id": j.get("id"),
                "job_type": "module2",
                "user_id": j.get("user_id"),
                "target": j.get("target") or "(uploaded code)",
                "status": j.get("status"),
                "aggressive": j.get("aggressive"),
                "authorized": j.get("authorized"),
                "created_at": j.get("created_at"),
            }
            for j in MODULE2_JOBS.values()
            if j.get("id") not in mem_ids
        ]
        combined = db_module2 + in_memory
        combined.sort(key=lambda x: x.get("created_at") or "", reverse=True)
        return {"recon_jobs": recon_jobs, "module2_jobs": combined}
    except Exception as e:
        raise HTTPException(500, str(e))


# ===================== Admin Live Monitor (SSE 24x7) =====================

MONITOR_START_TS = time.time()


def _monitor_snapshot():
    """Build a lightweight, real-time aggregate snapshot of platform activity."""
    now = time.time()

    # Module 2 in-memory jobs
    m2_running = 0
    m2_queued = 0
    m2_completed = 0
    m2_failed = 0
    for j in MODULE2_JOBS.values():
        st = (j.get("status") or "").lower()
        if st in ("queued", "running"):
            m2_running += 1
        elif st in ("completed", "done"):
            m2_completed += 1
        elif st in ("failed", "error"):
            m2_failed += 1

    # Recon in-memory + DB totals
    recon_running = 0
    recon_queued = 0
    recent_events = []
    for j in RECON_JOBS.values():
        st = (j.get("status") or "").lower()
        if st in ("queued", "running"):
            recon_running += 1
        elif st not in ("completed", "done"):
            recon_queued += 1
        # latest few events across running jobs for the live feed
        for ev in j.get("events", [])[-3:]:
            recent_events.append({
                "job_id": j.get("id"),
                "target": j.get("target"),
                "message": ev.get("message") or ev.get("event"),
                "status": ev.get("status") or ev.get("event_type"),
                "ts": ev.get("ts") or ev.get("timestamp") or now,
            })

    running = recon_running + m2_running
    completed = m2_completed + len([j for j in RECON_JOBS.values() if (j.get("status") or "").lower() in ("completed", "done")])
    failed = m2_failed + len([j for j in RECON_JOBS.values() if (j.get("status") or "").lower() in ("failed", "error")])

    recent_events.sort(key=lambda e: e.get("ts", 0), reverse=True)
    recent_events = recent_events[:20]

    return {
        "ts": now,
        "heartbeat": "LIVE",
        "uptime_s": int(now - MONITOR_START_TS),
        "running": running,
        "queued": m2_queued + recon_queued,
        "completed": completed,
        "failed": failed,
        "m2_running": m2_running,
        "m2_completed": m2_completed,
        "m2_failed": m2_failed,
        "total_jobs": len(MODULE2_JOBS) + len(RECON_JOBS),
        "module2_jobs": len(MODULE2_JOBS),
        "recon_jobs": len(RECON_JOBS),
        "events": recent_events,
        "status": "ok",
    }


@app.get("/api/admin/monitor")
async def admin_monitor_stream(authorization: Optional[str] = Header(None)):
    """24x7 live monitoring stream (SSE). Requires admin auth via header.

    Because EventSource in browsers cannot set custom headers, the admin.js
    client uses fetch + ReadableStream to consume this endpoint with the
    Authorization header, so the push-based feed still authenticates.
    """
    require_admin(authorization)
    import asyncio as _asyncio

    async def event_gen():
        while True:
            snapshot = _monitor_snapshot()
            yield f"event: monitor\ndata: {json.dumps(snapshot)}\n\n"
            await _asyncio.sleep(2.0)

    return StreamingResponse(event_gen(), media_type="text/event-stream")


# ===================== Static frontend =====================


FRONTEND_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend")


@app.get("/cyverion/cyverion/admin/cy")
async def secret_admin_login_route():
    secret_file = os.path.join(FRONTEND_DIR, "cyverion", "cyverion", "admin", "cy.html")
    if os.path.exists(secret_file):
        return FileResponse(secret_file)
    raise HTTPException(404, "Page not found")


class NoCacheStaticFiles(StaticFiles):
    async def get_response(self, path: str, scope) -> Response:
        response = await super().get_response(path, scope)
        # Avoid caching JS, CSS, and HTML files
        lower_path = path.lower()
        if not any(lower_path.endswith(ext) for ext in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".woff", ".woff2", ".ttf", ".eot")):
            response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
            response.headers["Pragma"] = "no-cache"
            response.headers["Expires"] = "0"
        return response


if os.path.isdir(FRONTEND_DIR):
    app.mount("/", NoCacheStaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
