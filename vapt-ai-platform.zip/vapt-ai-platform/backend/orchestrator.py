"""
Pipeline Orchestrator (Module — SAST / static code scan)
Coordinates the static-analysis agents as a state pipeline
(recon -> ingestion -> sast -> dependency), emitting AgentEvent progress
updates that the API layer streams to the frontend over SSE.

Written as a plain async generator so it has zero hard dependency on any
particular agent framework — swap this out for a LangGraph/CrewAI graph
without touching the agents themselves if you want to extend it.

Note: this pipeline performs static/offline analysis only (no AI auto-patch
stage). Active, real-time exploitation testing against a live target lives
in Module 2 — see agents/dast/module2_orchestrator.py.
"""
import asyncio
from typing import AsyncGenerator, Optional

from agents import ingestion_agent, sast_agent, dependency_agent, recon_agent
from models import ScanJob, Finding, AgentEvent


async def run_pipeline(job: ScanJob, root_dir: Optional[str], url: Optional[str]) -> AsyncGenerator[AgentEvent, None]:

    def emit(agent, status, message, findings_count=None):
        ev = AgentEvent(job_id=job.id, agent=agent, status=status, message=message,
                         findings_count=findings_count)
        job.events.append(ev)
        return ev

    job.status = "running"

    # ---- Recon (passive URL analysis) ----
    if url:
        yield emit("recon", "started", f"Passively analyzing {url} (headers, TLS, robots.txt)...")
        await asyncio.sleep(0.1)
        try:
            recon_findings = recon_agent.analyze(url)
            for rf in recon_findings:
                job.findings.append(Finding(**rf))
            yield emit("recon", "completed", f"Recon complete.", len(recon_findings))
        except Exception as e:
            yield emit("recon", "error", f"Recon failed: {e}")

    inventory = None
    if root_dir:
        # ---- Ingestion ----
        yield emit("ingestion", "started", "Walking uploaded project, detecting stack and manifests...")
        await asyncio.sleep(0.1)
        inventory = ingestion_agent.ingest(root_dir)
        job.files_scanned = inventory["total_files"]
        langs = ", ".join(f"{k} ({v})" for k, v in inventory["language_counts"].items()) or "no recognized code files"
        yield emit("ingestion", "completed",
                    f"Indexed {inventory['total_files']} files. Stack: {langs}. "
                    f"Manifests found: {len(inventory['manifests'])}.")

        # ---- SAST ----
        yield emit("sast", "started", "Running static analysis rule set across source files...")
        await asyncio.sleep(0.1)
        sast_findings = sast_agent.scan_directory(root_dir, inventory["files"])
        for f in sast_findings:
            job.findings.append(Finding(**f))
        yield emit("sast", "completed", f"Static analysis complete.", len(sast_findings))

        # ---- Dependency / SCA ----
        if inventory["manifests"]:
            yield emit("dependency", "started", f"Checking {len(inventory['manifests'])} manifest(s) for vulnerable versions...")
            await asyncio.sleep(0.1)
            dep_findings = dependency_agent.analyze(root_dir, inventory["manifests"])
            for f in dep_findings:
                job.findings.append(Finding(**f))
            yield emit("dependency", "completed", "Dependency analysis complete.", len(dep_findings))
        else:
            yield emit("dependency", "completed", "No dependency manifests found — skipping.", 0)

    job.status = "completed"
    yield emit("sast", "completed", f"Pipeline finished. {len(job.findings)} total finding(s).")
