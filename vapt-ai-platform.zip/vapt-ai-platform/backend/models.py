"""
Shared data models for the VAPT AI platform.
"""
from __future__ import annotations
from typing import Optional, List, Literal
from pydantic import BaseModel, Field
import uuid
import time

Severity = Literal["critical", "high", "medium", "low", "info"]
AgentName = Literal[
    "ingestion", "recon", "sast", "dependency"
]


class Finding(BaseModel):
    id: str = Field(default_factory=lambda: uuid.uuid4().hex[:10])
    source_agent: AgentName
    file_path: Optional[str] = None
    line: Optional[int] = None
    rule_id: str
    cwe: Optional[str] = None
    title: str
    description: str
    severity: Severity
    evidence: Optional[str] = None          # the offending code / header snippet
    recommendation: Optional[str] = None    # short human recommendation
    status: Literal["open"] = "open"


class AgentEvent(BaseModel):
    job_id: str
    agent: AgentName
    status: Literal["started", "progress", "completed", "error"]
    message: str
    timestamp: float = Field(default_factory=time.time)
    findings_count: Optional[int] = None


class ScanJob(BaseModel):
    id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    target_type: Literal["url", "upload", "both"]
    target_url: Optional[str] = None
    created_at: float = Field(default_factory=time.time)
    status: Literal["queued", "running", "completed", "error"] = "queued"
    findings: List[Finding] = Field(default_factory=list)
    files_scanned: int = 0
    events: List[AgentEvent] = Field(default_factory=list)
