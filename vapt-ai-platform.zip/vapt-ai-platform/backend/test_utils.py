import unittest

from backend import utils


class TestUtils(unittest.TestCase):
    def test_normalize_target_url_accepts_domain_without_scheme(self):
        self.assertEqual(utils.normalize_target_url("example.com"), "https://example.com/")

    def test_normalize_target_url_accepts_http_scheme(self):
        self.assertEqual(utils.normalize_target_url("http://example.com/path"), "http://example.com/path")

    def test_normalize_target_url_rejects_spaces(self):
        with self.assertRaises(ValueError):
            utils.normalize_target_url("example .com")

    def test_normalize_target_url_rejects_credentials(self):
        with self.assertRaises(ValueError):
            utils.normalize_target_url("https://user:pass@example.com")

    def test_normalize_target_url_rejects_invalid_scheme(self):
        with self.assertRaises(ValueError):
            utils.normalize_target_url("ftp://example.com")

    def test_normalize_target_url_rejects_empty(self):
        with self.assertRaises(ValueError):
            utils.normalize_target_url("")


if __name__ == "__main__":
    unittest.main()
