import unittest
from fastapi.testclient import TestClient

from backend.main import app
from backend import database
from backend import auth

# Mock database pool on both namespaced and un-namespaced modules to prevent connection hangs during tests
def mock_get_pool():
    raise RuntimeError("Mock DB Offline")

database.get_pool = mock_get_pool
database.get_user_by_id = lambda uid: {"id": uid, "email": "test@example.com", "first_name": "Test", "last_name": "User"}

try:
    import database as local_db
    local_db.get_pool = mock_get_pool
    local_db.get_user_by_id = lambda uid: {"id": uid, "email": "test@example.com", "first_name": "Test", "last_name": "User"}
except ImportError:
    pass


class TestMainEndpoints(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)
        self.token = auth.create_access_token({"sub": "42", "email": "test@example.com"})
        self.headers = {"Authorization": f"Bearer {self.token}"}

    def test_scan_rejects_invalid_url(self):
        response = self.client.post("/api/scan", data={"url": "ftp://example.com"})
        self.assertEqual(response.status_code, 400)
        self.assertIn("Only http:// and https:// targets are allowed", response.text)

    def test_recon_start_rejects_invalid_target(self):
        response = self.client.post(
            "/api/recon/start",
            data={"target": "invalid_domain", "authorized": "true"},
            headers=self.headers,
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn("Target hostname is not valid", response.text)

    def test_recon_start_rejects_spaces_in_target(self):
        response = self.client.post(
            "/api/recon/start",
            data={"target": "not valid url", "authorized": "true"},
            headers=self.headers,
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn("must not contain spaces", response.text)

    def test_recon_start_rejects_missing_authorization(self):
        response = self.client.post(
            "/api/recon/start",
            data={"target": "example.com"},
            headers=self.headers,
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn("You must confirm you own or are explicitly authorized", response.text)

    def test_admin_settings_patch_and_audit_log_post(self):
        # Test settings patch (maintenance_mode update) without Content-Type: application/json
        # This simulates the frontend bug where headers: authHeaders() does not include Content-Type
        import json
        response = self.client.patch(
            "/api/admin/settings",
            content=json.dumps({"maintenance_mode": True}),
            headers={**self.headers, "Content-Type": "text/plain"},
        )
        # Should return 422 because the Content-Type is not application/json
        self.assertEqual(response.status_code, 422)

        # Test settings patch with correct Content-Type: application/json
        response = self.client.patch(
            "/api/admin/settings",
            json={"maintenance_mode": True},
            headers=self.headers,
        )
        self.assertEqual(response.status_code, 200)

        # Test audit log post
        response = self.client.post(
            "/api/admin/audit/log",
            json={"action": "TEST_ACTION", "detail": {"some": "info"}},
            headers=self.headers,
        )
        self.assertEqual(response.status_code, 200)

    def test_secret_admin_login_route(self):
        # Retrieve the secret login gateway path
        response = self.client.get("/cyverion/cyverion/admin/cy")
        self.assertEqual(response.status_code, 200)
        self.assertIn("ADMIN MAINTENANCE GATEWAY", response.text)

    def test_save_recon_assessment(self):
        # Mock database helpers on main module namespace
        mock_get_any = lambda jid: {"job_id": jid, "user_id": 42, "target": "example.com", "status": "completed", "report": {}, "created_at": None, "completed_at": None}
        mock_get = lambda jid, uid: {"job_id": jid, "user_id": uid, "target": "example.com", "status": "completed", "report": {}, "created_at": None, "completed_at": None}
        mock_update = lambda jid, assess: None

        import backend.main as main_mod
        orig_get_any = getattr(main_mod, "get_recon_job_any", None)
        orig_get = getattr(main_mod, "get_recon_job", None)
        orig_update = getattr(main_mod, "update_recon_assessment", None)

        main_mod.get_recon_job_any = mock_get_any
        main_mod.get_recon_job = mock_get
        main_mod.update_recon_assessment = mock_update

        try:
            assessment_payload = {
                "likelihood": 3,
                "impact": 4,
                "notes": "Custom analyst assessment test notes",
                "stride_scenarios": [],
                "status": "Approved",
                "override_score": True,
                "custom_score": 85,
                "override_justification": "Mitigating factors analyzed."
            }

            response = self.client.post(
                "/api/recon/report/test_job_id_123/assess",
                json=assessment_payload,
                headers=self.headers,
            )
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.json()["success"], True)
        finally:
            if orig_get_any: main_mod.get_recon_job_any = orig_get_any
            if orig_get: main_mod.get_recon_job = orig_get
            if orig_update: main_mod.update_recon_assessment = orig_update

    def test_apply_fix_to_file(self):
        import tempfile
        import os
        from backend.main import apply_fix_to_file
        
        with tempfile.NamedTemporaryFile("w+", delete=False) as tmp:
            tmp.write("line 1\n    line 2 raw\nline 3\n")
            tmp_path = tmp.name
            
        try:
            success = apply_fix_to_file(tmp_path, 2, "line 2 patched")
            self.assertTrue(success)
            
            with open(tmp_path, "r") as f:
                content = f.read()
                
            self.assertEqual(content, "line 1\n    line 2 patched\nline 3\n")
        finally:
            os.remove(tmp_path)

    def test_module2_fix_endpoint(self):
        import backend.main as main_mod
        import tempfile
        import shutil
        import os
        
        job_id = "test_m2_fix_job"
        test_dir = os.path.join(main_mod.BASE_TMP, f"m2_{job_id}")
        os.makedirs(test_dir, exist_ok=True)
        
        test_file = "app.py"
        test_file_path = os.path.join(test_dir, test_file)
        with open(test_file_path, "w") as f:
            f.write("query = f'SELECT * FROM users WHERE id={user_id}'\n")
            
        main_mod.MODULE2_JOBS[job_id] = {
            "id": job_id,
            "user_id": 42,
            "status": "completed",
            "has_uploaded_code": True,
            "agents": ["sqli"],
            "report": {
                "findings": [
                    {
                        "finding_type": "source_code",
                        "file_path": test_file,
                        "line": 1,
                        "title": "SQL Injection",
                        "suggested_fix": "query = 'SELECT * FROM users WHERE id=%s'"
                    }
                ],
                "executive_summary": {
                    "risk_score": 50,
                    "risk_rating": "Needs Attention",
                    "total_findings": 1,
                    "severity_counts": {"critical": 0, "high": 1, "medium": 0, "low": 0, "info": 0},
                    "findings_by_agent": {"sqli": 1},
                    "agents_run": ["sqli"]
                }
            }
        }
        
        orig_update = main_mod.update_module2_job
        main_mod.update_module2_job = lambda *args, **kwargs: None
        
        try:
            payload = {
                "job_id": job_id,
                "file_path": test_file,
                "line": 1,
                "suggested_fix": "query = 'SELECT * FROM users WHERE id=%s'"
            }
            response = self.client.post(
                "/api/module2/fix",
                json=payload,
                headers=self.headers
            )
            self.assertEqual(response.status_code, 200)
            data = response.json()
            self.assertTrue(data["success"])
            self.assertTrue(data["fixed_in_temp"])
            
            with open(test_file_path, "r") as f:
                self.assertEqual(f.read().strip(), "query = 'SELECT * FROM users WHERE id=%s'")
                
            report = data["report"]
            self.assertTrue(report["findings"][0]["is_fixed"])
            self.assertEqual(report["executive_summary"]["risk_score"], 100)
            
        finally:
            main_mod.update_module2_job = orig_update
            if job_id in main_mod.MODULE2_JOBS:
                del main_mod.MODULE2_JOBS[job_id]
            shutil.rmtree(test_dir, ignore_errors=True)

    def test_download_fixed_zip_endpoint(self):
        import backend.main as main_mod
        import os
        import shutil
        import zipfile
        import io
        
        job_id = "test_m2_zip_job"
        test_dir = os.path.join(main_mod.BASE_TMP, f"m2_{job_id}")
        os.makedirs(test_dir, exist_ok=True)
        
        test_file = "app.py"
        with open(os.path.join(test_dir, test_file), "w") as f:
            f.write("print('fixed code')\n")
            
        main_mod.MODULE2_JOBS[job_id] = {
            "id": job_id,
            "user_id": 42,
            "has_uploaded_code": True,
        }
        
        try:
            response = self.client.get(
                f"/api/module2/download_fixed/{job_id}?token={self.token}"
            )
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.headers["content-type"], "application/zip")
            
            zip_bytes = io.BytesIO(response.content)
            with zipfile.ZipFile(zip_bytes) as zf:
                self.assertIn(test_file, zf.namelist())
                self.assertEqual(zf.read(test_file).decode().strip(), "print('fixed code')")
                
        finally:
            if job_id in main_mod.MODULE2_JOBS:
                del main_mod.MODULE2_JOBS[job_id]
            shutil.rmtree(test_dir, ignore_errors=True)

    def test_module2_chat_endpoint(self):
        # 1. Unauthorized request
        response = self.client.post("/api/module2/chat", json={
            "finding": {"title": "Test XSS", "agent": "xss", "severity": "high"},
            "prompt": "Explain this issue in simple terms"
        })
        self.assertEqual(response.status_code, 401)

        # 2. Authorized request - Explain prompt fallback
        response = self.client.post(
            "/api/module2/chat",
            json={
                "finding": {
                    "title": "SQL Injection in Search Form",
                    "agent": "sqli",
                    "severity": "high",
                    "cwe": "CWE-89",
                    "description": "Concat user input directly into query",
                    "recommendation": "Use parameterized queries",
                    "evidence": "SELECT * FROM users WHERE name = "
                },
                "prompt": "Explain this issue in simple terms and its risk profile",
                "history": []
            },
            headers=self.headers
        )
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("response", data)
        self.assertIn("Risk Analysis", data["response"])
        self.assertIn("SQL Injection", data["response"])

        # 3. Authorized request - Secure fix prompt fallback
        response = self.client.post(
            "/api/module2/chat",
            json={
                "finding": {
                    "title": "SQL Injection in Search Form",
                    "agent": "sqli",
                    "severity": "high",
                    "cwe": "CWE-89",
                    "evidence": "SELECT * FROM users WHERE name = "
                },
                "prompt": "Suggest a secure code fix",
                "history": []
            },
            headers=self.headers
        )
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("response", data)
        self.assertIn("cursor.execute", data["response"])

        # 4. Authorized request - Decision prompt fallback
        response = self.client.post(
            "/api/module2/chat",
            json={
                "finding": {
                    "title": "SQL Injection in Search Form",
                    "agent": "sqli",
                    "severity": "high",
                    "cwe": "CWE-89"
                },
                "prompt": "Should I approve or reject this finding?",
                "history": []
            },
            headers=self.headers
        )
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("response", data)
        self.assertIn("BLOCK build", data["response"])


if __name__ == "__main__":
    unittest.main()


