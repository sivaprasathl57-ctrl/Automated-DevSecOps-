import os
import sys

# Ensure backend submodules can import local packages via plain module names
# when the package is imported from the workspace root.
BACKEND_DIR = os.path.dirname(__file__)
if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)
