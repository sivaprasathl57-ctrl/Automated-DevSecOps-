"""
Module 2 Playground — a small, INTENTIONALLY vulnerable Flask app.

Purpose: give you a real, live HTTP target to point Module 2's active
agents at, so you can see them find and report genuine issues end-to-end
before you run them against your own authorized production/staging site.

DO NOT deploy this anywhere reachable by the public internet and DO NOT
use it to store real data — every route below is deliberately broken in a
specific, documented way (labeled with the agent that should catch it).

Run it:
    pip install -r requirements.txt
    python dast_playground.py
    # -> listens on http://127.0.0.1:5050

Then in Module 2, target: http://127.0.0.1:5050
"""
import os
import sqlite3
import tempfile

from flask import Flask, request, redirect, make_response, Response

app = Flask(__name__)
DB_PATH = os.path.join(tempfile.gettempdir(), "module2_playground.db")


def _init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT, email TEXT)")
    conn.execute("DELETE FROM users")
    conn.executemany("INSERT INTO users (id, name, email) VALUES (?, ?, ?)",
                      [(1, "alice", "alice@example.com"), (2, "bob", "bob@example.com")])
    conn.execute("CREATE TABLE IF NOT EXISTS invoices (id INTEGER PRIMARY KEY, owner TEXT, amount TEXT)")
    conn.execute("DELETE FROM invoices")
    conn.executemany("INSERT INTO invoices (id, owner, amount) VALUES (?, ?, ?)",
                      [(1001, "alice", "$400"), (1002, "bob", "$950")])
    conn.commit()
    conn.close()


@app.route("/")
def home():
    # [misconfig_agent] no CSP / X-Frame-Options / HSTS set anywhere in this app on purpose.
    return """
    <html><body>
    <h1>Module 2 Playground</h1>
    <ul>
      <li><a href="/search?q=hello">Search (XSS)</a></li>
      <li><a href="/user?name=alice">User lookup (SQLi)</a></li>
      <li><a href="/invoice/1001">Invoice 1001 (IDOR — try /invoice/1002)</a></li>
      <li><a href="/read?file=welcome.txt">Read file (Path Traversal)</a></li>
      <li><a href="/upload">Upload avatar (Unrestricted upload)</a></li>
      <li><a href="/fetch?url=https://example.com">Fetch preview (SSRF)</a></li>
      <li><a href="/login">Login (CSRF + username enum)</a></li>
    </ul>
    </body></html>
    """


# ---- [xss_agent] reflected XSS: user input echoed back unescaped ----
@app.route("/search")
def search():
    q = request.args.get("q", "")
    return f"<html><body><p>You searched for: {q}</p></body></html>"


# ---- [sqli_agent] SQL injection: query built via string concatenation ----
@app.route("/user")
def user_lookup():
    name = request.args.get("name", "")
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    try:
        cur.execute(f"SELECT id, name, email FROM users WHERE name = '{name}'")
        rows = cur.fetchall()
        html = "<br>".join(str(r) for r in rows) or "No user found."
    except sqlite3.OperationalError as e:
        # Deliberately verbose — real broken apps do this.
        html = f"SQLite3 error near query: {e}"
    conn.close()
    return f"<html><body>{html}</body></html>"


# ---- [idor_agent] no ownership check on invoice id ----
@app.route("/invoice/<int:invoice_id>")
def invoice(invoice_id):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id, owner, amount FROM invoices WHERE id = ?", (invoice_id,))
    row = cur.fetchone()
    conn.close()
    if not row:
        return "Not found", 404
    return f"<html><body>Invoice #{row[0]} — owner: {row[1]} — amount: {row[2]}</body></html>"


# ---- [path_traversal_agent] filename concatenated straight onto a base dir ----
SAFE_DIR = tempfile.gettempdir()
with open(os.path.join(SAFE_DIR, "welcome.txt"), "w") as fh:
    fh.write("Welcome to the Module 2 playground.\n")

@app.route("/read")
def read_file():
    filename = request.args.get("file", "welcome.txt")
    path = os.path.join(SAFE_DIR, filename)  # no sanitization on purpose
    try:
        with open(path, "r", errors="ignore") as fh:
            return Response(fh.read(), mimetype="text/plain")
    except OSError as e:
        return f"Error: {e}", 400


# ---- [ssrf_upload_agent] file upload with no type/content validation ----
@app.route("/upload", methods=["GET", "POST"])
def upload():
    if request.method == "GET":
        return """<form method="POST" enctype="multipart/form-data">
                     <input type="file" name="avatar">
                     <button type="submit">Upload</button>
                   </form>"""
    f = request.files.get("avatar")
    if not f:
        return "No file", 400
    dest = os.path.join(tempfile.gettempdir(), "module2_uploads")
    os.makedirs(dest, exist_ok=True)
    f.save(os.path.join(dest, f.filename))  # no extension/MIME check on purpose
    return f"Uploaded {f.filename}", 200


# ---- [ssrf_upload_agent] server fetches a user-supplied URL with no allow-list ----
@app.route("/fetch")
def fetch_preview():
    import urllib.request
    url = request.args.get("url", "")
    if not url:
        return "Provide ?url=", 400
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "playground-fetcher"})
        with urllib.request.urlopen(req, timeout=3) as resp:
            body = resp.read(500).decode(errors="ignore")
        return f"<pre>{body}</pre>"
    except Exception as e:
        return f"Fetch failed: {e}", 502


# ---- [csrf_agent] state-changing POST with no anti-CSRF token ----
# ---- [auth_agent] distinguishable invalid-user vs invalid-password responses ----
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return """<form method="POST">
                     <input type="text" name="username">
                     <input type="password" name="password">
                     <button type="submit">Log in</button>
                   </form>"""
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id FROM users WHERE name = ?", (username,))
    exists = cur.fetchone()
    conn.close()
    if not exists:
        return "No such username exists.", 401  # <- enumeration signal
    if password != "playground":
        return "Incorrect password for that account.", 401  # <- different body/behavior
    resp = make_response("Logged in!")
    resp.set_cookie("session", "demo-session-value")  # no HttpOnly/Secure/SameSite on purpose
    return resp


if __name__ == "__main__":
    _init_db()
    print("Module 2 Playground listening on http://127.0.0.1:5050")
    print("This app is intentionally vulnerable — local/offline use only.")
    app.run(host="127.0.0.1", port=5050, debug=False)
