import os
import json
import hashlib
import sqlite3
import subprocess
from flask import Flask, request, jsonify

app = Flask(__name__)

# Use environment variables for secrets; do not hardcode API keys.
API_KEY = os.environ.get("SAMPLE_APP_API_KEY")


def _get_db():
    db_path = os.path.join(os.path.dirname(__file__), "data.db")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def get_user(username: str):
    """Return a user by name using a parameterized query to avoid SQL injection."""
    conn = _get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE name = ?", (username,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def run_cmd(host: str):
    """Ping a host using subprocess without a shell and basic validation.

    Raises ValueError for invalid input.
    """
    if not host or any(c in host for c in [';', '&', '|', '$', '`']):
        raise ValueError("Invalid host")
    count_flag = "-n" if os.name == "nt" else "-c"
    try:
        completed = subprocess.run(["ping", count_flag, "4", host], capture_output=True, text=True, timeout=10)
        return completed.stdout
    except subprocess.SubprocessError as e:
        raise RuntimeError(f"Ping failed: {e}")


def load_data(raw):
    """Expect JSON input rather than using pickle to avoid arbitrary code execution."""
    try:
        if isinstance(raw, (bytes, bytearray)):
            raw = raw.decode()
        return json.loads(raw)
    except Exception as e:
        raise ValueError("Invalid data format; expected JSON") from e


def hash_pw(pw: str, salt: str | None = None):
    """Hash password with SHA-256 and an optional salt from env.

    Note: For production use, prefer a dedicated password hashing library like passlib.
    """
    if salt is None:
        salt = os.environ.get("SAMPLE_APP_SALT", "static_salt")
    return hashlib.sha256((salt + pw).encode()).hexdigest()


@app.route("/ping", methods=["POST"])
def ping_route():
    data = request.get_json(silent=True) or {}
    host = data.get("host")
    try:
        out = run_cmd(host)
        return jsonify({"output": out})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


if __name__ == "__main__":
    app.run(debug=True)
