# SENTINEL — Multi-Agent AI VAPT Platform

An AI-assisted Vulnerability Assessment & Penetration Testing (VAPT) tool built
around cooperating agents across two modules:

- **Module 1 — Recon & OSINT**: fully passive information gathering against a URL.
- **Module 1(b) — Static scan**: uploaded-code SAST + dependency analysis.
- **Module 2 — Active Vulnerability Agents**: real, live, black-box exploitation
  testing against an authorized running target (XSS, SQL Injection, CSRF, IDOR,
  Path Traversal/LFI, Auth & Authorization, SSRF & unrestricted upload, and
  Security Misconfiguration) — every finding carries a real request/response
  pair captured from the target, not a simulated result.

Built for an academic VAPT project. Stack: **Python/FastAPI backend + plain
HTML/CSS/JS frontend** (no build step, no framework — open `index.html` is all
it takes on the client side).

---

## Architecture — Module 1(b) static pipeline (4 agents)

| # | Agent | File | What it does |
|---|-------|------|---------------|
| 1 | **Recon Agent** | `backend/agents/recon_agent.py` | *Passive only.* Checks security headers, TLS/cert health, and conventionally-public paths (`robots.txt`) for a URL. No brute-forcing, no fuzzing, no exploitation. |
| 2 | **Ingestion Agent** | `backend/agents/ingestion_agent.py` | Walks an uploaded project, builds a file inventory, detects the language/tech stack, locates dependency manifests. |
| 3 | **SAST Agent** | `backend/agents/sast_agent.py` + `backend/rules/sast_rules.py` | Rule-based static analysis: SQLi, command injection, XSS, insecure deserialization, weak crypto, hardcoded secrets, debug mode, CORS misconfig, path traversal, and more (20 rules, easy to extend). |
| 4 | **Dependency Agent** | `backend/agents/dependency_agent.py` | Flags known-vulnerable package versions from `requirements.txt`/`package.json` — checks a bundled offline dataset, and optionally queries the free [OSV.dev](https://osv.dev) API live if the deployment has internet access. |

`backend/orchestrator.py` wires these into one pipeline and streams live
progress events; `backend/main.py` exposes it over a REST + Server-Sent-Events
API that the frontend consumes. This pipeline is static/offline analysis
only — it does not run against a live target and it does not auto-patch code.

## Frontend

Pure HTML/CSS/JS, no build tooling:
- **Agent rail** (left) — live status of each agent as the pipeline runs.
- **Console** (center) — URL input, folder/file upload (drag-and-drop or `webkitdirectory`), live terminal-style agent feed via SSE.
- **Findings panel** (right) — severity-sorted finding cards → click to open a detail modal with the evidence and recommendation.

## Module 1 — Recon & OSINT (`recon.html`)

A separate, full top-to-bottom information-gathering pipeline — pure passive
recon, no active exploitation (that's Module 2, described below). Six agents
under `backend/agents/recon/`:

| # | Agent | Gathers |
|---|-------|---------|
| 1 | `dns_whois.py` | Primary IP, every common DNS record (A/AAAA/MX/TXT/NS/CNAME/SOA), WHOIS (registrar, registration/expiry dates, name servers) |
| 2 | `subdomains.py` | Subdomains via certificate-transparency logs (crt.sh, fully passive) + common-name DNS resolution |
| 3 | `network_scan.py` | Open ports, service names, version banners, OS fingerprint guess — uses `nmap -sV -O` / `-A` if installed, else a pure-Python TCP-connect scanner fallback |
| 4 | `web_recon.py` | Security headers, cookie types (Session ID vs JWT vs CSRF, HttpOnly/Secure/SameSite flags), SSL/TLS certificate details, technology fingerprinting, WAF/CDN detection |
| 5 | `endpoints.py` | Crawled links/forms/scripts from the homepage, robots.txt + sitemap.xml disclosures, presence of common well-known paths (`/api`, `/.env`, `/admin`, `/graphql`, etc.) |
| 6 | `osint.py` | GitHub org/members via GitHub's public API, ready-to-open search-engine "dork" links for LinkedIn/social/public-document discovery, employee email-pattern guesses, Have I Been Pwned domain breach check (needs `HIBP_API_KEY`) |
| 7 | `cve_lookup.py` | **CVE Intelligence.** Parses clean product/version pairs out of everything the earlier agents already found (service banners, `Server` header, `X-Powered-By`, tech fingerprints), then checks each one against the free NVD (National Vulnerability Database) API — no paid key required. Returns matched CVE IDs, CVSS score/severity, description, and a link straight to the NVD page. |

**Executive summary / risk score:** every report opens with a scorecard —
a 0-100 risk score, plain-language rating (Good / Needs Attention / At
Risk), and big, easy-to-read numbers for open ports, subdomains, endpoints,
critical/high CVEs, session/JWT cookies, and missing security headers. The
scoring logic is fully transparent (`_build_executive_summary` in
`module1_orchestrator.py`) — it's a starting triage signal, not a
certified risk rating.

**CVE matching is free** — it uses NVD's public API, no signup or paid key
needed. Set `NVD_API_KEY` (free to request at nvd.nist.gov) only if you're
scanning many hosts and hit the (generous) unauthenticated rate limit.

**Run it:** same server as Module 2 — open `recon.html` (linked from the top
nav). Enter a target, tick **"I own this target or have authorization"**
(the API rejects requests without this — `authorized=true` is a required
field), optionally enable **Aggressive** (wider port range + deeper probes)
and **OSINT gathering**, then launch. Live agent activity streams via SSE
into the terminal, and the report panel fills in section by section.

**Why no LinkedIn/social-media scraping:** scraping LinkedIn (or most social
platforms) violates their Terms of Service and carries real legal risk. The
OSINT agent instead generates pre-built search-engine dork queries — the
same technique real OSINT engagements use — that a human analyst opens with
one click, rather than automating access to gated data.

**Endpoints:** `POST /api/recon/start`, `GET /api/recon/stream/{job_id}`,
`GET /api/recon/report/{job_id}`.

---

## Module 2 — Active Vulnerability Agents (`module2.html`)

Real, live, black-box testing agents. Unlike Module 1, these send actual
crafted requests at a running target and inspect the *real* response — every
finding ships with a genuine request/response evidence block so it can be
reproduced and verified by a human, not a canned/demo result. Lives in
`backend/agents/dast/`:

| # | Agent | File | What it does |
|---|-------|------|---------------|
| 0 | **Target Mapper** | `crawler.py` | Crawls the live site (bounded, ~12 pages) to find real forms, query-string parameters, and numeric object IDs to test. |
| 1 | **XSS Agent** | `xss_agent.py` | 8 reflected-XSS technique families (script tag, event-handler breakout, SVG `onload`, attribute breakout, `javascript:` URI, polyglot, etc.) — flags a hit only when the payload survives unescaped in the real response body. |
| 2 | **SQL Injection Agent** | `sqli_agent.py` | Error-based (5 DB engine signatures), boolean-based blind (diffs a TRUE vs FALSE response), and time-based blind (per-engine conditional sleep, measured against a real baseline). |
| 3 | **CSRF Agent** | `csrf_agent.py` | Flags POST forms with no anti-CSRF token field, and session cookies missing `SameSite`. |
| 4 | **IDOR Agent** | `idor_agent.py` | Tampers with numeric object IDs (path segments and query params) and compares real responses for a same-status, distinct-content "different record" pattern with no authorization check. |
| 5 | **Path Traversal / LFI Agent** | `path_traversal_agent.py` | Linux/Windows traversal payloads (`../../etc/passwd`, encoded variants, `win.ini`) — a hit requires the *actual file content signature* to appear in the response. |
| 6 | **Auth & Authorization Agent** | `auth_agent.py` | Session cookie hardening (HttpOnly/Secure/SameSite), JWT `alg:none`/weak-alg decoding, unauthenticated access to common admin/debug paths, and username-enumeration via differential login responses (no password brute forcing). |
| 7 | **SSRF & Upload Agent** | `ssrf_upload_agent.py` | Internal/metadata-address SSRF probes (loopback, `169.254.169.254`, etc.) validated via real redirect chains/timing baselines, plus file-upload extension/MIME-filter bypass testing using **inert marker content only** — never a working exploit payload. |
| 8 | **Security Misconfiguration Agent** | `misconfig_agent.py` | Missing security headers (CSP, HSTS, X-Frame-Options, etc.), exposed sensitive files (`.env`, `.git/config`, backups), directory listing, CORS misconfiguration, verbose version banners, and dangerous HTTP methods (TRACE). |

`backend/agents/dast/module2_orchestrator.py` runs the mapper then the
selected agents in sequence, streaming live `AgentEvent`-style progress over
SSE exactly like Module 1, and builds a risk-scored executive summary at the
end.

**Run it:** open `module2.html` (linked from the top nav). Enter a target,
select which agents to run (default = all 8), optionally enable
**Aggressive mode** (tests every discovered parameter, not just
likely-relevant ones), tick **"I confirm I own this target or am explicitly
authorized to actively test it"** (the API rejects requests without this —
`authorized=true` is a required field, exactly like Module 1), then launch.
Live agent activity streams into the terminal and the findings panel fills in
as each agent completes; click a finding to see its full live evidence.

**Endpoints:** `POST /api/module2/start`, `GET /api/module2/stream/{job_id}`,
`GET /api/module2/report/{job_id}`.

**Try it against a real, running (but safe) target:** `sample_vulnerable_app/dast_playground.py`
is a small, deliberately vulnerable Flask app you can run locally
(`python dast_playground.py`, listens on `http://127.0.0.1:5050`) with one
clearly-labeled real bug per agent — point Module 2 at it to see every agent
find a genuine issue end-to-end before you run against your own authorized
staging/production target. **Local/offline use only — never deploy it
publicly.**

---



```bash
cd backend
pip install -r requirements.txt --break-system-packages   # drop the flag if not needed on your machine
uvicorn main:app --reload --port 8000
```

That's it — **no API key needed.** Open **http://localhost:8000** (the backend
serves the frontend directly). Upload the included `sample_vulnerable_app/`
folder (deliberately vulnerable, for demo/testing only) into the Module 1(b)
static scan to see the find pipeline run end-to-end, offline. For Module 2,
run `python sample_vulnerable_app/dast_playground.py` (listens on
`http://127.0.0.1:5050`) and point the Module 2 console at it to watch the
active agents find real, live issues over real HTTP requests.

Tested live: the static pipeline finds all 7 planted issues in the sample app
(hardcoded API key, OS command injection, insecure pickle deserialization,
weak MD5 hash, Flask debug mode, and 2 outdated dependencies) with zero
external calls. The Module 2 agents were run end-to-end against
`dast_playground.py` and correctly found XSS, SQL injection, CSRF, IDOR, path
traversal, an unrestricted-upload bypass, and 6 misconfiguration issues — all
backed by real captured request/response evidence.

## Scope, limitations & ethics — read before your viva/demo

- **Only scan/actively test targets you own or are explicitly authorized to
  test.** Module 1's recon agent is intentionally passive (headers/TLS/robots.txt
  only). Module 2's agents are *active* — they send real crafted requests,
  including SQLi/XSS/traversal payloads and a benign file upload — which is
  unauthorized access in most jurisdictions if run against a system you don't
  control or have written permission for (e.g. India's IT Act §43/§66, US CFAA).
  Both modules require an explicit `authorized=true` confirmation before any
  request leaves the server.
- This is a **pattern/signature-based scanner**, not a full exploit framework.
  Like any DAST/SAST tool (Burp, ZAP, Bandit, Semgrep) it will have false
  positives/negatives — it's a strong triage aid, not a guarantee of "100%"
  coverage. Be ready to say that honestly if asked in a viva; it's also just
  true of every commercial scanner.
  The static rules cover single-statement patterns; multi-line data flow
  (e.g. a query built on one line, executed two lines later) is a natural
  "future work" extension point — mention it, it's a good discussion point.
- The dependency agent's offline dataset is illustrative (a handful of
  well-known CVEs) — swap in a full OSV/NVD feed for production use.
- Module 2's file-upload probe deliberately uses inert marker content, never
  a working script payload — it demonstrates that extension/MIME filtering
  can be bypassed without actually achieving code execution. A human should
  still validate and, if pursuing full exploitation, do so under the same
  written authorization that covers the rest of the engagement.
- Every Module 2 finding is a signal to investigate, not an automatic ground
  truth — a human should confirm and prioritize before acting on any of them,
  same as with any scanner output.

## Extending it

- Add more static rules to `backend/rules/sast_rules.py` — each is just an id,
  CWE, severity, regex, and recommendation.
- Add more Module 2 payload families/agents under `backend/agents/dast/` —
  each agent is a plain `run(session, target_report, aggressive)` function
  that returns a list of finding dicts, so new agents drop straight into
  `module2_orchestrator.AGENT_REGISTRY`.
- Swap `backend/orchestrator.py`'s sequential pipeline for a real LangGraph or
  CrewAI graph — the agents are already pure functions, so this is a drop-in
  change without touching agent logic.
- Add a PDF/HTML export of the report for the findings panel (nice addition
  for a project demo/report submission).

## Dev notes

Quick steps to run locally:

1. Install dependencies:
```bash
python -m pip install -r backend/requirements.txt
```

2. Ensure PostgreSQL is running and env vars are set (DB_HOST, DB_USER, DB_PASSWORD, DB_NAME).

3. Run DB migrations (creates revoked_tokens table):
```bash
python scripts/migrate_revoked_tokens.py
```

4. Start backend:
```bash
cd backend
uvicorn main:app --reload --port 8000
```

5. Open http://localhost:8000 in your browser.

CI: a GitHub Actions workflow is included at `.github/workflows/ci.yml` to run tests.

