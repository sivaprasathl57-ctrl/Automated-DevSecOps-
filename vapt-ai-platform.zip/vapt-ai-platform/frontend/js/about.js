/*=========================================
        CYVERION – RED & BLACK ABOUT JS
        GSAP Animations + Red Particle Matrix
=========================================*/

// ===============================
// GSAP PAGE ANIMATION
// ===============================

window.addEventListener("load", () => {
    if (typeof gsap === "undefined") return;

    gsap.from("header", {
        y: -100,
        opacity: 0,
        duration: 1,
        ease: "power3.out"
    });

    gsap.from(".hero-content h4", {
        y: 40,
        opacity: 0,
        duration: 1,
        ease: "power2.out"
    });

    gsap.from(".hero-content h1", {
        y: 60,
        opacity: 0,
        duration: 1.2,
        ease: "power3.out"
    });

    gsap.from(".hero-content p", {
        y: 60,
        opacity: 0,
        duration: 1.2,
        delay: .3,
        ease: "power2.out"
    });

    gsap.from(".hero-btn", {
        scale: .8,
        opacity: 0,
        duration: .8,
        delay: .6,
        ease: "back.out(2)"
    });

    gsap.from(".glass-box", {
        y: 80,
        opacity: 0,
        duration: 1,
        stagger: .2,
        ease: "power2.out"
    });

    gsap.from(".card", {
        y: 60,
        opacity: 0,
        duration: .8,
        stagger: .15,
        ease: "power2.out"
    });

    gsap.from(".stat", {
        scale: .7,
        opacity: 0,
        duration: .8,
        stagger: .2,
        ease: "power2.out"
    });

    gsap.from(".tech", {
        y: 40,
        opacity: 0,
        stagger: .05,
        duration: .6,
        ease: "power2.out"
    });

    gsap.from(".future-features", {
        y: 70,
        opacity: 0,
        duration: 1,
        delay: .2,
        ease: "power2.out"
    });

    gsap.from(".future-item", {
        y: 50,
        opacity: 0,
        duration: .8,
        stagger: .12,
        delay: .35,
        ease: "power2.out"
    });
});


// ===============================
// FLOATING RED PARTICLES
// ===============================

(function initParticles() {
    const container = document.getElementById("particles");
    if (!container) return;

    const COUNT = 80;

    for (let i = 0; i < COUNT; i++) {
        const p = document.createElement("span");
        const size = Math.random() * 3 + 1;
        const isEmber = Math.random() > 0.7;

        p.style.cssText = `
            position: absolute;
            width: ${size}px;
            height: ${size}px;
            border-radius: 50%;
            background: ${isEmber ? '#FF6D00' : '#FF1744'};
            opacity: ${Math.random() * 0.55 + 0.10};
            left: ${Math.random() * 100}vw;
            top: ${Math.random() * 100}vh;
            box-shadow: 0 0 ${size * 4}px ${isEmber ? '#FF6D00' : '#FF1744'},
                        0 0 ${size * 8}px ${isEmber ? 'rgba(255,109,0,0.3)' : 'rgba(255,23,68,0.25)'};
            pointer-events: none;
        `;

        container.appendChild(p);
        animateParticle(p);
    }

    function animateParticle(el) {
        let y = Math.random() * window.innerHeight;

        function move() {
            y -= 0.4;
            if (y < -20) {
                y = window.innerHeight + 20;
                el.style.left = Math.random() * window.innerWidth + "px";
            }
            el.style.transform = `translateY(${y}px)`;
            requestAnimationFrame(move);
        }
        move();
    }
})();


// ===============================
// NAVBAR EFFECT
// ===============================

window.addEventListener("scroll", () => {
    const header = document.querySelector("header");
    if (!header) return;

    if (window.scrollY > 40) {
        header.style.background = "rgba(6,6,6,0.92)";
        header.style.borderBottom = "1px solid rgba(255,23,68,0.25)";
        header.style.boxShadow = "0 10px 40px rgba(255,23,68,0.10)";
    } else {
        header.style.background = "rgba(6,6,6,0.55)";
        header.style.borderBottom = "1px solid rgba(255,23,68,0.14)";
        header.style.boxShadow = "none";
    }
});


// ===============================
// 3D PARALLAX EFFECT
// ===============================

document.querySelectorAll(".card, .glass-box, .stat, .tech").forEach(card => {
    card.addEventListener("mousemove", (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const rotateY = (x - rect.width / 2) / 18;
        const rotateX = (rect.height / 2 - y) / 18;

        card.style.transform = `
            perspective(1000px)
            rotateY(${rotateY}deg)
            rotateX(${rotateX}deg)
            translateY(-8px)
        `;
    });

    card.addEventListener("mouseleave", () => {
        card.style.transform = "rotateX(0deg) rotateY(0deg) translateY(0px)";
    });
});


// ===============================
// HERO BUTTON
// ===============================

const heroBtn = document.querySelector(".hero-btn");

if (heroBtn) {
    heroBtn.addEventListener("mouseenter", () => {
        heroBtn.style.transform = "scale(1.08)";
    });
    heroBtn.addEventListener("mouseleave", () => {
        heroBtn.style.transform = "scale(1)";
    });
}


// ===============================
// CARD GLOW EFFECT
// ===============================

document.querySelectorAll(".card, .future-item").forEach(card => {
    card.addEventListener("mousemove", (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        card.style.background = `
            radial-gradient(
                circle at ${x}px ${y}px,
                rgba(255,23,68,0.14),
                rgba(17,17,17,0.90) 60%
            )
        `;
    });

    card.addEventListener("mouseleave", () => {
        card.style.background = "rgba(17,17,17,0.85)";
    });
});


// ===============================
// STATS COUNTER
// ===============================

document.querySelectorAll(".stat h2").forEach(counter => {
    let text = counter.innerText;
    let target = parseInt(text);

    if (isNaN(target)) return;

    let current = 0;
    let step = target / 80;

    function update() {
        current += step;
        if (current < target) {
            counter.innerText = Math.floor(current) + "+";
            requestAnimationFrame(update);
        } else {
            if (text.includes("%")) {
                counter.innerText = target + "%";
            } else if (text.includes("/")) {
                counter.innerText = "24/7";
            } else {
                counter.innerText = target + "+";
            }
        }
    }
    update();
});


// ===============================
// RANDOM CYBER GLOW (RED)
// ===============================

setInterval(() => {
    document.querySelectorAll(".tech").forEach(box => {
        const intensity = (Math.random() * 25).toFixed(0);
        box.style.boxShadow = `0 0 ${intensity}px rgba(255, 23, 68, 0.15)`;
    });
}, 1500);


// ===============================
// TITLE TYPING EFFECT
// ===============================

const aboutTitle = document.querySelector(".hero h4");

if (aboutTitle) {
    const origText = aboutTitle.innerText;
    aboutTitle.innerHTML = "";
    let i = 0;

    function type() {
        if (i < origText.length) {
            aboutTitle.innerHTML += origText.charAt(i);
            i++;
            setTimeout(type, 45);
        }
    }
    type();
}

console.log(
    "%cCYVERION About — Red & Black 🔴",
    "color:#FF1744;font-size:16px;font-weight:800;"
);
