const API_BASE = "";
const AUTH_TOKEN = sessionStorage.getItem("authToken");
const LOGGED_IN = sessionStorage.getItem("loggedIn") === "true" && AUTH_TOKEN;
if (!LOGGED_IN) {
  window.location.href = "login.html";
}

function authHeaders() {
  return AUTH_TOKEN ? { Authorization: `Bearer ${AUTH_TOKEN}` } : {};
}

const terminalBody = document.getElementById("terminalBody");
const jobIdLabel = document.getElementById("jobIdLabel");
const statusDot = document.getElementById("statusDot");
const statusLabel = document.getElementById("statusLabel");
const reportBody = document.getElementById("reportBody");
const reportActions = document.getElementById("reportActions");
const expandAllBtn = document.getElementById("expandAllBtn");
const collapseAllBtn = document.getElementById("collapseAllBtn");
const refreshBtn = document.getElementById("refreshBtn");

expandAllBtn.addEventListener("click", () => {
  document.querySelectorAll(".report-section").forEach(s => s.classList.add("open"));
});
collapseAllBtn.addEventListener("click", () => {
  document.querySelectorAll(".report-section").forEach(s => s.classList.remove("open"));
});
refreshBtn.addEventListener("click", () => {
  const jobId = getJobId();
  if (jobId) loadReport(jobId);
});

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str == null ? "" : String(str);
  return d.innerHTML;
}

function logLine(text, cls = "") {
  const p = document.createElement("p");
  p.className = `term-line ${cls}`;
  const ts = new Date().toLocaleTimeString();
  p.innerHTML = `<span class="term-ts">[${ts}]</span>${escapeHtml(text)}`;
  terminalBody.appendChild(p);
  terminalBody.scrollTop = terminalBody.scrollHeight;
}

function setStatus(state, label) {
  if (statusDot) statusDot.className = `status-dot ${state}`;
  if (statusLabel) statusLabel.textContent = label;
}

function getJobId() {
  const params = new URLSearchParams(window.location.search);
  return params.get("job_id");
}

function getMode() {
  const params = new URLSearchParams(window.location.search);
  return params.get("mode");
}

function scrollReportIntoView() {
  const panel = document.getElementById("reportPanel");
  if (panel) panel.scrollIntoView({ behavior: "smooth", block: "start" });
}

const SEV_ORDER = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };

function renderModule2Scorecard(s) {
  const ratingClass = s.risk_rating === "Good" ? "score-good" : s.risk_rating === "Needs Attention" ? "score-warn" : "score-bad";
  const counts = s.severity_counts || {};
  return `
    <div class="scorecard">
      <div class="scorecard-main ${ratingClass}">
        <div class="scorecard-number">${s.risk_score}</div>
        <div class="scorecard-label">/ 100 — ${escapeHtml(s.risk_rating)}</div>
      </div>
      <div class="scorecard-grid">
        <div class="scorecard-item sev-critical-text"><span class="sc-num">${counts.critical || 0}</span><span class="sc-label">Critical</span></div>
        <div class="scorecard-item sev-high-text"><span class="sc-num">${counts.high || 0}</span><span class="sc-label">High</span></div>
        <div class="scorecard-item"><span class="sc-num">${counts.medium || 0}</span><span class="sc-label">Medium</span></div>
        <div class="scorecard-item"><span class="sc-num">${counts.low || 0}</span><span class="sc-label">Low</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.total_findings || 0}</span><span class="sc-label">Total Findings</span></div>
        <div class="scorecard-item"><span class="sc-num">${(s.agents_run || []).length}</span><span class="sc-label">Agents Run</span></div>
      </div>
    </div>`;
}

function renderModule2Findings(findings) {
  if (!findings || !findings.length) {
    return `<p class="section-note">No findings were recorded for this scan.</p>`;
  }
  const sorted = [...findings].sort((a, b) => (SEV_ORDER[a.severity] ?? 9) - (SEV_ORDER[b.severity] ?? 9));
  const cards = sorted.map(f => {
    const sev = (f.severity || "info").toLowerCase();
    const sevColor = sev === "critical" ? "var(--crimson)" : sev === "high" ? "#ff8a5c" : sev === "medium" ? "var(--amber)" : sev === "low" ? "var(--blue)" : "var(--text-muted)";
    const location = f.finding_type === "source_code"
      ? `${f.file_path || ""}:${f.line || ""}`
      : `${f.method || ""} ${f.url || ""}${f.param ? " — param: " + f.param : ""}`;
    return `
      <div class="report-section open${f.is_fixed ? ' fixed-section' : ''}">
        <div class="report-section-head" style="display: flex; justify-content: space-between; align-items: center;">
          <span>
            <span style="color:${f.is_fixed ? '#10b981' : sevColor};font-family:var(--font-mono);font-size:10px;text-transform:uppercase;margin-right:8px;">${f.is_fixed ? 'FIXED' : escapeHtml(sev)}</span>
            ${escapeHtml(f.title)}
          </span>
          <span style="display: flex; align-items: center; gap: 8px;">
            ${f.is_fixed ? '<span class="fixed-badge-mini" style="font-size:11px;color:#10b981;background:rgba(16,185,129,0.1);padding:3px 8px;border-radius:4px;border:1px solid rgba(16,185,129,0.2);display:inline-flex;align-items:center;gap:3px;"><i class="fa-solid fa-circle-check"></i> Fixed</span>' : ''}
            <span class="chevron">▶</span>
          </span>
        </div>
        <div class="report-section-body">
          <p class="section-note">${escapeHtml(f.agent_label || f.agent || "")}${location ? " · " + escapeHtml(location) : ""}${f.cwe ? " · " + escapeHtml(f.cwe) : ""}</p>
          <p style="margin:8px 0;">${escapeHtml(f.description || "")}</p>
          ${f.recommendation ? `<p class="section-note"><strong>Recommendation:</strong> ${escapeHtml(f.recommendation)}</p>` : ""}
          ${f.suggested_fix ? `<pre class="raw-block" style="white-space:pre-wrap;${f.is_fixed ? 'border-color:#10b981;background:rgba(16,185,129,0.02);' : ''}">${escapeHtml(f.suggested_fix)}</pre>` : ""}
        </div>
      </div>`;
  }).join("");
  return cards;
}

function renderModule2Report(report) {
  const summary = report.executive_summary;
  const findings = report.findings || [];
  let html = "";
  if (summary) {
    html += renderModule2Scorecard(summary);
  }
  if (report.target) {
    html += section("m2-target", "🎯 Target", kvTable({ "Base URL": report.target, "Uploaded code": report.has_uploaded_code ? "Yes" : "No" }), true);
  }
  html += section("m2-findings", `🛡️ Findings (${findings.length})`, renderModule2Findings(findings), true);
  reportBody.innerHTML = html || `<p class="empty-state">No data returned.</p>`;
}

async function loadReport(jobId) {
  if (!jobId) {
    reportBody.innerHTML = `<p class="empty-state">Missing job_id in URL. Use recon.html or module2.html to trigger a scan and follow the result link.</p>`;
    setStatus("error", "Missing job ID");
    return;
  }

  const mode = getMode();
  const isModule2 = mode === "module2";
  jobIdLabel.textContent = `Report for job ${jobId}`;
  reportBody.innerHTML = `<p class="empty-state">Loading report data...</p>`;
  setStatus("running", "Loading report...");
  logLine(`Requesting ${isModule2 ? "Module 2" : "Recon"} report for job ${jobId}...`, "term-muted");

  try {
    const endpoint = isModule2 ? `/api/module2/report/${jobId}` : `/api/recon/report/${jobId}`;
    const res = await fetch(`${API_BASE}${endpoint}`, {
      headers: authHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Server responded ${res.status}`);
    }
    const data = await res.json();
    currentReport = data.report || {};
    currentJobId = jobId;

    if (isModule2) {
      renderModule2Report(currentReport);
      const downloadZipBtn = document.getElementById("downloadZipBtn");
      if (downloadZipBtn) {
        if (data.has_uploaded_code) {
          downloadZipBtn.style.display = "inline-flex";
          downloadZipBtn.onclick = () => {
            window.open(`${API_BASE}/api/module2/download_fixed/${jobId}?token=${encodeURIComponent(AUTH_TOKEN || "")}`, "_blank");
          };
        } else {
          downloadZipBtn.style.display = "none";
        }
      }
    } else {
      renderReport(currentReport);
      const downloadZipBtn = document.getElementById("downloadZipBtn");
      if (downloadZipBtn) downloadZipBtn.style.display = "none";
    }
    
    // Bind click handlers for export buttons dynamically
    const exportJsonBtn = document.getElementById("exportJsonBtn");
    const exportMdBtn = document.getElementById("exportMdBtn");
    const exportPdfBtn = document.getElementById("exportPdfBtn");
    
    if (exportJsonBtn) {
      exportJsonBtn.onclick = () => exportJson(currentReport, currentJobId);
    }
    if (exportMdBtn) {
      exportMdBtn.onclick = () => exportMarkdown(currentReport, currentJobId);
    }
    if (exportPdfBtn) {
      exportPdfBtn.onclick = () => exportPdf(currentReport, currentJobId);
    }

    reportActions.hidden = false;
    setStatus("done", "Report loaded");
    logLine("Report loaded successfully.", "term-ok");
    scrollReportIntoView();
  } catch (err) {
    reportBody.innerHTML = `<p class="empty-state">Could not load report: ${escapeHtml(err.message)}</p>`;
    reportActions.hidden = true;
    setStatus("error", "Report load failed");
    logLine(`Error loading report: ${err.message}`, "term-err");
  }
}

function renderScorecard(s) {
  const ratingClass = s.risk_rating === "Good" ? "score-good" : s.risk_rating === "Needs Attention" ? "score-warn" : "score-bad";
  return `
    <div class="scorecard">
      <div class="scorecard-main ${ratingClass}">
        <div class="scorecard-number">${s.risk_score}</div>
        <div class="scorecard-label">/ 100 — ${escapeHtml(s.risk_rating)}</div>
      </div>
      <div class="scorecard-grid">
        <div class="scorecard-item"><span class="sc-num">${s.open_ports}</span><span class="sc-label">Open Ports</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.subdomains_found}</span><span class="sc-label">Subdomains</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.endpoints_found}</span><span class="sc-label">Endpoints</span></div>
        <div class="scorecard-item sev-critical-text"><span class="sc-num">${s.cve_critical}</span><span class="sc-label">Critical CVEs</span></div>
        <div class="scorecard-item sev-high-text"><span class="sc-num">${s.cve_high}</span><span class="sc-label">High CVEs</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.total_cves}</span><span class="sc-label">Total CVEs</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.session_or_jwt_cookies}</span><span class="sc-label">Session/JWT Cookies</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.missing_security_headers}</span><span class="sc-label">Missing Headers</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.waf_detected ? "Yes" : "No"}</span><span class="sc-label">WAF Detected</span></div>
      </div>
    </div>`;
}

function section(id, title, bodyHtml, openByDefault = true) {
  return `
    <div class="report-section ${openByDefault ? "open" : ""}" id="sec-${id}">
      <div class="report-section-head" onclick="document.getElementById('sec-${id}').classList.toggle('open')">
        <span>${title}</span>
        <span class="chevron">▶</span>
      </div>
      <div class="report-section-body">${bodyHtml}</div>
    </div>`;
}

function kvTable(obj) {
  if (!obj || typeof obj !== "object") return `<p class="section-note">No data.</p>`;
  const rows = Object.entries(obj)
    .filter(([k, v]) => v !== null && v !== undefined && !(Array.isArray(v) && v.length === 0))
    .map(([k, v]) => {
      let val = Array.isArray(v) ? v.join(", ") : (typeof v === "object" ? JSON.stringify(v) : v);
      return `<tr><td>${escapeHtml(k)}</td><td>${escapeHtml(val)}</td></tr>`;
    }).join("");
  return rows ? `<table class="kv-table">${rows}</table>` : `<p class="section-note">No data returned.</p>`;
}

function tagList(items, variantFn) {
  if (!items || !items.length) return `<p class="section-note">None found.</p>`;
  return `<div class="tag-list">${items.map(i => {
    const cls = variantFn ? variantFn(i) : "";
    return `<span class="tag ${cls}">${escapeHtml(typeof i === "object" ? JSON.stringify(i) : i)}</span>`;
  }).join("")}</div>`;
}

function miniTable(rows, columns) {
  if (!rows || !rows.length) return `<p class="section-note">None found.</p>`;
  const head = columns.map(c => `<th>${escapeHtml(c.label)}</th>`).join("");
  const body = rows.map(r => `<tr>${columns.map(c => `<td class="${c.cls ? c.cls(r) : ''}">${escapeHtml(c.get(r))}</td>`).join("")}</tr>`).join("");
  return `<table class="mini-table"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
}

function linkList(items) {
  if (!items || !items.length) return `<p class="section-note">None found.</p>`;
  return `<ul class="link-list">${items.slice(0, 60).map(l =>
    `<li><a href="${escapeHtml(l)}" target="_blank" rel="noopener">${escapeHtml(l)}</a></li>`).join("")}</ul>`;
}

function rawToggle(id, content) {
  return `<span class="raw-toggle" onclick="const el=document.getElementById('${id}'); el.style.display = el.style.display==='none' ? 'block' : 'none';">▸ view raw</span>
          <div class="raw-block" id="${id}" style="display:none">${escapeHtml(content)}</div>`;
}

function renderReport(report) {
  let html = "";

  if (report.executive_summary) {
    html += renderScorecard(report.executive_summary);
  }

  if (report.target) {
    html += section("target", "🎯 Target Summary", kvTable(report.target), true);
  }

  if (report.dns_whois) {
    const d = report.dns_whois;
    let body = `<h4 style="margin:0 0 6px;color:var(--teal);font-size:11.5px;">Primary IP</h4>${kvTable({ "IP Address": d.primary_ip })}`;
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">DNS Records</h4>`;
    if (d.dns_records && Object.keys(d.dns_records).length) {
      body += miniTable(
        Object.entries(d.dns_records).flatMap(([type, vals]) => vals.map(v => ({ type, v }))),
        [{ label: "Type", get: r => r.type }, { label: "Value", get: r => r.v }]
      );
    } else {
      body += `<p class="section-note">No records resolved.</p>`;
    }
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">WHOIS</h4>`;
    body += d.whois && !d.whois.error ? kvTable(d.whois) : `<p class="section-note">WHOIS lookup unavailable: ${escapeHtml(d.whois?.error || "unknown")}.</p>`;
    html += section("dns", "🌐 Domain, DNS &amp; WHOIS", body);
  }

  if (report.subdomains) {
    const s = report.subdomains;
    let body = `<p class="section-note">${s.total_found} subdomain(s) found via ${escapeHtml(s.source || "") }.</p>`;
    body += tagList(s.subdomains);
    if (s.resolved_with_ip && s.resolved_with_ip.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Resolved with IP</h4>`;
      body += miniTable(s.resolved_with_ip, [{ label: "Subdomain", get: r => r.subdomain }, { label: "IP", get: r => r.ip }]);
    }
    html += section("subs", "🧩 Subdomains", body);
  }

  if (report.network_scan) {
    const n = report.network_scan;
    let body = kvTable({ "Scan engine": n.engine, "OS guess": n.os_guess, "Ports checked": n.ports_scanned });
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Open Ports &amp; Services</h4>`;
    body += miniTable(n.open_ports, [
      { label: "Port", get: r => r.port, cls: () => "port-open" },
      { label: "Service", get: r => r.service || r.protocol || "" },
      { label: "Version / Banner", get: r => r.version_guess || r.banner || "—" },
    ]);
    if (n.raw_output) body += rawToggle("raw-nmap", n.raw_output);
    html += section("netscan", "🛰️ Network Scan (Ports / Services / OS)", body);
  }

  if (report.web_recon) {
    const w = report.web_recon;
    let body = kvTable({
      "Status code": w.status_code, "Server banner": w.server_banner,
      "WAF/CDN detected": (w.waf_detected || []).join(", ") || "None detected",
    });
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Technologies</h4>${tagList(w.technologies, () => "tag-teal")}`;
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Cookies</h4>`;
    body += miniTable(w.cookies, [
      { label: "Name", get: r => r.name },
      { label: "Type", get: r => r.type, cls: r => r.type === "JWT" ? "cookie-jwt" : (r.type === "Session ID" ? "cookie-session" : "") },
      { label: "HttpOnly", get: r => r.http_only ? "yes" : "no" },
      { label: "Secure", get: r => r.secure ? "yes" : "no" },
      { label: "SameSite", get: r => r.same_site || "—" },
    ]);
    if (w.ssl_certificate) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">SSL Certificate</h4>${kvTable(w.ssl_certificate)}`;
    }
    if (w.headers) body += rawToggle("raw-headers", JSON.stringify(w.headers, null, 2));
    html += section("webrecon", "🔐 Web Recon (Headers / Cookies / SSL / WAF)", body);
  }

  if (report.endpoints) {
    const e = report.endpoints;
    let body = `<p class="section-note">${e.total_endpoints} total endpoint(s) discovered.</p>`;
    body += `<h4 style="margin:10px 0 6px;color:var(--teal);font-size:11.5px;">Crawled Links</h4>${linkList(e.crawled_links)}`;
    if (e.well_known_paths_present && e.well_known_paths_present.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Well-Known Paths Present</h4>`;
      body += miniTable(e.well_known_paths_present, [
        { label: "Path", get: r => r.path, cls: () => "port-open" },
        { label: "Status", get: r => r.status },
        { label: "Size (bytes)", get: r => r.size_bytes },
      ]);
    }
    if (e.forms_found && e.forms_found.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Forms</h4>`;
      body += miniTable(e.forms_found, [
        { label: "Action", get: r => r.action }, { label: "Method", get: r => r.method },
        { label: "Inputs", get: r => (r.inputs || []).join(", ") },
      ]);
    }
    if (e.disclosed_via_robots_sitemap && e.disclosed_via_robots_sitemap.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Disclosed via robots.txt / sitemap.xml</h4>`;
      body += miniTable(e.disclosed_via_robots_sitemap, [
        { label: "Source", get: r => r.source }, { label: "Directive", get: r => r.directive }, { label: "Path", get: r => r.path },
      ]);
    }
    html += section("endpoints", "🕸️ Endpoint Discovery", body);
  }

  if (report.cve_lookup) {
    const c = report.cve_lookup;
    let body = `<p class="section-note">${c.total_cves_found} CVE(s) found across ${c.software_checked} software version(s) checked against the free NVD database. ${c.note || ""}</p>`;
    if (c.findings && c.findings.length) {
      c.findings.forEach(f => {
        if (!f.cves.length) return;
        body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">${escapeHtml(f.product)} ${escapeHtml(f.version)} <span class="section-note">(${escapeHtml(f.source)})</span></h4>`;
        body += `<table class="mini-table"><thead><tr><th>CVE</th><th>Severity</th><th>CVSS</th><th>Published</th><th>Description</th></tr></thead><tbody>`;
        f.cves.forEach(cv => {
          body += `<tr>
            <td><a href="${escapeHtml(cv.url)}" target="_blank" rel="noopener" style="color:var(--blue)">${escapeHtml(cv.cve_id)}</a></td>
            <td><span class="sev-badge sev-${(cv.severity || 'unknown').toLowerCase()}">${escapeHtml(cv.severity)}</span></td>
            <td>${cv.cvss_score ?? "—"}</td>
            <td>${escapeHtml(cv.published)}</td>
            <td style="max-width:280px;">${escapeHtml(cv.description)}</td>
          </tr>`;
        });
        body += `</tbody></table>`;
      });
    }
    if (c.software_detected && c.software_detected.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">All Detected Software</h4>`;
      body += miniTable(c.software_detected, [
        { label: "Product", get: r => r.product }, { label: "Version", get: r => r.version || "—" }, { label: "Source", get: r => r.source },
      ]);
    }
    html += section("cve", "🛡️ Vulnerability Intelligence (CVE Matches)", body, true);
  }

  if (report.osint) {
    const o = report.osint;
    let body = "";
    if (o.github) {
      body += `<h4 style="margin:0 0 6px;color:var(--teal);font-size:11.5px;">GitHub</h4>`;
      body += o.github.found ? kvTable(o.github.org) : `<p class="section-note">${escapeHtml(o.github.note)}</p>`;
      if (o.github.public_members && o.github.public_members.length) {
        body += miniTable(o.github.public_members, [{ label: "Username", get: r => r.username }, { label: "Profile", get: r => r.profile }]);
      }
    }
    if (o.search_dorks) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Search Dorks (click to open manually)</h4>`;
      body += `<ul class="link-list">${Object.entries(o.search_dorks).map(([label, url]) =>
        `<li>${escapeHtml(label.replace(/_/g, " "))}: <a href="${escapeHtml(url)}" target="_blank" rel="noopener">open ↗</a></li>`).join("")}</ul>`;
      body += `<p class="section-note">These generate search-engine queries rather than scraping platforms directly — the ToS-safe way to gather this category of OSINT.</p>`;
    }
    if (o.email_pattern_examples && o.email_pattern_examples.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Email Pattern Guesses</h4>`;
      body += miniTable(o.email_pattern_examples, [{ label: "Pattern", get: r => r.pattern }, { label: "Confidence", get: r => r.confidence }]);
    }
    if (o.breach_check) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Data Breach Exposure</h4>${kvTable(o.breach_check)}`;
    }
    html += section("osint", "🕵️ OSINT — Company / Employees / Breaches", body);
  }

  reportBody.innerHTML = html || `<p class="empty-state">No data returned.</p>`;
}

window.addEventListener("DOMContentLoaded", () => {
  const jobId = getJobId();
  const mode = getMode();

  // Show the appropriate back button based on the report mode.
  const backToRecon = document.getElementById("backToRecon");
  const backToModule2 = document.getElementById("backToModule2");
  if (mode === "module2") {
    if (backToRecon) backToRecon.style.display = "none";
    if (backToModule2) backToModule2.style.display = "inline-block";
  }

  loadReport(jobId);
});

// ===== Export helpers =====
let currentReport = null;
let currentJobId = null;

function exportJson(report, jobId) {
  if (!report) return;
  const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `VAPT_Report_${jobId}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function exportMarkdown(report, jobId) {
  if (!report) return;
  const md = generateReportMarkdown(report, jobId);
  const blob = new Blob([md], { type: "text/markdown" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `VAPT_Report_${jobId}.md`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function exportPdf(report, jobId) {
  if (!report) return;
  
  const tempDiv = document.createElement("div");
  tempDiv.style.position = "fixed";
  tempDiv.style.left = "-9999px";
  tempDiv.style.top = "-9999px";
  document.body.appendChild(tempDiv);
  
  tempDiv.innerHTML = generateVaptHtmlReport(report, jobId);
  
  if (typeof html2pdf === "undefined") {
    const script = document.createElement("script");
    script.src = "https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js";
    script.onload = () => {
      runHtml2Pdf(tempDiv, jobId);
    };
    script.onerror = () => {
      alert("Failed to load PDF generation library from CDN.");
      document.body.removeChild(tempDiv);
    };
    document.head.appendChild(script);
  } else {
    runHtml2Pdf(tempDiv, jobId);
  }
}

function runHtml2Pdf(element, jobId) {
  const opt = {
    margin:       10,
    filename:     `VAPT_Report_${jobId}.pdf`,
    image:        { type: 'jpeg', quality: 0.98 },
    html2canvas:  { scale: 2, useCORS: true, letterRendering: true },
    jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' },
    pagebreak:    { mode: ['avoid-all', 'css', 'legacy'] }
  };
  
  html2pdf().from(element).set(opt).save().then(() => {
    document.body.removeChild(element);
  });
}

function generateReportMarkdown(report, jobId) {
  const target = report.target || report.base_url || "N/A";
  const riskScore = report.executive_summary?.risk_score ?? 100;
  const riskRating = report.executive_summary?.risk_rating || "HIGH";
  
  let md = `# VAPT HIGH-LEVEL TESTER REPORT\n\n`;
  md += `## 1. Report Information\n\n`;
  md += `| Field | Details |\n`;
  md += `| :--- | :--- |\n`;
  md += `| Report ID | VAPT-${jobId.toUpperCase()} |\n`;
  md += `| Client / Organization | Cyverion Security User |\n`;
  md += `| Target Domain | ${target} |\n`;
  md += `| Assessment Type | Vulnerability Assessment / Penetration Testing |\n`;
  md += `| Testing Status | Completed |\n`;
  md += `| Tester / Team | Cyverion Automated Core |\n`;
  md += `| Time Zone | IST (UTC+05:30) |\n`;
  md += `\n---\n\n`;
  
  md += `## 2. Executive Summary\n\n`;
  md += `A automated security assessment was performed against the target: **${target}**.\n\n`;
  md += `### Overall Security Rating\n\n`;
  md += `**Risk Level: ${riskRating.toUpperCase()} (Score: ${riskScore}/100)**\n\n`;
  md += `### Assessment Summary\n\n`;
  md += `| Metric | Result |\n`;
  md += `| :--- | ---: |\n`;
  md += `| Subdomains Discovered | ${report.subdomains?.total_found ?? 0} |\n`;
  md += `| Open Ports Identified | ${(report.network_scan?.open_ports || []).length} |\n`;
  md += `| Vulnerabilities Found | ${(report.findings || []).length} |\n`;
  md += `| Critical | ${report.executive_summary?.severity_counts?.critical ?? report.executive_summary?.cve_critical ?? 0} |\n`;
  md += `| High | ${report.executive_summary?.severity_counts?.high ?? report.executive_summary?.cve_high ?? 0} |\n`;
  md += `| Medium | ${report.executive_summary?.severity_counts?.medium ?? 0} |\n`;
  md += `| Low | ${report.executive_summary?.severity_counts?.low ?? 0} |\n`;
  md += `\n---\n\n`;
  
  md += `## 3. Technology Stack\n\n`;
  md += `* **Web Server**: ${report.web_recon?.server_banner || "N/A"}\n`;
  md += `* **Exposed Technologies**: ${(report.web_recon?.technologies || []).join(", ") || "N/A"}\n`;
  md += `* **CDN/WAF**: ${(report.web_recon?.waf_detected || []).join(", ") || "None Detected"}\n\n`;
  md += `\n---\n\n`;
  
  md += `## 4. Service & Port Discovery\n\n`;
  md += `| Port | Service | Version banner / OS guess |\n`;
  md += `| :--- | :--- | :--- |\n`;
  if (report.network_scan?.open_ports && report.network_scan.open_ports.length) {
    report.network_scan.open_ports.forEach(p => {
      md += `| ${p.port} | ${p.service || p.protocol || "N/A"} | ${p.version_guess || p.banner || "—"} |\n`;
    });
  } else {
    md += `| — | — | No open ports identified |\n`;
  }
  md += `\n---\n\n`;
  
  md += `## 5. Detailed Findings Report\n\n`;
  if (report.findings && report.findings.length) {
    report.findings.forEach((f, i) => {
      md += `### VAPT-${String(i+1).padStart(3, '0')} — ${f.title}\n\n`;
      md += `* **Severity**: ${f.severity.toUpperCase()}\n`;
      md += `* **CWE**: ${f.cwe || "N/A"}\n`;
      md += `* **Affected Endpoint**: ${f.url || f.file_path || "N/A"}\n`;
      md += `* **Status**: ${f.is_fixed ? "Remediation Confirmed" : "Active"}\n\n`;
      md += `#### Description\n\n${f.description || "No description provided."}\n\n`;
      if (f.evidence) {
        const evidenceStr = typeof f.evidence === 'string' ? f.evidence : (f.evidence.code_snippet || f.evidence.request || JSON.stringify(f.evidence, null, 2));
        md += `#### Evidence\n\n\`\`\`\n${evidenceStr}\n\`\`\`\n\n`;
      }
      md += `#### Recommendation\n\n${f.recommendation || "Implement standard remediation controls."}\n\n`;
      if (f.suggested_fix) {
        md += `#### Suggested Secure Fix\n\n\`\`\`\n${f.suggested_fix}\n\`\`\`\n\n`;
      }
      md += `\n---\n\n`;
    });
  } else {
    md += `*No findings were recorded for this scan.*\n`;
  }
  
  return md;
}

function generateVaptHtmlReport(report, jobId) {
  const target = report.target || report.base_url || "N/A";
  const riskScore = report.executive_summary?.risk_score ?? 100;
  const riskRating = report.executive_summary?.risk_rating || "HIGH";
  
  return `
    <div style="font-family: 'Inter', 'Segoe UI', Arial, sans-serif; color: #1e293b; padding: 25px; background: #fff; box-sizing: border-box;">
      <div style="border-bottom: 2px solid #0f172a; padding-bottom: 15px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center;">
        <div>
          <h1 style="margin: 0; font-size: 26px; color: #e11d48; font-weight: 800; letter-spacing: 0.5px;">CYVERION</h1>
          <p style="margin: 4px 0 0 0; font-size: 13px; font-weight: 700; text-transform: uppercase; color: #64748b; letter-spacing: 0.5px;">VAPT High-Level Tester Report</p>
        </div>
        <div style="text-align: right;">
          <p style="margin: 0; font-size: 12px; color: #475569;">Report ID: <strong>VAPT-${jobId.toUpperCase()}</strong></p>
          <p style="margin: 4px 0 0 0; font-size: 11px; color: #94a3b8;">Generated: ${new Date().toLocaleString()}</p>
        </div>
      </div>

      <div style="margin-bottom: 30px;">
        <h2 style="font-size: 15px; border-left: 4px solid #e11d48; padding-left: 8px; margin-bottom: 12px; color: #0f172a; text-transform: uppercase; font-weight: 700;">1. Report Information</h2>
        <table style="width: 100%; border-collapse: collapse; font-size: 12.5px;">
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; width: 30%; background: #f8fafc; color: #475569;">Report ID</td>
            <td style="padding: 7px; color: #1e293b; font-family: monospace;">VAPT-${jobId.toUpperCase()}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; background: #f8fafc; color: #475569;">Target URL/Domain</td>
            <td style="padding: 7px; color: #1e293b; font-family: monospace;">${escapeHtml(target)}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; background: #f8fafc; color: #475569;">Assessment Type</td>
            <td style="padding: 7px; color: #1e293b;">Vulnerability Assessment / Penetration Testing</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; background: #f8fafc; color: #475569;">Testing Status</td>
            <td style="padding: 7px; font-weight: 700; color: #10b981;">Completed</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; background: #f8fafc; color: #475569;">Tester Team</td>
            <td style="padding: 7px; color: #1e293b;">Cyverion Automated Security Core</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; background: #f8fafc; color: #475569;">Time Zone</td>
            <td style="padding: 7px; color: #1e293b;">IST (UTC+05:30)</td>
          </tr>
        </table>
      </div>

      <div style="margin-bottom: 30px; page-break-inside: avoid;">
        <h2 style="font-size: 15px; border-left: 4px solid #e11d48; padding-left: 8px; margin-bottom: 12px; color: #0f172a; text-transform: uppercase; font-weight: 700;">2. Executive Summary</h2>
        <p style="font-size: 13px; line-height: 1.55; margin: 0 0 15px 0; color: #334155;">
          A security vulnerability assessment was completed against the target **${escapeHtml(target)}**. 
          This high-level summary encapsulates subdomain intelligence, service mapping, open ports detection, and correlated common vulnerabilities and exposures (CVEs).
        </p>
        
        <div style="display: flex; gap: 15px; margin-bottom: 15px;">
          <div style="flex: 1; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; text-align: center; background: #fffcfc; border-left: 4px solid #e11d48;">
            <p style="margin: 0; font-size: 10.5px; text-transform: uppercase; font-weight: 600; color: #64748b;">Risk Rating</p>
            <h3 style="margin: 4px 0 0 0; font-size: 20px; font-weight: 800; color: ${riskRating === 'Good' ? '#10b981' : (riskRating === 'Needs Attention' ? '#f59e0b' : '#e11d48')};">${escapeHtml(riskRating)}</h3>
          </div>
          <div style="flex: 1; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; text-align: center; background: #f8fafc;">
            <p style="margin: 0; font-size: 10.5px; text-transform: uppercase; font-weight: 600; color: #64748b;">Risk Score</p>
            <h3 style="margin: 4px 0 0 0; font-size: 20px; font-weight: 800; color: #0f172a;">${riskScore} / 100</h3>
          </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; font-size: 12.5px;">
          <thead>
            <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1; text-align: left;">
              <th style="padding: 7px; font-weight: 600; color: #475569;">Assessment Metric</th>
              <th style="padding: 7px; font-weight: 600; color: #475569; text-align: right;">Result</th>
            </tr>
          </thead>
          <tbody>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 7px; color: #334155;">Subdomains Discovered</td>
              <td style="padding: 7px; color: #1e293b; text-align: right; font-weight: 600;">${report.subdomains?.total_found ?? 0}</td>
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 7px; color: #334155;">Open Ports Identified</td>
              <td style="padding: 7px; color: #1e293b; text-align: right; font-weight: 600;">${(report.network_scan?.open_ports || []).length}</td>
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 7px; color: #334155;">Total Vulnerabilities Found</td>
              <td style="padding: 7px; color: #e11d48; text-align: right; font-weight: 600;">${(report.findings || []).length}</td>
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 7px; color: #64748b; padding-left: 20px; font-size: 11.5px;">Critical Severity</td>
              <td style="padding: 7px; color: #e11d48; text-align: right; font-weight: 600; font-size: 11.5px;">${report.executive_summary?.severity_counts?.critical ?? report.executive_summary?.cve_critical ?? 0}</td>
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 7px; color: #64748b; padding-left: 20px; font-size: 11.5px;">High Severity</td>
              <td style="padding: 7px; color: #f59e0b; text-align: right; font-weight: 600; font-size: 11.5px;">${report.executive_summary?.severity_counts?.high ?? report.executive_summary?.cve_high ?? 0}</td>
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 7px; color: #64748b; padding-left: 20px; font-size: 11.5px;">Medium Severity</td>
              <td style="padding: 7px; color: #334155; text-align: right; font-weight: 600; font-size: 11.5px;">${report.executive_summary?.severity_counts?.medium ?? 0}</td>
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 7px; color: #64748b; text-align: right; font-weight: 600; font-size: 11.5px;">${report.executive_summary?.severity_counts?.low ?? 0}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div style="margin-bottom: 30px; page-break-inside: avoid;">
        <h2 style="font-size: 15px; border-left: 4px solid #e11d48; padding-left: 8px; margin-bottom: 12px; color: #0f172a; text-transform: uppercase; font-weight: 700;">3. Scope &amp; Tech Stack</h2>
        <table style="width: 100%; border-collapse: collapse; font-size: 12.5px;">
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; width: 30%; background: #f8fafc; color: #475569;">Web Server</td>
            <td style="padding: 7px; color: #1e293b;">${escapeHtml(report.web_recon?.server_banner || "N/A")}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; background: #f8fafc; color: #475569;">Technologies</td>
            <td style="padding: 7px; color: #1e293b;">${escapeHtml((report.web_recon?.technologies || []).join(", ") || "N/A")}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; background: #f8fafc; color: #475569;">WAF/CDN</td>
            <td style="padding: 7px; color: #1e293b;">${escapeHtml((report.web_recon?.waf_detected || []).join(", ") || "None Detected")}</td>
          </tr>
        </table>
      </div>

      <div style="margin-bottom: 30px;">
        <h2 style="font-size: 15px; border-left: 4px solid #e11d48; padding-left: 8px; margin-bottom: 12px; color: #0f172a; text-transform: uppercase; font-weight: 700;">4. Port Discovery &amp; Services</h2>
        <table style="width: 100%; border-collapse: collapse; font-size: 12.5px; text-align: left;">
          <thead>
            <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
              <th style="padding: 7px; font-weight: 600; color: #475569;">Port</th>
              <th style="padding: 7px; font-weight: 600; color: #475569;">Service</th>
              <th style="padding: 7px; font-weight: 600; color: #475569;">Version Guess / Banner</th>
            </tr>
          </thead>
          <tbody>
            ${(report.network_scan?.open_ports || []).map(p => `
              <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="padding: 7px; color: #0284c7; font-weight: 700; font-family: monospace;">${escapeHtml(p.port)}</td>
                <td style="padding: 7px; color: #1e293b;">${escapeHtml(p.service || p.protocol || "N/A")}</td>
                <td style="padding: 7px; color: #475569; font-family: monospace; font-size: 11.5px;">${escapeHtml(p.version_guess || p.banner || "—")}</td>
              </tr>
            `).join("") || `<tr><td colspan="3" style="padding: 10px; text-align: center; color: #64748b; font-style: italic;">No open ports identified.</td></tr>`}
          </tbody>
        </table>
      </div>

      <div style="page-break-before: always;"></div>

      <div style="margin-bottom: 30px;">
        <h2 style="font-size: 15px; border-left: 4px solid #e11d48; padding-left: 8px; margin-bottom: 15px; color: #0f172a; text-transform: uppercase; font-weight: 700;">5. Detailed Findings Report</h2>
        
        ${(report.findings || []).map((f, i) => {
          const sev = (f.severity || "info").toLowerCase();
          const sevColor = sev === 'critical' ? '#e11d48' : (sev === 'high' ? '#f59e0b' : (sev === 'medium' ? '#3b82f6' : '#64748b'));
          const bg = sev === 'critical' ? '#fff1f2' : (sev === 'high' ? '#fffbeb' : '#f8fafc');
          
          let evidenceText = "";
          if (f.evidence) {
            evidenceText = typeof f.evidence === 'string' ? f.evidence : (f.evidence.code_snippet || f.evidence.request || JSON.stringify(f.evidence, null, 2));
          }
          
          return `
            <div style="border: 1px solid #e2e8f0; border-radius: 6px; margin-bottom: 20px; page-break-inside: avoid; background: ${bg}; overflow: hidden;">
              <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 15px; border-bottom: 1px solid #e2e8f0; background: #fff;">
                <span style="font-weight: 700; font-size: 13.5px; color: #0f172a;">VAPT-${String(i+1).padStart(3, '0')} — ${escapeHtml(f.title)}</span>
                <span style="background: ${sevColor}; color: #fff; font-size: 10.5px; font-weight: 700; text-transform: uppercase; padding: 2px 7px; border-radius: 3px; font-family: monospace;">${escapeHtml(sev)}</span>
              </div>
              <div style="padding: 15px; font-size: 12.5px;">
                <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 11.5px;">
                  <tr style="border-bottom: 1px dashed #cbd5e1;">
                    <td style="padding: 4px 0; font-weight: 600; width: 25%; color: #64748b;">Classification / CWE</td>
                    <td style="padding: 4px 0; color: #1e293b; font-family: monospace;">${escapeHtml(f.cwe || "N/A")}</td>
                  </tr>
                  <tr style="border-bottom: 1px dashed #cbd5e1;">
                    <td style="padding: 4px 0; font-weight: 600; color: #64748b;">Endpoint / File Location</td>
                    <td style="padding: 4px 0; color: #1e293b; font-family: monospace; word-break: break-all;">${escapeHtml(f.url || f.file_path || "N/A")}${f.line ? ` (Line ${f.line})` : ''}</td>
                  </tr>
                  ${f.param ? `
                    <tr style="border-bottom: 1px dashed #cbd5e1;">
                      <td style="padding: 4px 0; font-weight: 600; color: #64748b;">Parameter</td>
                      <td style="padding: 4px 0; color: #1e293b; font-family: monospace;">${escapeHtml(f.param)}</td>
                    </tr>
                  ` : ''}
                  <tr style="border-bottom: 1px dashed #cbd5e1;">
                    <td style="padding: 4px 0; font-weight: 600; color: #64748b;">Status</td>
                    <td style="padding: 4px 0; font-weight: 700; color: ${f.is_fixed ? '#10b981' : '#e11d48'};">${f.is_fixed ? '✓ Remediation Confirmed' : '⚠ Active'}</td>
                  </tr>
                </table>

                <p style="margin: 0 0 5px 0; font-weight: 600; color: #475569;">Description</p>
                <p style="margin: 0 0 12px 0; line-height: 1.5; color: #334155;">${escapeHtml(f.description || "No description provided.")}</p>

                ${evidenceText ? `
                  <p style="margin: 0 0 4px 0; font-weight: 600; color: #475569;">Evidence</p>
                  <pre style="margin: 0 0 12px 0; padding: 8px; background: #0f172a; color: #38bdf8; border-radius: 4px; font-family: monospace; font-size: 11px; overflow-x: auto; white-space: pre-wrap; line-height: 1.4;">${escapeHtml(evidenceText)}</pre>
                ` : ''}

                <p style="margin: 0 0 4px 0; font-weight: 600; color: #475569;">Recommendation</p>
                <p style="margin: 0; line-height: 1.5; color: #334155; font-weight: 500; border-left: 2px solid #10b981; padding-left: 6px;">${escapeHtml(f.recommendation || "Implement secure parameterization/encoding controls.")}</p>

                ${f.suggested_fix ? `
                  <p style="margin: 12px 0 4px 0; font-weight: 600; color: #475569;">Suggested Secure Patch</p>
                  <pre style="margin: 0; padding: 8px; background: #f1f5f9; color: #0f172a; border-radius: 4px; font-family: monospace; font-size: 11.5px; border: 1px dashed #cbd5e1; overflow-x: auto; white-space: pre-wrap; line-height: 1.4;">${escapeHtml(f.suggested_fix)}</pre>
                ` : ''}
              </div>
            </div>
          `;
        }).join("") || `<p style="text-align: center; color: #64748b; font-style: italic; padding: 15px;">No findings recorded for this scan.</p>`}
      </div>

      <div style="margin-top: 40px; border-top: 1px solid #cbd5e1; padding-top: 15px; page-break-inside: avoid;">
        <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #64748b;">
          <tr>
            <td style="width: 50%;">
              <p style="margin: 0 0 2px 0;">Report Version: <strong>1.0 (Confidential)</strong></p>
              <p style="margin: 0;">System ID: <strong>CY-${jobId.toUpperCase()}</strong></p>
            </td>
            <td style="text-align: right; width: 50%;">
              <p style="margin: 0 0 2px 0; font-weight: 600; color: #475569;">Cyverion Automated Platform</p>
              <p style="margin: 0;">Testing completed successfully.</p>
            </td>
          </tr>
        </table>
      </div>
    </div>
  `;
}
