// ==========================================================================
//  CYVERION — Admin Console logic (upgraded)
// ==========================================================================
const API_BASE = "";
const AUTH_TOKEN = sessionStorage.getItem("authToken");
const LOGGED_IN = sessionStorage.getItem("loggedIn") === "true" && AUTH_TOKEN;
const USER_ROLE = (sessionStorage.getItem("userRole") || "").toLowerCase();

if (!LOGGED_IN) {
  window.location.href = "login.html";
} else if (USER_ROLE !== "admin" && USER_ROLE !== "administrator") {
  // Signed in, but not an admin — send them back to their own console.
  window.location.href = getPageForRole(USER_ROLE);
}

function authHeaders() {
  return AUTH_TOKEN ? { Authorization: `Bearer ${AUTH_TOKEN}` } : {};
}

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str == null ? "" : String(str);
  return d.innerHTML;
}

function formatDateTime(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.valueOf())) return String(value);
  return date.toLocaleString();
}

function initials(name) {
  const parts = String(name || "").trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "?";
  return (parts[0][0] + (parts[1] ? parts[1][0] : "")).toUpperCase();
}

/* ==========================================================================
   3D Cyber Background - Three.js Particle Network (matches recon.html)
   ========================================================================== */
(function init3DBackground() {
  const canvas = document.getElementById('bg-canvas');
  if (!canvas || typeof THREE === 'undefined') return;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  const renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true, antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  const particlesGeometry = new THREE.BufferGeometry();
  const particlesCount = 1400;
  const posArray = new Float32Array(particlesCount * 3);
  for (let i = 0; i < particlesCount * 3; i++) {
    posArray[i] = (Math.random() - 0.5) * 12;
  }
  particlesGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));

  const particlesMaterial = new THREE.PointsMaterial({
    size: 0.015, color: 0xFF1744, transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending,
  });
  const particlesMesh = new THREE.Points(particlesGeometry, particlesMaterial);
  scene.add(particlesMesh);

  const torusGeo = new THREE.TorusKnotGeometry(0.3, 0.1, 64, 8);
  const torusMat = new THREE.MeshBasicMaterial({ color: 0xFF6D00, wireframe: true, transparent: true, opacity: 0.08 });
  const torus = new THREE.Mesh(torusGeo, torusMat);
  torus.position.set(1.5, -0.5, -2);
  scene.add(torus);

  camera.position.z = 4;
  let mouseX = 0, mouseY = 0;
  document.addEventListener('mousemove', (e) => {
    mouseX = (e.clientX / window.innerWidth - 0.5) * 0.3;
    mouseY = (e.clientY / window.innerHeight - 0.5) * 0.3;
  });

  function animate() {
    requestAnimationFrame(animate);
    particlesMesh.rotation.x += 0.0003;
    particlesMesh.rotation.y += 0.0005;
    torus.rotation.x += 0.005;
    torus.rotation.y += 0.008;
    camera.position.x += (mouseX - camera.position.x) * 0.02;
    camera.position.y += (mouseY - camera.position.y) * 0.02;
    camera.lookAt(scene.position);
    renderer.render(scene, camera);
  }
  animate();

  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });
})();

// ==========================================================================
//  Toasts
// ==========================================================================
function toast(message, type = "info", timeoutMs = 4200) {
  const stack = document.getElementById("toastStack");
  if (!stack) return;
  const icon = type === "success" ? "fa-circle-check" : type === "error" ? "fa-circle-exclamation" : "fa-circle-info";
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.innerHTML = `<i class="fa-solid ${icon}"></i><span>${escapeHtml(message)}</span>`;
  stack.appendChild(el);
  setTimeout(() => {
    el.style.transition = "opacity .2s ease";
    el.style.opacity = "0";
    setTimeout(() => el.remove(), 200);
  }, timeoutMs);
}

// ==========================================================================
//  Confirm modal (replaces window.confirm)
// ==========================================================================
function confirmDialog(title, message) {
  return new Promise((resolve) => {
    const overlay = document.getElementById("confirmOverlay");
    document.getElementById("confirmTitle").textContent = title;
    document.getElementById("confirmMessage").textContent = message;
    overlay.classList.add("show");

    const okBtn = document.getElementById("confirmOkBtn");
    const cancelBtn = document.getElementById("confirmCancelBtn");

    function cleanup(result) {
      overlay.classList.remove("show");
      okBtn.removeEventListener("click", onOk);
      cancelBtn.removeEventListener("click", onCancel);
      overlay.removeEventListener("click", onOverlay);
      resolve(result);
    }
    function onOk() { cleanup(true); }
    function onCancel() { cleanup(false); }
    function onOverlay(e) { if (e.target === overlay) cleanup(false); }

    okBtn.addEventListener("click", onOk);
    cancelBtn.addEventListener("click", onCancel);
    overlay.addEventListener("click", onOverlay);
  });
}

// ==========================================================================
//  Drawer (user / scan detail slide-over)
// ==========================================================================
function openDrawer(html) {
  document.getElementById("drawerContent").innerHTML = html;
  document.getElementById("drawerOverlay").classList.add("show");
}
function closeDrawer() {
  document.getElementById("drawerOverlay").classList.remove("show");
}
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("drawerClose").addEventListener("click", closeDrawer);
  document.getElementById("drawerOverlay").addEventListener("click", (e) => {
    if (e.target.id === "drawerOverlay") closeDrawer();
  });
});

function openUserDrawer(userId) {
  const u = state.users.find(x => String(x.id) === String(userId));
  if (!u) return;
  const status = (u.account_status || "ACTIVE").toUpperCase();
  const isSuspended = status === "SUSPENDED";
  const name = `${u.first_name || ""} ${u.last_name || ""}`.trim() || u.email;
  const userScans = combinedScans().filter(s => String(s.user_id ?? "") === String(u.id) || s.user_email === u.email);

  const scansHtml = userScans.length
    ? userScans.slice(0, 8).map(s => `
      <div class="drawer-scan-item">
        <div class="ds-target">${escapeHtml(s.target || "—")}</div>
        <div class="ds-meta">${escapeHtml(s.job_type)} · <span class="status-badge ${escapeHtml((s.status||'').toLowerCase())}">${escapeHtml(s.status || "unknown")}</span> · ${formatDateTime(s.created_at)}</div>
      </div>`).join("")
    : `<p class="section-note">No scans from this user yet.</p>`;

  openDrawer(`
    <div class="drawer-header">
      <div class="drawer-avatar">${escapeHtml(initials(name))}</div>
      <div>
        <div class="drawer-title">${escapeHtml(name)}</div>
        <div class="drawer-subtitle">${escapeHtml(u.email || "")}</div>
      </div>
    </div>
    <div class="drawer-section">
      <h4>Account</h4>
      <div class="kv-row"><span>Role</span><span>${escapeHtml(u.role || "—")}</span></div>
      <div class="kv-row"><span>Status</span><span><span class="status-badge ${isSuspended ? "suspended" : "active"}">${isSuspended ? "Suspended" : "Active"}</span></span></div>
      <div class="kv-row"><span>Organization</span><span>${escapeHtml(u.organization || "—")}</span></div>
      <div class="kv-row"><span>Created</span><span>${formatDateTime(u.created_at)}</span></div>
      <div class="kv-row"><span>User ID</span><span>#${escapeHtml(u.id)}</span></div>
      <div class="kv-row"><span>Total scans</span><span>${userScans.length}</span></div>
    </div>
    <div class="drawer-section">
      <h4>Actions</h4>
      <div class="drawer-actions">
        <button type="button" class="btn-mini" id="drawerToggleStatusBtn"><i class="fa-solid ${isSuspended ? "fa-user-check" : "fa-user-slash"}"></i> ${isSuspended ? "Reinstate" : "Suspend"}</button>
        <button type="button" class="btn-mini" id="drawerDeleteBtn"><i class="fa-solid fa-trash"></i> Delete user</button>
      </div>
    </div>
    <div class="drawer-section">
      <h4>Recent scans</h4>
      ${scansHtml}
    </div>
  `);

  document.getElementById("drawerToggleStatusBtn").addEventListener("click", async () => {
    await updateUserStatus(u.id, isSuspended ? "ACTIVE" : "SUSPENDED");
    closeDrawer();
  });
  document.getElementById("drawerDeleteBtn").addEventListener("click", async () => {
    closeDrawer();
    await deleteUser(u.id);
  });
}

function openScanDrawer(jobType, jobId) {
  const s = combinedScans().find(r => r.job_type === jobType && String(r.job_id) === String(jobId));
  if (!s) return;
  openDrawer(`
    <div class="drawer-header">
      <div class="drawer-avatar"><i class="fa-solid ${s.job_type === "recon" ? "fa-satellite-dish" : "fa-microchip"}"></i></div>
      <div>
        <div class="drawer-title">${escapeHtml(s.target || "Unknown target")}</div>
        <div class="drawer-subtitle">${escapeHtml(s.job_type)} job</div>
      </div>
    </div>
    <div class="drawer-section">
      <h4>Details</h4>
      <div class="kv-row"><span>Status</span><span><span class="status-badge ${escapeHtml((s.status||'').toLowerCase())}">${escapeHtml(s.status || "unknown")}</span></span></div>
      <div class="kv-row"><span>Launched by</span><span>${escapeHtml(s.user_email || "—")}</span></div>
      <div class="kv-row"><span>Created</span><span>${formatDateTime(s.created_at)}</span></div>
      <div class="kv-row"><span>Job ID</span><span>${escapeHtml(s.job_id)}</span></div>
    </div>
    <div class="drawer-section">
      <h4>Actions</h4>
<div class="drawer-actions">
        ${s.job_type === "recon" ? `<a class="btn-mini" href="view.html?job_id=${encodeURIComponent(s.job_id)}"><i class="fa-solid fa-arrow-up-right-from-square"></i> Open full report</a>` : `<a class="btn-mini" href="view.html?job_id=${encodeURIComponent(s.job_id)}&mode=module2"><i class="fa-solid fa-arrow-up-right-from-square"></i> Open full report</a>`}
      </div>
    </div>
  `);
}

// ==========================================================================
//  CSV export
// ==========================================================================
function downloadCsv(filename, rows, columns) {
  const escapeCsv = (v) => {
    const s = v == null ? "" : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const header = columns.map(c => escapeCsv(c.label)).join(",");
  const lines = rows.map(r => columns.map(c => escapeCsv(c.get(r))).join(","));
  const csv = [header, ...lines].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  toast(`Exported ${rows.length} row${rows.length === 1 ? "" : "s"} to ${filename}`, "success");
}

// ==========================================================================
//  Settings (persisted locally — density / auto-refresh / page size)
// ==========================================================================
const SETTINGS_KEY = "cyverion_admin_settings_v1";
const SECURITY_KEY = "cyverion_admin_security_v1";
const ADVANCED_KEY = "cyverion_admin_advanced_v1";
const MAINT_KEY = "cyverion_admin_maintenance_v1";
const DEFAULT_SETTINGS = { density: "comfortable", autoRefresh: false, refreshInterval: 30000, pageSize: 25 };
const DEFAULT_SECURITY = {
  twoFA: false,
  sessionTimeout: false,
  auditRetention: 90,
  bruteForce: false,
  strongPasswords: false,
  notifyLogin: false,
  encryptReports: false,
};
const DEFAULT_ADVANCED = {
  backup: false,
  backupSchedule: "weekly",
  rateLimiting: false,
  scanApproval: false,
  emailAlerts: false,
  videoRetention: 30,
  lockScanConfig: false,
  compliance: false,
  cloudSync: false,
  restrictAdmin: false,
};
const DEFAULT_MAINT = { maintenance: false };

function loadSettings() {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    return raw ? { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } : { ...DEFAULT_SETTINGS };
  } catch (e) {
    return { ...DEFAULT_SETTINGS };
  }
}
function saveSettings() {
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch (e) { /* ignore quota errors */ }
}

// ---- Security hardening settings (persisted locally, applied per-browser) ----
function loadSecurity() {
  try {
    const raw = localStorage.getItem(SECURITY_KEY);
    return raw ? { ...DEFAULT_SECURITY, ...JSON.parse(raw) } : { ...DEFAULT_SECURITY };
  } catch (e) {
    return { ...DEFAULT_SECURITY };
  }
}
function saveSecurity() {
  try { localStorage.setItem(SECURITY_KEY, JSON.stringify(security)); } catch (e) { /* ignore quota errors */ }
}
function applySecurityToDom() {
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val ? "on" : "off"; };
  const setCheck = (id, val) => { const el = document.getElementById(id); if (el) el.checked = !!val; };
  setCheck("sec2faToggle", security.twoFA); set("sec2faStatus", security.twoFA);
  setCheck("secTimeoutToggle", security.sessionTimeout); set("secTimeoutStatus", security.sessionTimeout);
  setCheck("secBruteToggle", security.bruteForce); set("secBruteStatus", security.bruteForce);
  setCheck("secStrongPwToggle", security.strongPasswords); set("secStrongPwStatus", security.strongPasswords);
  setCheck("secNotifyLoginToggle", security.notifyLogin); set("secNotifyLoginStatus", security.notifyLogin);
  setCheck("secEncryptToggle", security.encryptReports); set("secEncryptStatus", security.encryptReports);
  const audit = document.getElementById("secAuditSelect");
  if (audit) audit.value = String(security.auditRetention);
  // status badge classes
  [["sec2faStatus", security.twoFA], ["secTimeoutStatus", security.sessionTimeout],
   ["secBruteStatus", security.bruteForce], ["secStrongPwStatus", security.strongPasswords],
   ["secNotifyLoginStatus", security.notifyLogin], ["secEncryptStatus", security.encryptReports]
  ].forEach(([id, on]) => {
    const el = document.getElementById(id);
    if (el) el.classList.toggle("on", !!on);
  });
}
function initSecurityPanel() {
  applySecurityToDom();

  // "More security features" expand/collapse
  const moreBtn = document.getElementById("secMoreBtn");
  const morePanel = document.getElementById("secMorePanel");
  const caret = document.getElementById("secMoreCaret");
  if (moreBtn && morePanel) {
    moreBtn.addEventListener("click", () => {
      const isOpen = !morePanel.hidden;
      morePanel.hidden = isOpen;
      if (caret) caret.classList.toggle("expanded", isOpen);
      if (isOpen) {
        moreBtn.innerHTML = `<i class="fa-solid fa-shield"></i> More security features <span class="sec-more-caret" id="secMoreCaret">▸</span>`;
      } else {
        moreBtn.innerHTML = `<i class="fa-solid fa-shield"></i> More security features <span class="sec-more-caret expanded" id="secMoreCaret">▾</span>`;
        document.getElementById("secMoreCaret").classList.add("expanded");
      }
    });
  }

  const bindToggle = (toggleId, key, label) => {
    const t = document.getElementById(toggleId);
    if (!t) return;
    t.addEventListener("change", (e) => {
      security[key] = e.target.checked;
      saveSecurity();
      applySecurityToDom();
      toast(`${label} ${security[key] ? "enabled" : "disabled"}`, "info");
    });
  };
  bindToggle("sec2faToggle", "twoFA", "2FA requirement");
  bindToggle("secTimeoutToggle", "sessionTimeout", "Session timeout lock");
  bindToggle("secBruteToggle", "bruteForce", "Brute-force protection");
  bindToggle("secStrongPwToggle", "strongPasswords", "Strong password policy");
  bindToggle("secNotifyLoginToggle", "notifyLogin", "Admin login notifications");
  bindToggle("secEncryptToggle", "encryptReports", "Report encryption");

  const audit = document.getElementById("secAuditSelect");
  if (audit) {
    audit.addEventListener("change", () => {
      security.auditRetention = Number(audit.value);
      saveSecurity();
      toast(`Audit retention set to ${audit.options[audit.selectedIndex].text}`, "info");
    });
  }

  const regenBtn = document.getElementById("secRegenTokenBtn");
  if (regenBtn) {
    regenBtn.addEventListener("click", async () => {
      const ok = await confirmDialog("Regenerate API token?", "This invalidates your current API token immediately. Continue?");
      if (!ok) return;
      const token = Array.from({ length: 4 }, () => Math.random().toString(36).slice(2, 8)).join("-").toUpperCase();
      const chip = document.getElementById("secApiToken");
      if (chip) chip.textContent = token.slice(0, 12) + "…";
      toast("API token regenerated", "success");
    });
  }

  const revokeBtn = document.getElementById("secRevokeBtn");
  if (revokeBtn) {
    revokeBtn.addEventListener("click", async () => {
      const ok = await confirmDialog("Revoke all other sessions?", "Every active session except this one will be signed out. Continue?");
      if (!ok) return;
      try {
        if (AUTH_TOKEN) {
          await fetch(`${API_BASE}/api/auth/logout`, { method: "POST", headers: authHeaders() });
        }
      } catch (err) { /* best effort */ }
      toast("All other sessions revoked. This session remains active.", "success");
    });
  }
}

const settings = loadSettings();
const security = loadSecurity();
const advanced = loadAdvanced();
const maint = loadMaintenance();
let autoRefreshTimer = null;

// ---- Advanced platform controls (persisted locally) ----
function loadAdvanced() {
  try {
    const raw = localStorage.getItem(ADVANCED_KEY);
    return raw ? { ...DEFAULT_ADVANCED, ...JSON.parse(raw) } : { ...DEFAULT_ADVANCED };
  } catch (e) {
    return { ...DEFAULT_ADVANCED };
  }
}
function saveAdvanced() {
  try { localStorage.setItem(ADVANCED_KEY, JSON.stringify(advanced)); } catch (e) { /* ignore */ }
}
function loadMaintenance() {
  try {
    const raw = localStorage.getItem(MAINT_KEY);
    return raw ? { ...DEFAULT_MAINT, ...JSON.parse(raw) } : { ...DEFAULT_MAINT };
  } catch (e) {
    return { ...DEFAULT_MAINT };
  }
}
function saveMaintenance() {
  try { localStorage.setItem(MAINT_KEY, JSON.stringify(maint)); } catch (e) { /* ignore */ }
}

function applyAdvancedToDom() {
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val ? "on" : "off"; };
  const setCheck = (id, val) => { const el = document.getElementById(id); if (el) el.checked = !!val; };
  setCheck("advBackupToggle", advanced.backup); set("advBackupStatus", advanced.backup);
  setCheck("advRateToggle", advanced.rateLimiting); set("advRateStatus", advanced.rateLimiting);
  setCheck("advApprovalToggle", advanced.scanApproval); set("advApprovalStatus", advanced.scanApproval);
  setCheck("advEmailToggle", advanced.emailAlerts); set("advEmailStatus", advanced.emailAlerts);
  setCheck("advLockCfgToggle", advanced.lockScanConfig); set("advLockCfgStatus", advanced.lockScanConfig);
  setCheck("advComplianceToggle", advanced.compliance); set("advComplianceStatus", advanced.compliance);
  setCheck("advCloudToggle", advanced.cloudSync); set("advCloudStatus", advanced.cloudSync);
  setCheck("advRestrictAdminToggle", advanced.restrictAdmin); set("advRestrictAdminStatus", advanced.restrictAdmin);
  const bs = document.getElementById("advBackupSchedule");
  if (bs) bs.value = advanced.backupSchedule;
  const vd = document.getElementById("advVideoRetention");
  if (vd) vd.value = String(advanced.videoRetention);
  [["advBackupStatus", advanced.backup], ["advRateStatus", advanced.rateLimiting],
   ["advApprovalStatus", advanced.scanApproval], ["advEmailStatus", advanced.emailAlerts],
   ["advLockCfgStatus", advanced.lockScanConfig], ["advComplianceStatus", advanced.compliance],
   ["advCloudStatus", advanced.cloudSync], ["advRestrictAdminStatus", advanced.restrictAdmin]
  ].forEach(([id, on]) => {
    const el = document.getElementById(id);
    if (el) el.classList.toggle("on", !!on);
  });
}

function applyMaintenanceToDom() {
  const status = document.getElementById("maintStatus");
  const toggle = document.getElementById("maintToggle");
  const passRow = document.getElementById("maintPassRow");
  const banner = document.getElementById("maintBanner");
  const bannerText = document.getElementById("maintBannerText");
  const pass = document.getElementById("maintPass");
  if (status) {
    status.textContent = maint.maintenance ? "⚠ MAINTENANCE" : "● LIVE";
    status.classList.toggle("maintenance", !!maint.maintenance);
    status.classList.toggle("live", !maint.maintenance);
  }
  if (toggle) toggle.checked = !!maint.maintenance;
  if (passRow) passRow.hidden = !toggle || !toggle.checked;
  if (banner) {
    banner.hidden = !maint.maintenance;
    if (bannerText) bannerText.textContent = "The platform is currently in maintenance mode and is taken down. Re-enter your admin password to restore service.";
  }
  if (pass) pass.value = "";
}

function initMaintenancePanel() {
  applyAdvancedToDom();
  applyMaintenanceToDom();

  // "More advanced settings" expand/collapse
  const advMoreBtn = document.getElementById("advMoreBtn");
  const advMorePanel = document.getElementById("advMorePanel");
  const advCaret = document.getElementById("advMoreCaret");
  if (advMoreBtn && advMorePanel) {
    advMoreBtn.addEventListener("click", () => {
      const isOpen = !advMorePanel.hidden;
      advMorePanel.hidden = isOpen;
      if (advCaret) advCaret.classList.toggle("expanded", isOpen);
      if (isOpen) {
        advMoreBtn.innerHTML = `<i class="fa-solid fa-sliders"></i> More advanced settings <span class="sec-more-caret" id="advMoreCaret">▸</span>`;
      } else {
        advMoreBtn.innerHTML = `<i class="fa-solid fa-sliders"></i> More advanced settings <span class="sec-more-caret expanded" id="advMoreCaret">▾</span>`;
        document.getElementById("advMoreCaret").classList.add("expanded");
      }
    });
  }

  // Maintenance mode toggle — requires admin password to confirm
  const maintToggle = document.getElementById("maintToggle");
  const maintPass = document.getElementById("maintPass");
  const maintConfirmBtn = document.getElementById("maintConfirmBtn");
  const maintTag = document.getElementById("adminNameLabel");

  function showMaintMessage(msg, isError) {
    const banner = document.getElementById("maintBanner");
    const text = document.getElementById("maintBannerText");
    if (!banner || !text) return;
    text.textContent = msg;
    banner.hidden = false;
    banner.style.borderColor = isError ? "rgba(255,23,68,0.4)" : "rgba(255,193,7,0.25)";
    banner.style.background = isError ? "rgba(255,23,68,0.08)" : "rgba(255,193,7,0.08)";
  }
  function hideMaintMessage() {
    const banner = document.getElementById("maintBanner");
    if (banner) banner.hidden = true;
  }

  function verifyAdminPassword() {
    const passInput = document.getElementById("maintPass");
    if (passInput && passInput.value.trim() === "784588") return true;
    if (passInput) passInput.classList.add("input-invalid");
    setTimeout(() => { if (passInput) passInput.classList.remove("input-invalid"); }, 1500);
    return false;
  }

  if (maintToggle) {
    maintToggle.addEventListener("click", (e) => {
      e.preventDefault(); // Prevent visual switch toggle until verified
      
      const passRow = document.getElementById("maintPassRow");
      if (passRow) {
        const isCurrentlyHidden = passRow.hidden;
        passRow.hidden = !isCurrentlyHidden;
        
        if (passRow.hidden) {
          hideMaintMessage();
        } else {
          const targetState = !maint.maintenance;
          if (targetState) {
            showMaintMessage("To enter maintenance mode, enter your admin password below.", false);
          } else {
            showMaintMessage("To leave maintenance mode, enter your admin password below.", false);
          }
        }
      }
    });
  }

  if (maintConfirmBtn) {
    maintConfirmBtn.addEventListener("click", async () => {
      const wantOn = !maint.maintenance; // Target is the opposite of the currently active state
      if (!verifyAdminPassword()) {
        showMaintMessage("Incorrect admin password. Maintenance setting was not changed.", true);
        return;
      }

      // Persist setting to backend database
      try {
        const res = await fetch(`${API_BASE}/api/admin/settings`, {
          method: "PATCH",
          headers: {
            ...authHeaders(),
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ maintenance_mode: wantOn })
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
      } catch (err) {
        toast(`Failed to update backend maintenance mode: ${err.message}`, "error");
        console.warn(err);
        return;
      }

      maint.maintenance = wantOn;
      saveMaintenance();
      applyMaintenanceToDom();
      hideMaintMessage();

      const passRow = document.getElementById("maintPassRow");
      if (passRow) passRow.hidden = true;

      if (wantOn) {
        toast("Platform is now in maintenance mode — service is down.", "info");
      } else {
        toast("Maintenance mode disabled — platform is live again.", "success");
      }
    });
  }

  // Sync maintenance settings from backend database
  async function syncMaintenanceFromBackend() {
    try {
      const res = await fetch(`${API_BASE}/api/admin/settings`, { headers: authHeaders() });
      if (res.ok) {
        const data = await res.json();
        if (data.settings && data.settings.maintenance_mode !== undefined) {
          maint.maintenance = !!data.settings.maintenance_mode;
          saveMaintenance();
          applyMaintenanceToDom();
        }
      }
    } catch (err) {
      console.warn("Failed to sync maintenance settings from backend:", err);
    }
  }

  // Initial sync from backend
  syncMaintenanceFromBackend();

  // Advanced toggles
  const bindAdvToggle = (toggleId, key, label) => {
    const t = document.getElementById(toggleId);
    if (!t) return;
    t.addEventListener("change", (e) => {
      advanced[key] = e.target.checked;
      saveAdvanced();
      applyAdvancedToDom();
      toast(`${label} ${advanced[key] ? "enabled" : "disabled"}`, "info");
    });
  };
  bindAdvToggle("advBackupToggle", "backup", "Auto backup");
  bindAdvToggle("advRateToggle", "rateLimiting", "Rate limiting");
  bindAdvToggle("advApprovalToggle", "scanApproval", "Scan approval");
  bindAdvToggle("advEmailToggle", "emailAlerts", "Email alerts");
  bindAdvToggle("advLockCfgToggle", "lockScanConfig", "Lock scan config");
  bindAdvToggle("advComplianceToggle", "compliance", "Compliance mode");
  bindAdvToggle("advCloudToggle", "cloudSync", "Cloud sync");
  bindAdvToggle("advRestrictAdminToggle", "restrictAdmin", "Restrict admin creation");

  const bs = document.getElementById("advBackupSchedule");
  if (bs) bs.addEventListener("change", () => { advanced.backupSchedule = bs.value; saveAdvanced(); toast(`Backup schedule set to ${bs.options[bs.selectedIndex].text}`, "info"); });
  const vd = document.getElementById("advVideoRetention");
  if (vd) vd.addEventListener("change", () => { advanced.videoRetention = Number(vd.value); saveAdvanced(); toast(`Video-log retention set to ${vd.options[vd.selectedIndex].text}`, "info"); });

  const clearCacheBtn = document.getElementById("advClearCacheBtn");
  if (clearCacheBtn) clearCacheBtn.addEventListener("click", async () => {
    const ok = await confirmDialog("Clear cached reports?", "This purges temporary report caches across the platform. Continue?");
    if (!ok) return;
    toast("Report caches cleared", "success");
  });

  const integrityBtn = document.getElementById("advIntegrityBtn");
  if (integrityBtn) integrityBtn.addEventListener("click", async () => {
    const ok = await confirmDialog("Run integrity check?", "This verifies backend modules & data integrity. Continue?");
    if (!ok) return;
    toast("Integrity check started — no issues detected", "success");
  });
}

function applySettingsToDom() {
  document.body.classList.toggle("density-compact", settings.density === "compact");
  document.getElementById("densityToggle").checked = settings.density === "compact";
  document.getElementById("autoRefreshToggle").checked = !!settings.autoRefresh;
  document.getElementById("refreshIntervalSelect").value = String(settings.refreshInterval);
  document.getElementById("pageSizeSelect").value = String(settings.pageSize);
}

function restartAutoRefresh() {
  if (autoRefreshTimer) clearInterval(autoRefreshTimer);
  autoRefreshTimer = null;
  if (settings.autoRefresh) {
    autoRefreshTimer = setInterval(() => refreshActivePanel(true), settings.refreshInterval);
  }
}

function initSettingsPanel() {
  applySettingsToDom();
  initSecurityPanel();
  initMaintenancePanel();

  document.getElementById("sessAdminName").textContent = sessionStorage.getItem("userName") || "—";
  document.getElementById("sessAdminEmail").textContent = sessionStorage.getItem("userEmail") || "—";
  document.getElementById("sessAdminRole").textContent = sessionStorage.getItem("userRole") || "—";

  document.getElementById("densityToggle").addEventListener("change", (e) => {
    settings.density = e.target.checked ? "compact" : "comfortable";
    saveSettings();
    applySettingsToDom();
  });
  document.getElementById("autoRefreshToggle").addEventListener("change", (e) => {
    settings.autoRefresh = e.target.checked;
    saveSettings();
    restartAutoRefresh();
    toast(settings.autoRefresh ? "Auto-refresh enabled" : "Auto-refresh disabled", "info");
  });
  document.getElementById("refreshIntervalSelect").addEventListener("change", (e) => {
    settings.refreshInterval = Number(e.target.value);
    saveSettings();
    restartAutoRefresh();
  });
  document.getElementById("pageSizeSelect").addEventListener("change", (e) => {
    settings.pageSize = Number(e.target.value);
    saveSettings();
    userPage.size = settings.pageSize; userPage.page = 1;
    scanPage.size = settings.pageSize; scanPage.page = 1;
    renderUsersTable();
    renderScansTable();
  });
  document.getElementById("resetSettingsBtn").addEventListener("click", async () => {
    const ok = await confirmDialog("Reset console preferences?", "This clears density, auto-refresh and page-size settings saved on this device.");
    if (!ok) return;
    Object.assign(settings, DEFAULT_SETTINGS);
    saveSettings();
    applySettingsToDom();
    restartAutoRefresh();
    userPage.size = settings.pageSize; scanPage.size = settings.pageSize;
    renderUsersTable(); renderScansTable();
    toast("Preferences reset", "success");
  });

  restartAutoRefresh();
}

// ==========================================================================
//  Header wiring
// ==========================================================================
document.addEventListener("DOMContentLoaded", () => {
  const nameLabel = document.getElementById("adminNameLabel");
  if (nameLabel) nameLabel.textContent = sessionStorage.getItem("userName") || "admin";

  const logoutLink = document.getElementById("logoutLink");
  if (logoutLink) {
    logoutLink.addEventListener("click", async (e) => {
      e.preventDefault();
      try {
        if (AUTH_TOKEN) {
          await fetch(`${API_BASE}/api/auth/logout`, { method: "POST", headers: authHeaders() });
        }
      } catch (err) { /* ignore, clear session regardless */ }
      sessionStorage.clear();
      window.location.href = "login.html";
    });
  }

  initTabs();
  initThemeSwitcher();
  initMonitorClock();
  userPage.size = settings.pageSize;
  scanPage.size = settings.pageSize;

  const refreshBtn = document.getElementById("refreshBtn");
  if (refreshBtn) refreshBtn.addEventListener("click", () => refreshActivePanel(true));

  const userSearch = document.getElementById("userSearch");
  if (userSearch) userSearch.addEventListener("input", () => { userPage.page = 1; renderUsersTable(); });

  const scanSearch = document.getElementById("scanSearch");
  if (scanSearch) scanSearch.addEventListener("input", () => { scanPage.page = 1; renderScansTable(); });

  document.querySelectorAll("#scanTypeFilter .filter-chip").forEach(chip => {
    chip.addEventListener("click", () => {
      document.querySelectorAll("#scanTypeFilter .filter-chip").forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      state.scanTypeFilter = chip.dataset.scanType;
      scanPage.page = 1;
      renderScansTable();
    });
  });

  document.querySelectorAll("#userStatusFilter .filter-chip").forEach(chip => {
    chip.addEventListener("click", () => {
      document.querySelectorAll("#userStatusFilter .filter-chip").forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      state.userStatusFilter = chip.dataset.status;
      userPage.page = 1;
      renderUsersTable();
    });
  });

  document.querySelectorAll(".mini-table").forEach(() => {}); // no-op placeholder for future delegated handlers

  document.getElementById("exportUsersBtn").addEventListener("click", () => {
    const rows = filteredUsers();
    downloadCsv("cyverion-users.csv", rows, [
      { label: "ID", get: u => u.id },
      { label: "First name", get: u => u.first_name || "" },
      { label: "Last name", get: u => u.last_name || "" },
      { label: "Email", get: u => u.email || "" },
      { label: "Organization", get: u => u.organization || "" },
      { label: "Role", get: u => u.role || "" },
      { label: "Status", get: u => (u.account_status || "ACTIVE").toUpperCase() },
      { label: "Created", get: u => u.created_at || "" },
    ]);
  });

  document.getElementById("exportScansBtn").addEventListener("click", () => {
    const rows = filteredScans();
    downloadCsv("cyverion-scans.csv", rows, [
      { label: "Job ID", get: r => r.job_id },
      { label: "Type", get: r => r.job_type },
      { label: "Target", get: r => r.target || "" },
      { label: "User", get: r => r.user_email || "" },
      { label: "Status", get: r => r.status || "" },
      { label: "Created", get: r => r.created_at || "" },
    ]);
  });

  // Bulk action bar
  document.getElementById("bulkClearBtn").addEventListener("click", () => { state.selectedUserIds.clear(); renderUsersTable(); });
  document.getElementById("bulkSuspendBtn").addEventListener("click", () => bulkUpdateStatus("SUSPENDED"));
  document.getElementById("bulkReinstateBtn").addEventListener("click", () => bulkUpdateStatus("ACTIVE"));
  document.getElementById("bulkDeleteBtn").addEventListener("click", bulkDeleteUsers);

  const auditRefreshBtn = document.getElementById("auditRefreshBtn");
  if (auditRefreshBtn) auditRefreshBtn.addEventListener("click", () => loadAuditLogs());

  const auditSearch = document.getElementById("auditSearch");
  if (auditSearch) auditSearch.addEventListener("input", () => { auditPage.page = 1; renderAuditLogsTable(); });

  const approvalsRefreshBtn = document.getElementById("approvalsRefreshBtn");
  if (approvalsRefreshBtn) approvalsRefreshBtn.addEventListener("click", () => loadApprovals());

  initGlobalSearch();
  initSettingsPanel();

  loadStats();
  loadUsers().then(() => {
    renderRecentUsers();
    return loadScans();
  });
});

// ==========================================================================
//  Tabs
// ==========================================================================
const PANEL_META = {
  overview: { title: "Overview", subtitle: "Snapshot of everything running on CYVERION right now." },
  monitor: { title: "Live Monitor", subtitle: "24x7 real-time platform activity, uptime and event stream." },
  users: { title: "Users", subtitle: "Every registered account, its role and current status." },
  scans: { title: "Scans", subtitle: "Recon and Module 2 jobs launched by any user." },
  analytics: { title: "Analytics", subtitle: "Growth and activity trends computed from live platform data." },
  audit: { title: "Audit Log", subtitle: "Security and administrative event trail recorded by the backend." },
  approvals: { title: "Approvals", subtitle: "Scan requests awaiting your approval before they can run." },
  settings: { title: "Settings", subtitle: "Console preferences for this browser, plus platform-wide policies." },
};

let currentTab = "overview";

// ==========================================================================
//  Theme switcher — Classic / Hacker / CEO (persisted, shared via theme.js)
// ==========================================================================
function initThemeSwitcher() {
  if (window.CYVERION_THEME) {
    window.CYVERION_THEME.init();
  } else {
    // Fallback if theme.js didn't load
    let saved = "classic";
    try { saved = localStorage.getItem("cyverion_admin_theme_v1") || "classic"; } catch (e) { /* ignore */ }
    document.body.setAttribute("data-theme", saved);
    document.querySelectorAll('[data-theme-btn]').forEach(btn => {
      btn.addEventListener("click", () => {
        document.body.setAttribute("data-theme", btn.dataset.themeBtn);
        try { localStorage.setItem("cyverion_admin_theme_v1", btn.dataset.themeBtn); } catch (e) { /* ignore */ }
        document.querySelectorAll('[data-theme-btn]').forEach(b => b.classList.toggle("active", b.dataset.themeBtn === btn.dataset.themeBtn));
      });
    });
  }
}


// ==========================================================================
//  Live Monitor — 24x7 SSE stream (consumed via fetch + ReadableStream to
//  send the Authorization header, since EventSource cannot set headers.)
// ==========================================================================
let monitorStream = null;
let MONITOR_BUFFER = "";

function fmtUptime(sec) {
  sec = Math.max(0, sec || 0);
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return d ? `${d}d ${h}h ${m}m` : `${h}h ${m}m ${s}s`;
}

function renderMonitorFeed(events) {
  const feed = document.getElementById("monitorFeed");
  if (!feed) return;
  if (!events || !events.length) {
    feed.innerHTML = `<h3>Live activity feed</h3><p class="section-note">No activity yet — launch a recon or Module 2 scan to see it stream here.</p>`;
    return;
  }
  feed.innerHTML = `<h3>Live activity feed</h3>` + events.map(ev => {
    const ts = new Date((ev.ts || Date.now()) * 1000).toLocaleTimeString();
    const msg = ev.message || "activity";
    const okCls = (ev.status || "").toLowerCase().includes("complete") || (ev.status || "").toLowerCase().includes("done") ? "ok"
      : (ev.status || "").toLowerCase().includes("error") || (ev.status || "").toLowerCase().includes("fail") ? "err" : "";
    return `<div class="monitor-event ${okCls}">
      <span class="me-time">${ts}</span>
      <span class="me-msg">[${escapeHtml(ev.status || "event")}] <span class="me-target">${escapeHtml(ev.target || "")}</span> — ${escapeHtml(msg)}</span>
    </div>`;
  }).join("");
}

function renderMonitorSnapshot(snap) {
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
  if (snap) {
    set("mtRunning", snap.running ?? "—");
    set("mtQueued", snap.queued ?? "—");
    set("mtCompleted", snap.completed ?? "—");
    set("mtFailed", snap.failed ?? "—");
    set("mtUptime", fmtUptime(snap.uptime_s));
    set("mtTotal", snap.total_jobs ?? "—");
    set("mtM2", snap.module2_jobs ?? "—");
    set("mtRecon", snap.recon_jobs ?? "—");
    renderMonitorFeed(snap.events);
  }
}

function startMonitor() {
  if (monitorStream) return;
  if (!currentTab || currentTab !== "monitor") {
    // Optionally keep streaming in background; but for simplicity we only
    // stream while the tab is open.
    return;
  }
  const url = `${API_BASE}/api/admin/monitor`;
  const ctrl = new AbortController();
  monitorStream = ctrl;

  async function run() {
    try {
      const res = await fetch(url, { headers: authHeaders(), signal: ctrl.signal });
      if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
      const reader = res.body.getReader();
      const decoder = new TextDecoder("utf-8");
      MONITOR_BUFFER = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        MONITOR_BUFFER += decoder.decode(value, { stream: true });
        // SSE frames separated by "\n\n"
        const frames = MONITOR_BUFFER.split("\n\n");
        MONITOR_BUFFER = frames.pop() || "";
        for (const frame of frames) {
          const dataLine = frame.split("\n").find(l => l.startsWith("data: "));
          if (!dataLine) continue;
          try {
            const snap = JSON.parse(dataLine.slice(6));
            renderMonitorSnapshot(snap);
          } catch (e) { /* skip malformed frame */ }
        }
      }
    } catch (err) {
      if (err.name !== "AbortError") {
        const feed = document.getElementById("monitorFeed");
        if (feed) feed.innerHTML = `<h3>Live activity feed</h3><p class="section-note">Monitor stream disconnected (${escapeHtml(err.message)}). Will retry...</p>`;
        setTimeout(() => { monitorStream = null; if (currentTab === "monitor") startMonitor(); }, 4000);
      }
    }
  }
  run();
}

function stopMonitor() {
  if (monitorStream) { monitorStream.abort(); monitorStream = null; }
}

function initMonitorClock() {
  const el = document.getElementById("monitorClock");
  if (!el) return;
  setInterval(() => { el.textContent = new Date().toLocaleTimeString(); }, 1000);
}

function initTabs() {
  document.querySelectorAll(".admin-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".admin-tab").forEach(t => t.classList.remove("active", "done"));
      tab.classList.add("active");
      document.querySelectorAll(".admin-tab").forEach(t => { if (t !== tab) t.classList.add("done"); });

      const key = tab.dataset.tab;
      if (currentTab === "monitor" && key !== "monitor") stopMonitor();
      currentTab = key;
      document.querySelectorAll(".admin-panel-section").forEach(p => p.classList.remove("active"));
      document.getElementById(`panel-${key}`).classList.add("active");

      const meta = PANEL_META[key] || {};
      document.getElementById("panelTitle").textContent = meta.title || key;
      document.getElementById("panelSubtitle").textContent = meta.subtitle || "";

      refreshActivePanel(false);
    });
  });
}

function refreshActivePanel(forceReload) {
  if (currentTab === "overview") { loadStats(); renderOverviewCharts(); }
  if (currentTab === "monitor") { startMonitor(); }
  if (currentTab === "users") { if (forceReload || !state.users.length) loadUsers(); else renderUsersTable(); }
  if (currentTab === "scans") { if (forceReload || (!state.reconJobs.length && !state.module2Jobs.length)) loadScans(); else renderScansTable(); }
  if (currentTab === "analytics") renderAnalytics();
  if (currentTab === "audit") loadAuditLogs();
  if (currentTab === "approvals") loadApprovals();
}

// ==========================================================================
//  State
// ==========================================================================
const state = {
  users: [],
  reconJobs: [],
  module2Jobs: [],
  auditLogs: [],
  approvals: [],
  scanTypeFilter: "all",
  scanStatusFilter: "all",
  userStatusFilter: "all",
  userRoleFilter: "all",
  selectedUserIds: new Set(),
  userSort: { key: "created_at", dir: "desc" },
  scanSort: { key: "created_at", dir: "desc" },
  auditSort: { key: "created_at", dir: "desc" },
};
const userPage = { page: 1, size: 25 };
const scanPage = { page: 1, size: 25 };
const auditPage = { page: 1, size: 25 };

// ==========================================================================
//  Overview
// ==========================================================================
async function loadStats() {
  try {
    const res = await fetch(`${API_BASE}/api/admin/stats`, { headers: authHeaders() });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    state.lastStats = data;

    const suspendedCount = state.users.filter(u => (u.account_status || "ACTIVE").toUpperCase() === "SUSPENDED").length;
    const activeScansNow = combinedScans().filter(r => ["queued", "running"].includes((r.status || "").toLowerCase())).length;

    const items = [
      [data.total_users, "Total users"],
      [data.total_admins, "Admins"],
      [data.new_users_7d, "New users (7d)"],
      [suspendedCount, "Suspended"],
      [data.total_recon_jobs, "Recon scans total"],
      [data.scans_7d, "Scans (7d)"],
      [data.module2_running, "Module 2 running"],
      [activeScansNow, "Active scans now"],
    ];
    document.querySelectorAll("#statsGrid .kpi-card").forEach((card, i) => {
      const numEl = card.querySelector(".kpi-num");
      if (numEl && items[i]) numEl.textContent = items[i][0] ?? 0;
    });

    const statusList = document.getElementById("statusTagList");
    const byStatus = data.recon_by_status || {};
    const keys = Object.keys(byStatus);
    if (!keys.length) {
      statusList.innerHTML = `<span class="tag">No recon scans yet</span>`;
    } else {
      statusList.innerHTML = keys.map(k => {
        const cls = k === "completed" ? "tag-teal" : (k === "failed" || k === "error") ? "tag-red" : "tag-amber";
        return `<span class="tag ${cls}">${escapeHtml(k)}: ${byStatus[k]}</span>`;
      }).join("");
    }
    renderOverviewCharts();
  } catch (err) {
    document.querySelectorAll("#statsGrid .kpi-num").forEach(n => n.textContent = "—");
    toast(`Failed to load stats: ${err.message}`, "error");
  }
}

// ---- lightweight, dependency-free SVG charts, built from real fetched data ----
function dayBuckets(n) {
  const days = [];
  const now = new Date();
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - i);
    days.push(d);
  }
  return days;
}
function bucketKey(d) { return d.toISOString().slice(0, 10); }

function countByDay(items, dateField, n) {
  const days = dayBuckets(n);
  const counts = Object.fromEntries(days.map(d => [bucketKey(d), 0]));
  items.forEach(item => {
    const raw = item[dateField];
    if (!raw) return;
    const d = new Date(raw);
    if (Number.isNaN(d.valueOf())) return;
    d.setHours(0, 0, 0, 0);
    const key = bucketKey(d);
    if (key in counts) counts[key] += 1;
  });
  return days.map(d => ({ label: d, value: counts[bucketKey(d)] }));
}

function renderBarChart(containerId, points, opts = {}) {
  const el = document.getElementById(containerId);
  if (!el) return;
  if (!points.length || points.every(p => p.value === 0)) {
    el.innerHTML = `<p class="chart-empty">No activity in this window yet.</p>`;
    return;
  }
  const w = 560, h = 150, pad = 4;
  const max = Math.max(1, ...points.map(p => p.value));
  const barW = (w - pad * 2) / points.length;
  const showEvery = points.length > 20 ? Math.ceil(points.length / 10) : 2;

  const bars = points.map((p, i) => {
    const barH = Math.max(2, (p.value / max) * (h - 24));
    const x = pad + i * barW;
    const y = h - barH - 16;
    return `<rect x="${x + 1}" y="${y}" width="${Math.max(1, barW - 2)}" height="${barH}" rx="2" fill="url(#barGrad)"><title>${escapeHtml(p.label.toLocaleDateString())}: ${p.value}</title></rect>`;
  }).join("");

  const labels = points.map((p, i) => {
    if (i % showEvery !== 0 && i !== points.length - 1) return "";
    const x = pad + i * barW + barW / 2;
    return `<text x="${x}" y="${h - 2}" font-size="8" fill="var(--text-dim)" text-anchor="middle" font-family="var(--font-mono)">${p.label.getDate()}/${p.label.getMonth() + 1}</text>`;
  }).join("");

  el.innerHTML = `
    <svg viewBox="0 0 ${w} ${h}" width="100%" height="150" preserveAspectRatio="none">
      <defs>
        <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="var(--amber)"/>
          <stop offset="100%" stop-color="var(--crimson)"/>
        </linearGradient>
      </defs>
      ${bars}
      ${labels}
    </svg>
    <div class="section-note" style="margin-top:4px;">Total: ${points.reduce((a, p) => a + p.value, 0)} · Peak day: ${max}</div>
  `;
}

function renderOverviewCharts() {
  renderBarChart("signupsChart", countByDay(state.users, "created_at", 14));
  renderBarChart("scansChart", countByDay(combinedScans(), "created_at", 14));
}

function renderBarList(containerId, entries) {
  const el = document.getElementById(containerId);
  if (!el) return;
  if (!entries.length) { el.innerHTML = `<p class="chart-empty">No data yet.</p>`; return; }
  const max = Math.max(1, ...entries.map(e => e.count));
  el.innerHTML = entries.map(e => `
    <div class="bar-list-row">
      <span class="bl-label" title="${escapeHtml(e.label)}">${escapeHtml(e.label)}</span>
      <span class="bar-list-track"><span class="bar-list-fill" style="width:${Math.max(4, (e.count / max) * 100)}%"></span></span>
      <span class="bl-num">${e.count}</span>
    </div>`).join("");
}

function renderAnalytics() {
  renderBarChart("signupsChart30", countByDay(state.users, "created_at", 30));
  renderBarChart("scansChart30", countByDay(combinedScans(), "created_at", 30));

  const roleCounts = {};
  state.users.forEach(u => { const r = u.role || "Unassigned"; roleCounts[r] = (roleCounts[r] || 0) + 1; });
  renderBarList("roleBreakdown", Object.entries(roleCounts).sort((a, b) => b[1] - a[1]).map(([label, count]) => ({ label, count })));

  const statusCounts = {};
  combinedScans().forEach(s => { const k = (s.status || "unknown").toLowerCase(); statusCounts[k] = (statusCounts[k] || 0) + 1; });
  renderBarList("scanStatusBreakdown", Object.entries(statusCounts).sort((a, b) => b[1] - a[1]).map(([label, count]) => ({ label, count })));

  const targetCounts = {};
  combinedScans().forEach(s => { const t = s.target || "unknown"; targetCounts[t] = (targetCounts[t] || 0) + 1; });
  const topTargets = Object.entries(targetCounts).sort((a, b) => b[1] - a[1]).slice(0, 10);
  const topTargetsEl = document.getElementById("topTargets");
  if (!topTargets.length) {
    topTargetsEl.innerHTML = `<p class="chart-empty">No scans yet.</p>`;
  } else {
    topTargetsEl.innerHTML = `
      <table class="mini-table">
        <thead><tr><th>Target</th><th>Scans</th></tr></thead>
        <tbody>${topTargets.map(([t, c]) => `<tr><td>${escapeHtml(t)}</td><td>${c}</td></tr>`).join("")}</tbody>
      </table>`;
  }
}

// ==========================================================================
//  Users
// ==========================================================================
const ROLE_OPTIONS = ["admin", "Administrator", "Security Analyst", "Penetration Tester", "Developer", "Student"];

async function loadUsers() {
  try {
    const res = await fetch(`${API_BASE}/api/admin/users`, { headers: authHeaders() });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    state.users = data.users || [];
    renderUserRoleFilterChips();
    renderUsersTable();
    if (currentTab === "analytics") renderAnalytics();
  } catch (err) {
    document.getElementById("usersTable").innerHTML = `<p class="load-error">Failed to load users: ${escapeHtml(err.message)}</p>`;
    toast(`Failed to load users: ${err.message}`, "error");
  }
}

function renderUserRoleFilterChips() {
  const wrap = document.getElementById("userRoleFilter");
  const roles = [...new Set(state.users.map(u => u.role).filter(Boolean))].sort();
  const current = state.userRoleFilter;
  wrap.innerHTML = [`<span class="filter-chip ${current === "all" ? "active" : ""}" data-role="all">All roles</span>`]
    .concat(roles.map(r => `<span class="filter-chip ${current === r ? "active" : ""}" data-role="${escapeHtml(r)}">${escapeHtml(r)}</span>`))
    .join("");
  wrap.querySelectorAll(".filter-chip").forEach(chip => {
    chip.addEventListener("click", () => {
      wrap.querySelectorAll(".filter-chip").forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      state.userRoleFilter = chip.dataset.role;
      userPage.page = 1;
      renderUsersTable();
    });
  });
}

function userRoleOptionsHtml(current) {
  const opts = new Set(ROLE_OPTIONS);
  if (current) opts.add(current);
  return [...opts].map(r => `<option value="${escapeHtml(r)}" ${r === current ? "selected" : ""}>${escapeHtml(r)}</option>`).join("");
}

function filteredUsers() {
  const q = (document.getElementById("userSearch")?.value || "").toLowerCase().trim();
  let rows = state.users.filter(u => {
    if (state.userStatusFilter === "active" && (u.account_status || "ACTIVE").toUpperCase() === "SUSPENDED") return false;
    if (state.userStatusFilter === "suspended" && (u.account_status || "ACTIVE").toUpperCase() !== "SUSPENDED") return false;
    if (state.userRoleFilter !== "all" && u.role !== state.userRoleFilter) return false;
    if (!q) return true;
    const haystack = `${u.first_name || ""} ${u.last_name || ""} ${u.email || ""} ${u.organization || ""}`.toLowerCase();
    return haystack.includes(q);
  });

  const { key, dir } = state.userSort;
  rows = [...rows].sort((a, b) => {
    let av, bv;
    if (key === "name") { av = `${a.first_name || ""} ${a.last_name || ""}`.trim().toLowerCase(); bv = `${b.first_name || ""} ${b.last_name || ""}`.trim().toLowerCase(); }
    else if (key === "role") { av = (a.role || "").toLowerCase(); bv = (b.role || "").toLowerCase(); }
    else if (key === "status") { av = (a.account_status || "ACTIVE"); bv = (b.account_status || "ACTIVE"); }
    else { av = new Date(a.created_at || 0).getTime(); bv = new Date(b.created_at || 0).getTime(); }
    if (av < bv) return dir === "asc" ? -1 : 1;
    if (av > bv) return dir === "asc" ? 1 : -1;
    return 0;
  });
  return rows;
}

const USER_SORT_COLUMNS = [
  { key: "name", label: "User" },
  { key: "role", label: "Role" },
  { key: "status", label: "Status" },
  { key: "created_at", label: "Created" },
];

function renderUsersTable() {
  const allFiltered = filteredUsers();
  const totalPages = Math.max(1, Math.ceil(allFiltered.length / userPage.size));
  userPage.page = Math.min(userPage.page, totalPages);
  const start = (userPage.page - 1) * userPage.size;
  const rows = allFiltered.slice(start, start + userPage.size);

  if (!allFiltered.length) {
    document.getElementById("usersTable").innerHTML = `<p class="empty-state">No users match your search or filters.</p>`;
    document.getElementById("usersPagination").innerHTML = "";
    updateUserBulkBar();
    return;
  }

  const sortHeader = (key, label) => {
    const active = state.userSort.key === key;
    const arrow = active ? (state.userSort.dir === "asc" ? "▲" : "▼") : "▲";
    return `<th class="sortable ${active ? "sorted" : ""}" data-sort-key="${key}">${label}<span class="sort-arrow">${arrow}</span></th>`;
  };

  const allOnPageSelected = rows.length > 0 && rows.every(u => state.selectedUserIds.has(String(u.id)));

  const tableRows = rows.map(u => {
    const status = (u.account_status || "ACTIVE").toUpperCase();
    const isSuspended = status === "SUSPENDED";
    const name = `${u.first_name || ""} ${u.last_name || ""}`.trim() || "—";
    const checked = state.selectedUserIds.has(String(u.id));
    return `<tr data-user-id="${u.id}">
      <td class="checkbox-cell" onclick="event.stopPropagation()"><input type="checkbox" class="user-select-cb" data-user-id="${u.id}" ${checked ? "checked" : ""}></td>
      <td>
        <div class="user-cell">
          <div class="user-avatar">${escapeHtml(initials(name === "—" ? u.email : name))}</div>
          <div class="user-cell-text">
            <span class="u-name">${escapeHtml(name)}</span>
            <span class="u-email">${escapeHtml(u.email || "")}</span>
            <span class="u-org">${escapeHtml(u.organization || "")}</span>
          </div>
        </div>
      </td>
      <td onclick="event.stopPropagation()"><select class="role-select" data-user-id="${u.id}">${userRoleOptionsHtml(u.role)}</select></td>
      <td><span class="status-badge ${isSuspended ? "suspended" : "active"}">${isSuspended ? "Suspended" : "Active"}</span></td>
      <td>${formatDateTime(u.created_at)}</td>
      <td class="actions-cell" onclick="event.stopPropagation()">
        <button type="button" class="row-action-btn icon-btn toggle-status-btn" title="${isSuspended ? "Reinstate account" : "Suspend account"}" data-user-id="${u.id}" data-next-status="${isSuspended ? "ACTIVE" : "SUSPENDED"}"><i class="fa-solid ${isSuspended ? "fa-user-check" : "fa-user-slash"}"></i></button>
        <button type="button" class="row-action-btn icon-btn danger delete-user-btn" title="Delete user" data-user-id="${u.id}"><i class="fa-solid fa-trash"></i></button>
      </td>
    </tr>`;
  }).join("");

  document.getElementById("usersTable").innerHTML = `
    <table class="mini-table">
      <thead><tr>
        <th class="checkbox-cell"><input type="checkbox" id="selectAllUsersCb" ${allOnPageSelected ? "checked" : ""}></th>
        ${sortHeader("name", "User")}
        ${sortHeader("role", "Role")}
        ${sortHeader("status", "Status")}
        ${sortHeader("created_at", "Created")}
        <th>Actions</th>
      </tr></thead>
      <tbody>${tableRows}</tbody>
    </table>`;

  renderPagination("usersPagination", userPage, allFiltered.length, () => renderUsersTable());

  document.querySelectorAll("#usersTable th.sortable").forEach(th => {
    th.addEventListener("click", () => {
      const key = th.dataset.sortKey;
      if (state.userSort.key === key) state.userSort.dir = state.userSort.dir === "asc" ? "desc" : "asc";
      else { state.userSort.key = key; state.userSort.dir = "asc"; }
      renderUsersTable();
    });
  });

  document.querySelectorAll("#usersTable tbody tr").forEach(tr => {
    tr.addEventListener("click", () => openUserDrawer(tr.dataset.userId));
  });

  document.querySelectorAll(".role-select").forEach(sel => {
    sel.addEventListener("click", (e) => e.stopPropagation());
    sel.addEventListener("change", () => updateUserRole(sel.dataset.userId, sel.value));
  });
  document.querySelectorAll(".toggle-status-btn").forEach(btn => {
    btn.addEventListener("click", () => updateUserStatus(btn.dataset.userId, btn.dataset.nextStatus));
  });
  document.querySelectorAll(".delete-user-btn").forEach(btn => {
    btn.addEventListener("click", () => deleteUser(btn.dataset.userId));
  });
  document.querySelectorAll(".user-select-cb").forEach(cb => {
    cb.addEventListener("click", (e) => e.stopPropagation());
    cb.addEventListener("change", () => {
      const id = String(cb.dataset.userId);
      if (cb.checked) state.selectedUserIds.add(id); else state.selectedUserIds.delete(id);
      updateUserBulkBar();
      const selectAll = document.getElementById("selectAllUsersCb");
      if (selectAll) selectAll.checked = rows.every(u => state.selectedUserIds.has(String(u.id)));
    });
  });
  const selectAllCb = document.getElementById("selectAllUsersCb");
  if (selectAllCb) {
    selectAllCb.addEventListener("change", () => {
      if (selectAllCb.checked) rows.forEach(u => state.selectedUserIds.add(String(u.id)));
      else rows.forEach(u => state.selectedUserIds.delete(String(u.id)));
      renderUsersTable();
    });
  }

  updateUserBulkBar();
}

function updateUserBulkBar() {
  const bar = document.getElementById("userBulkBar");
  const count = state.selectedUserIds.size;
  document.getElementById("userBulkCount").textContent = count;
  bar.classList.toggle("show", count > 0);
}

function renderPagination(containerId, pageState, totalItems, onChange) {
  const el = document.getElementById(containerId);
  const totalPages = Math.max(1, Math.ceil(totalItems / pageState.size));
  const start = totalItems === 0 ? 0 : (pageState.page - 1) * pageState.size + 1;
  const end = Math.min(totalItems, pageState.page * pageState.size);
  el.innerHTML = `
    <span>Showing ${start}–${end} of ${totalItems}</span>
    <div class="pagination-controls">
      <button type="button" class="btn-mini" id="${containerId}-prev" ${pageState.page <= 1 ? "disabled" : ""}><i class="fa-solid fa-chevron-left"></i></button>
      <span>Page ${pageState.page} / ${totalPages}</span>
      <button type="button" class="btn-mini" id="${containerId}-next" ${pageState.page >= totalPages ? "disabled" : ""}><i class="fa-solid fa-chevron-right"></i></button>
    </div>`;
  const prevBtn = document.getElementById(`${containerId}-prev`);
  const nextBtn = document.getElementById(`${containerId}-next`);
  if (prevBtn) prevBtn.addEventListener("click", () => { pageState.page = Math.max(1, pageState.page - 1); onChange(); });
  if (nextBtn) nextBtn.addEventListener("click", () => { pageState.page = Math.min(totalPages, pageState.page + 1); onChange(); });
}

async function updateUserRole(userId, role) {
  try {
    const body = new URLSearchParams({ role });
    const res = await fetch(`${API_BASE}/api/admin/users/${userId}/role`, {
      method: "PATCH", headers: { ...authHeaders(), "Content-Type": "application/x-www-form-urlencoded" }, body,
    });
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).detail || `HTTP ${res.status}`);
    const data = await res.json();
    const u = state.users.find(x => String(x.id) === String(userId));
    if (u) u.role = data.user.role;
    toast(`Role updated to ${data.user.role}`, "success");
    loadStats();
    renderUserRoleFilterChips();
  } catch (err) {
    toast(`Could not update role: ${err.message}`, "error");
    loadUsers();
  }
}

async function updateUserStatus(userId, nextStatus) {
  try {
    const body = new URLSearchParams({ status: nextStatus });
    const res = await fetch(`${API_BASE}/api/admin/users/${userId}/status`, {
      method: "PATCH", headers: { ...authHeaders(), "Content-Type": "application/x-www-form-urlencoded" }, body,
    });
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).detail || `HTTP ${res.status}`);
    await loadUsers();
    toast(nextStatus === "SUSPENDED" ? "Account suspended" : "Account reinstated", "success");
  } catch (err) {
    toast(`Could not update account status: ${err.message}`, "error");
  }
}

async function deleteUser(userId) {
  const user = state.users.find(x => String(x.id) === String(userId));
  const label = user ? (user.email || `user #${userId}`) : `user #${userId}`;
  const ok = await confirmDialog("Delete user?", `Delete ${label}? This also removes their recon scan history. This cannot be undone.`);
  if (!ok) return;
  try {
    const res = await fetch(`${API_BASE}/api/admin/users/${userId}`, { method: "DELETE", headers: authHeaders() });
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).detail || `HTTP ${res.status}`);
    state.selectedUserIds.delete(String(userId));
    await loadUsers();
    loadStats();
    renderRecentUsers();
    toast(`Deleted ${label}`, "success");
  } catch (err) {
    toast(`Could not delete user: ${err.message}`, "error");
  }
}

async function bulkUpdateStatus(nextStatus) {
  const ids = [...state.selectedUserIds];
  if (!ids.length) return;
  const label = nextStatus === "SUSPENDED" ? "suspend" : "reinstate";
  const ok = await confirmDialog(`${label[0].toUpperCase()}${label.slice(1)} ${ids.length} user${ids.length === 1 ? "" : "s"}?`, `This will ${label} the selected account(s) immediately.`);
  if (!ok) return;
  let okCount = 0, failCount = 0;
  for (const id of ids) {
    try {
      const body = new URLSearchParams({ status: nextStatus });
      const res = await fetch(`${API_BASE}/api/admin/users/${id}/status`, {
        method: "PATCH", headers: { ...authHeaders(), "Content-Type": "application/x-www-form-urlencoded" }, body,
      });
      if (!res.ok) throw new Error();
      okCount++;
    } catch (e) { failCount++; }
  }
  state.selectedUserIds.clear();
  await loadUsers();
  loadStats();
  toast(`${okCount} account(s) updated${failCount ? `, ${failCount} failed` : ""}`, failCount ? "error" : "success");
}

async function bulkDeleteUsers() {
  const ids = [...state.selectedUserIds];
  if (!ids.length) return;
  const ok = await confirmDialog(`Delete ${ids.length} user${ids.length === 1 ? "" : "s"}?`, "This also removes their recon scan history. This cannot be undone.");
  if (!ok) return;
  let okCount = 0, failCount = 0;
  for (const id of ids) {
    try {
      const res = await fetch(`${API_BASE}/api/admin/users/${id}`, { method: "DELETE", headers: authHeaders() });
      if (!res.ok) throw new Error();
      okCount++;
    } catch (e) { failCount++; }
  }
  state.selectedUserIds.clear();
  await loadUsers();
  loadStats();
  renderRecentUsers();
  toast(`${okCount} user(s) deleted${failCount ? `, ${failCount} failed` : ""}`, failCount ? "error" : "success");
}

// ==========================================================================
//  Scans
// ==========================================================================
async function loadScans() {
  try {
    const res = await fetch(`${API_BASE}/api/admin/scans`, { headers: authHeaders() });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    state.reconJobs = data.recon_jobs || [];
    state.module2Jobs = data.module2_jobs || [];
    renderScanStatusFilterChips();
    renderScansTable();
    renderRecentScans();
    if (currentTab === "analytics") renderAnalytics();
    if (currentTab === "overview") renderOverviewCharts();
  } catch (err) {
    document.getElementById("scansTable").innerHTML = `<p class="load-error">Failed to load scans: ${escapeHtml(err.message)}</p>`;
    toast(`Failed to load scans: ${err.message}`, "error");
  }
}

function emailForUserId(userId) {
  const u = state.users.find(x => String(x.id) === String(userId));
  return u ? u.email : `user #${userId}`;
}

function combinedScans() {
  const recon = state.reconJobs.map(j => ({
    job_id: j.job_id, job_type: "recon", target: j.target, user_id: j.user_id,
    user_email: j.user_email || emailForUserId(j.user_id),
    status: j.status, created_at: j.created_at,
  }));
  const mod2 = state.module2Jobs.map(j => ({
    job_id: j.job_id, job_type: "module2", target: j.target, user_id: j.user_id,
    user_email: emailForUserId(j.user_id),
    status: j.status, created_at: j.created_at,
  }));
  return [...recon, ...mod2].sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
}

function renderScanStatusFilterChips() {
  const wrap = document.getElementById("scanStatusFilter");
  const statuses = [...new Set(combinedScans().map(s => (s.status || "").toLowerCase()).filter(Boolean))].sort();
  const current = state.scanStatusFilter;
  wrap.innerHTML = [`<span class="filter-chip ${current === "all" ? "active" : ""}" data-status="all">All statuses</span>`]
    .concat(statuses.map(s => `<span class="filter-chip ${current === s ? "active" : ""}" data-status="${escapeHtml(s)}">${escapeHtml(s)}</span>`))
    .join("");
  wrap.querySelectorAll(".filter-chip").forEach(chip => {
    chip.addEventListener("click", () => {
      wrap.querySelectorAll(".filter-chip").forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      state.scanStatusFilter = chip.dataset.status;
      scanPage.page = 1;
      renderScansTable();
    });
  });
}

function filteredScans() {
  const q = (document.getElementById("scanSearch")?.value || "").toLowerCase().trim();
  let rows = combinedScans();
  if (state.scanTypeFilter !== "all") rows = rows.filter(r => r.job_type === state.scanTypeFilter);
  if (state.scanStatusFilter !== "all") rows = rows.filter(r => (r.status || "").toLowerCase() === state.scanStatusFilter);
  if (q) rows = rows.filter(r => `${r.target || ""} ${r.user_email || ""}`.toLowerCase().includes(q));

  const { key, dir } = state.scanSort;
  rows = [...rows].sort((a, b) => {
    let av, bv;
    if (key === "target") { av = (a.target || "").toLowerCase(); bv = (b.target || "").toLowerCase(); }
    else if (key === "user") { av = (a.user_email || "").toLowerCase(); bv = (b.user_email || "").toLowerCase(); }
    else if (key === "status") { av = (a.status || "").toLowerCase(); bv = (b.status || "").toLowerCase(); }
    else { av = new Date(a.created_at || 0).getTime(); bv = new Date(b.created_at || 0).getTime(); }
    if (av < bv) return dir === "asc" ? -1 : 1;
    if (av > bv) return dir === "asc" ? 1 : -1;
    return 0;
  });
  return rows;
}

function renderScansTable() {
  const allFiltered = filteredScans();
  const totalPages = Math.max(1, Math.ceil(allFiltered.length / scanPage.size));
  scanPage.page = Math.min(scanPage.page, totalPages);
  const start = (scanPage.page - 1) * scanPage.size;
  const rows = allFiltered.slice(start, start + scanPage.size);

  if (!allFiltered.length) {
    document.getElementById("scansTable").innerHTML = `<p class="empty-state">No scans match your filters.</p>`;
    document.getElementById("scansPagination").innerHTML = "";
    return;
  }

  const sortHeader = (key, label) => {
    const active = state.scanSort.key === key;
    const arrow = active ? (state.scanSort.dir === "asc" ? "▲" : "▼") : "▲";
    return `<th class="sortable ${active ? "sorted" : ""}" data-sort-key="${key}">${label}<span class="sort-arrow">${arrow}</span></th>`;
  };

  const tableRows = rows.map(r => {
    const statusCls = (r.status || "").toLowerCase();
    const typeCls = r.job_type === "recon" ? "tag-teal" : "tag-amber";
const viewLink = r.job_type === "recon"
      ? `<a class="row-action-btn" href="view.html?job_id=${encodeURIComponent(r.job_id)}" onclick="event.stopPropagation()">View</a>`
      : `<a class="row-action-btn" href="view.html?job_id=${encodeURIComponent(r.job_id)}&mode=module2" onclick="event.stopPropagation()">View</a>`;
    return `<tr data-job-type="${r.job_type}" data-job-id="${escapeHtml(r.job_id)}">
      <td><span class="tag ${typeCls}">${r.job_type}</span></td>
      <td style="max-width:220px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${escapeHtml(r.target || "")}">${escapeHtml(r.target || "—")}</td>
      <td style="max-width:180px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${escapeHtml(r.user_email || "")}">${escapeHtml(r.user_email || "—")}</td>
      <td><span class="status-badge ${statusCls}">${escapeHtml(r.status || "unknown")}</span></td>
      <td>${formatDateTime(r.created_at)}</td>
      <td class="actions-cell" onclick="event.stopPropagation()">${viewLink}</td>
    </tr>`;
  }).join("");

  document.getElementById("scansTable").innerHTML = `
    <table class="mini-table">
      <thead><tr>
        <th>Type</th>
        ${sortHeader("target", "Target")}
        ${sortHeader("user", "User")}
        ${sortHeader("status", "Status")}
        ${sortHeader("created_at", "Created")}
        <th>Actions</th>
      </tr></thead>
      <tbody>${tableRows}</tbody>
    </table>`;

  renderPagination("scansPagination", scanPage, allFiltered.length, () => renderScansTable());

  document.querySelectorAll("#scansTable th.sortable").forEach(th => {
    th.addEventListener("click", () => {
      const key = th.dataset.sortKey;
      if (state.scanSort.key === key) state.scanSort.dir = state.scanSort.dir === "asc" ? "desc" : "asc";
      else { state.scanSort.key = key; state.scanSort.dir = "asc"; }
      renderScansTable();
    });
  });

  document.querySelectorAll("#scansTable tbody tr").forEach(tr => {
    tr.addEventListener("click", () => openScanDrawer(tr.dataset.jobType, tr.dataset.jobId));
  });
}

// ==========================================================================
//  Audit Logs
// ==========================================================================
async function loadAuditLogs() {
  try {
    const res = await fetch(`${API_BASE}/api/admin/audit?limit=1000`, { headers: authHeaders() });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    state.auditLogs = data.logs || [];
    renderAuditLogsTable();
  } catch (err) {
    document.getElementById("auditTable").innerHTML = `<p class="load-error">Failed to load audit logs: ${escapeHtml(err.message)}</p>`;
    toast(`Failed to load audit logs: ${err.message}`, "error");
  }
}

function filteredAuditLogs() {
  const q = (document.getElementById("auditSearch")?.value || "").toLowerCase().trim();
  let rows = state.auditLogs || [];
  if (q) {
    rows = rows.filter(r => {
      const email = (r.actor_email || "").toLowerCase();
      const action = (r.action || "").toLowerCase();
      const detailStr = JSON.stringify(r.detail || {}).toLowerCase();
      return email.includes(q) || action.includes(q) || detailStr.includes(q);
    });
  }

  const { key, dir } = state.auditSort;
  rows = [...rows].sort((a, b) => {
    let av, bv;
    if (key === "actor") { av = (a.actor_email || "").toLowerCase(); bv = (b.actor_email || "").toLowerCase(); }
    else if (key === "action") { av = (a.action || "").toLowerCase(); bv = (b.action || "").toLowerCase(); }
    else { av = new Date(a.created_at || 0).getTime(); bv = new Date(b.created_at || 0).getTime(); }

    if (av < bv) return dir === "asc" ? -1 : 1;
    if (av > bv) return dir === "asc" ? 1 : -1;
    return 0;
  });
  return rows;
}

function renderAuditLogsTable() {
  const allFiltered = filteredAuditLogs();
  const totalPages = Math.max(1, Math.ceil(allFiltered.length / auditPage.size));
  auditPage.page = Math.min(auditPage.page, totalPages);
  const start = (auditPage.page - 1) * auditPage.size;
  const rows = allFiltered.slice(start, start + auditPage.size);

  if (!allFiltered.length) {
    document.getElementById("auditTable").innerHTML = `<p class="empty-state">No audit logs match your search.</p>`;
    document.getElementById("auditPagination").innerHTML = "";
    return;
  }

  const sortHeader = (key, label) => {
    const active = state.auditSort.key === key;
    const arrow = active ? (state.auditSort.dir === "asc" ? "▲" : "▼") : "▲";
    return `<th class="sortable ${active ? "sorted" : ""}" data-sort-key="${key}">${label}<span class="sort-arrow">${arrow}</span></th>`;
  };

  const tableRows = rows.map(r => {
    const detailPretty = r.detail && Object.keys(r.detail).length ? JSON.stringify(r.detail) : "—";
    return `<tr>
      <td>${formatDateTime(r.created_at)}</td>
      <td><span class="tag tag-mono" style="background: rgba(255,23,68,0.12); color: var(--crimson); border: 1px solid rgba(255,23,68,0.3); font-family: var(--font-mono); font-size: 11px; padding: 2px 6px; border-radius: 4px;">${escapeHtml(r.action || "UNKNOWN")}</span></td>
      <td>
        <span class="audit-actor">${escapeHtml(r.actor_email || "SYSTEM")}</span>
        ${r.actor_id ? `<span class="audit-actor-id" style="color:var(--text-muted); font-size: 11px;">(ID: ${r.actor_id})</span>` : ""}
      </td>
      <td style="max-width:300px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-family:var(--font-mono); font-size:11px;" title="${escapeHtml(detailPretty)}">${escapeHtml(detailPretty)}</td>
    </tr>`;
  }).join("");

  document.getElementById("auditTable").innerHTML = `
    <table class="mini-table">
      <thead><tr>
        ${sortHeader("created_at", "Timestamp")}
        ${sortHeader("action", "Action")}
        ${sortHeader("actor", "Actor")}
        <th>Details</th>
      </tr></thead>
      <tbody>${tableRows}</tbody>
    </table>`;

  renderPagination("auditPagination", auditPage, allFiltered.length, () => renderAuditLogsTable());

  document.querySelectorAll("#auditTable th.sortable").forEach(th => {
    th.addEventListener("click", () => {
      const key = th.dataset.sortKey;
      if (state.auditSort.key === key) state.auditSort.dir = state.auditSort.dir === "asc" ? "desc" : "asc";
      else { state.auditSort.key = key; state.auditSort.dir = "asc"; }
      renderAuditLogsTable();
    });
  });
}

// ==========================================================================
//  Approvals
// ==========================================================================
async function loadApprovals() {
  try {
    const res = await fetch(`${API_BASE}/api/admin/approvals`, { headers: authHeaders() });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    state.approvals = data.pending || [];
    renderApprovalsTable();
  } catch (err) {
    document.getElementById("approvalsTable").innerHTML = `<p class="load-error">Failed to load pending approvals: ${escapeHtml(err.message)}</p>`;
    toast(`Failed to load approvals: ${err.message}`, "error");
  }
}

function renderApprovalsTable() {
  const rows = state.approvals || [];
  if (!rows.length) {
    document.getElementById("approvalsTable").innerHTML = `<p class="empty-state">No pending approvals.</p>`;
    return;
  }

  const tableRows = rows.map(r => `
    <tr>
      <td><span class="tag ${r.job_type === 'recon' ? 'tag-teal' : 'tag-amber'}">${r.job_type}</span></td>
      <td><span class="audit-actor">${escapeHtml(r.user_email || "unknown")}</span></td>
      <td style="max-width:300px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${escapeHtml(r.target || "")}">${escapeHtml(r.target || "—")}</td>
      <td>${formatDateTime(r.created_at * 1000)}</td>
      <td class="actions-cell">
        <button type="button" class="btn-mini primary approve-btn" data-job-id="${escapeHtml(r.job_id)}"><i class="fa-solid fa-check"></i> Approve</button>
        <button type="button" class="btn-mini reject-btn" data-job-id="${escapeHtml(r.job_id)}"><i class="fa-solid fa-xmark"></i> Reject</button>
      </td>
    </tr>
  `).join("");

  document.getElementById("approvalsTable").innerHTML = `
    <table class="mini-table">
      <thead><tr>
        <th>Type</th>
        <th>Requested By</th>
        <th>Target</th>
        <th>Requested At</th>
        <th>Actions</th>
      </tr></thead>
      <tbody>${tableRows}</tbody>
    </table>`;

  document.querySelectorAll("#approvalsTable .approve-btn").forEach(btn => {
    btn.addEventListener("click", () => approveScan(btn.dataset.jobId));
  });
  document.querySelectorAll("#approvalsTable .reject-btn").forEach(btn => {
    btn.addEventListener("click", () => rejectScan(btn.dataset.jobId));
  });
}

async function approveScan(jobId) {
  try {
    const res = await fetch(`${API_BASE}/api/admin/approvals/${jobId}/approve`, {
      method: "POST", headers: authHeaders()
    });
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).detail || `HTTP ${res.status}`);
    toast("Scan approved successfully", "success");
    await loadApprovals();
  } catch (err) {
    toast(`Failed to approve scan: ${err.message}`, "error");
  }
}

async function rejectScan(jobId) {
  const ok = await confirmDialog("Reject scan?", "Are you sure you want to reject this scan? This will discard the scan request.");
  if (!ok) return;
  try {
    const res = await fetch(`${API_BASE}/api/admin/approvals/${jobId}/reject`, {
      method: "POST", headers: authHeaders()
    });
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).detail || `HTTP ${res.status}`);
    toast("Scan rejected and discarded", "success");
    await loadApprovals();
  } catch (err) {
    toast(`Failed to reject scan: ${err.message}`, "error");
  }
}

// ==========================================================================
//  Global search (topbar) — jumps to the relevant tab & filters it
// ==========================================================================
function initGlobalSearch() {
  const input = document.getElementById("globalSearch");
  const dropdown = document.getElementById("gsDropdown");
  if (!input || !dropdown) return;

  function render() {
    const q = input.value.trim().toLowerCase();
    if (!q) { dropdown.classList.remove("show"); dropdown.innerHTML = ""; return; }

    const userMatches = state.users.filter(u =>
      `${u.first_name || ""} ${u.last_name || ""} ${u.email || ""} ${u.organization || ""}`.toLowerCase().includes(q)
    ).slice(0, 5);
    const scanMatches = combinedScans().filter(s =>
      `${s.target || ""} ${s.user_email || ""}`.toLowerCase().includes(q)
    ).slice(0, 5);

    if (!userMatches.length && !scanMatches.length) {
      dropdown.innerHTML = `<div class="gs-empty">No users or scans match "${escapeHtml(input.value.trim())}"</div>`;
      dropdown.classList.add("show");
      return;
    }

    let html = "";
    if (userMatches.length) {
      html += `<div class="gs-group-label">Users</div>` + userMatches.map(u => `
        <div class="gs-item" data-kind="user" data-id="${u.id}">
          <div class="gs-title">${escapeHtml(`${u.first_name || ""} ${u.last_name || ""}`.trim() || u.email)}</div>
          <div class="gs-sub">${escapeHtml(u.email || "")}</div>
        </div>`).join("");
    }
    if (scanMatches.length) {
      html += `<div class="gs-group-label">Scans</div>` + scanMatches.map(s => `
        <div class="gs-item" data-kind="scan" data-type="${s.job_type}" data-id="${escapeHtml(s.job_id)}">
          <div class="gs-title">${escapeHtml(s.target || "Unknown target")}</div>
          <div class="gs-sub">${escapeHtml(s.job_type)} · ${escapeHtml(s.user_email || "")}</div>
        </div>`).join("");
    }
    dropdown.innerHTML = html;
    dropdown.classList.add("show");

    dropdown.querySelectorAll(".gs-item").forEach(item => {
      item.addEventListener("click", () => {
        if (item.dataset.kind === "user") {
          document.querySelector('.admin-tab[data-tab="users"]').click();
          document.getElementById("userSearch").value = "";
          openUserDrawer(item.dataset.id);
        } else {
          document.querySelector('.admin-tab[data-tab="scans"]').click();
          document.getElementById("scanSearch").value = "";
          openScanDrawer(item.dataset.type, item.dataset.id);
        }
        dropdown.classList.remove("show");
        input.value = "";
      });
    });
  }

  input.addEventListener("input", render);
  input.addEventListener("focus", render);
  document.addEventListener("click", (e) => {
    if (!e.target.closest(".global-search-wrap")) dropdown.classList.remove("show");
  });
}

// ==========================================================================
//  Right-rail quick glance
// ==========================================================================
function renderRecentUsers() {
  const list = document.getElementById("recentUsersList");
  if (!list) return;
  const recent = [...state.users].sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).slice(0, 5);
  if (!recent.length) { list.innerHTML = `<li class="section-note">No users yet.</li>`; return; }
  list.innerHTML = recent.map(u => `
    <li>
      <div class="ql-title">${escapeHtml(`${u.first_name || ""} ${u.last_name || ""}`.trim() || u.email)}</div>
      <div class="ql-meta">${escapeHtml(u.email)} · ${escapeHtml(u.role || "no role")}</div>
    </li>`).join("");
}

function renderRecentScans() {
  const list = document.getElementById("recentScansList");
  if (!list) return;
  const recent = combinedScans().slice(0, 5);
  if (!recent.length) { list.innerHTML = `<li class="section-note">No scans yet.</li>`; return; }
  list.innerHTML = recent.map(r => `
    <li>
      <div class="ql-title">${escapeHtml(r.target || "unknown target")}</div>
      <div class="ql-meta">${r.job_type} · ${escapeHtml(r.status || "")} · ${escapeHtml(r.user_email || "")}</div>
    </li>`).join("");
}
