
const API_BASE = "";
const AUTH_TOKEN = sessionStorage.getItem("authToken");
const LOGGED_IN = sessionStorage.getItem("loggedIn") === "true" && AUTH_TOKEN;
if (!LOGGED_IN) {
  window.location.href = "login.html";
}

function authHeaders() {
  return AUTH_TOKEN ? { Authorization: `Bearer ${AUTH_TOKEN}` } : {};
}

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str == null ? "" : String(str);
  return d.innerHTML;
}

function formatDateTime(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.valueOf())) return String(value);
  return date.toLocaleString();
}

function renderModule2HistoryTable(items) {
  if (!items || !items.length) {
    return `<p class="section-note">No Module 2 history available yet.</p>`;
  }
  return `<div class="history-list">${items.map(item => {
    const statusClass = item.status === "completed" ? "history-ok" : item.status === "error" ? "history-err" : "history-pending";
    const target = item.target || (item.has_uploaded_code ? "(uploaded code)" : "—");
    const agents = (item.agents && item.agents.length) ? item.agents.join(", ") : "";
    return `<button type="button" class="history-entry ${statusClass}" data-job-id="${escapeHtml(item.job_id)}">
      <div class="history-entry-main">
        <div class="history-entry-title">${escapeHtml(target)}</div>
        <div class="history-entry-meta">${escapeHtml(agents || "—")} • ${formatDateTime(item.created_at)}</div>
      </div>
      <div class="history-entry-status">${escapeHtml(item.status)}</div>
    </button>`;
  }).join("")}</div>`;
}

async function loadModule2History() {
  const historyList = document.getElementById("module2HistoryList");
  if (!historyList) return;
  historyList.innerHTML = `<p class="section-note">Loading your Module 2 history...</p>`;
  try {
    const res = await fetch(`${API_BASE}/api/module2/history`, {
      headers: authHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Server responded ${res.status}`);
    }
    const data = await res.json();
    historyList.innerHTML = renderModule2HistoryTable(data.history);
    historyList.querySelectorAll(".history-entry").forEach(btn => {
      btn.addEventListener("click", () => {
        const jobId = btn.getAttribute("data-job-id");
        window.location.href = `view.html?job_id=${encodeURIComponent(jobId)}&mode=module2`;
      });
    });
  } catch (err) {
    historyList.innerHTML = `<p class="section-note">Could not load history: ${escapeHtml(err.message)}</p>`;
  }
}

/* ==========================================================================
   AUTH NAVIGATION
   ========================================================================== */
window.addEventListener("DOMContentLoaded", () => {
  // Apply globally-synced theme (Classic / Hacker / CEO) from theme.js
  if (window.CYVERION_THEME) window.CYVERION_THEME.init();

  const logoutLink = document.getElementById("logoutLink");
  const navLoginLink = document.getElementById("navLoginLink");
  const navRegisterLink = document.getElementById("navRegisterLink");

  if (logoutLink) {
    logoutLink.addEventListener("click", async (e) => {
      e.preventDefault();
      const token = sessionStorage.getItem("authToken");
      try {
        if (token) {
          await fetch(`${API_BASE}/api/auth/logout`, { method: "POST", headers: { "Authorization": `Bearer ${token}` } });
        }
      } catch (err) {
        // ignore logout errors and continue clearing session
      }
      sessionStorage.clear();
      window.location.href = "login.html";
    });
  }

  if (navLoginLink) navLoginLink.style.display = "none";
  if (navRegisterLink) navRegisterLink.style.display = "none";

  const adminLink = document.getElementById("adminLink");
  const userRole = sessionStorage.getItem("userRole") || "";
  if (adminLink && userRole.toLowerCase() === "admin") {
    adminLink.style.display = "inline-block";
  }

  loadModule2History();
});

/* ==========================================================================
   DOM refs
   ========================================================================== */
const module2Form = document.getElementById("module2Form");
const targetInput = document.getElementById("targetInput");
const aggressiveCheck = document.getElementById("aggressiveCheck");
const authorizedCheck = document.getElementById("authorizedCheck");
const agentPicker = document.getElementById("agentPicker");
const launchBtn = document.getElementById("launchBtn");

const dropzone = document.getElementById("dropzone");
const folderInput = document.getElementById("folderInput");
const fileInput = document.getElementById("fileInput");
const pickFolderBtn = document.getElementById("pickFolderBtn");
const pickFilesBtn = document.getElementById("pickFilesBtn");
const fileCount = document.getElementById("fileCount");

let selectedFiles = [];

function updateFileCount() {
  fileCount.textContent = selectedFiles.length
    ? `${selectedFiles.length} file(s) selected`
    : "";
}

pickFolderBtn.addEventListener("click", () => folderInput.click());
pickFilesBtn.addEventListener("click", () => fileInput.click());
folderInput.addEventListener("change", () => { selectedFiles = Array.from(folderInput.files); updateFileCount(); clearFolderInvalid(); });
fileInput.addEventListener("change", () => { selectedFiles = Array.from(fileInput.files); updateFileCount(); clearFolderInvalid(); });
dropzone.addEventListener("dragover", (e) => { e.preventDefault(); dropzone.classList.add("dragover"); });
dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));
dropzone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropzone.classList.remove("dragover");
  const dropped = Array.from(e.dataTransfer.files || []);
  if (dropped.length) { selectedFiles = dropped; updateFileCount(); clearFolderInvalid(); }
});

const terminalBody = document.getElementById("terminalBody");
const jobIdLabel = document.getElementById("jobIdLabel");
const statusDot = document.getElementById("statusDot");
const statusLabel = document.getElementById("statusLabel");
const findingsList = document.getElementById("findingsList");
const severitySummary = document.getElementById("severitySummary");
const scorecardWrap = document.getElementById("scorecardWrap");

const modalBackdrop = document.getElementById("modalBackdrop");
const modalClose = document.getElementById("modalClose");
const modalSeverity = document.getElementById("modalSeverity");
const modalTitle = document.getElementById("modalTitle");
const modalMeta = document.getElementById("modalMeta");
const modalDesc = document.getElementById("modalDesc");
const modalEvidence = document.getElementById("modalEvidence");
const modalEvidenceLabel = document.getElementById("modalEvidenceLabel");
const modalFixBlock = document.getElementById("modalFixBlock");
const modalFixTextarea = document.getElementById("modalFixTextarea");
const applyFixBtn = document.getElementById("applyFixBtn");
const fixStatusMsg = document.getElementById("fixStatusMsg");
const downloadZipBtn = document.getElementById("downloadZipBtn");
const modalRecommendation = document.getElementById("modalRecommendation");
let currentJobId = null;
const assistantChat = document.getElementById("assistantChat");
const assistantInput = document.getElementById("assistantInput");
const assistantForm = document.getElementById("assistantForm");
const assistantPills = document.querySelectorAll(".assistant-pill");

let currentFindings = [];
let currentFinding = null;

function normalizeTargetInput(raw) {
  if (!raw || !raw.trim()) throw new Error("Target is required.");
  if (raw.includes(" ")) throw new Error("Target must not contain spaces.");
  let value = raw.trim();
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(value)) value = `https://${value}`;
  let url;
  try {
    url = new URL(value);
  } catch {
    throw new Error("Enter a valid domain or URL.");
  }
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("Only http:// and https:// targets are allowed.");
  if (url.username || url.password) throw new Error("Credentials are not allowed in the target URL.");
  if (!url.hostname) throw new Error("Target must include a hostname.");
  return url.href;
}

/* ==========================================================================
   INPUT VALIDATION — fake link & empty folder detection
   ========================================================================== */
async function checkTargetReachability(url) {
  // Browsers block client-side cross-origin fetches with CORS, so real sites
  // (e.g. https://www.shopsy.in/) would appear unreachable even when they are
  // valid. Delegate the reachability test to the backend, which performs DNS +
  // HTTP checks with no CORS restriction.
  const apiBase = window.API_BASE || API_BASE || "";
  try {
    const formData = new FormData();
    formData.append("target", url);
    const res = await fetch(`${apiBase}/api/validate/target`, {
      method: "POST",
      body: formData,
      headers: authHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      return { reachable: false, reason: err.detail || "Validation service returned an error." };
    }
    const data = await res.json();
    if (data.valid) {
      return { reachable: true, statusCode: data.status_code };
    }
    return { reachable: false, reason: data.reason || "This link appears invalid/fake." };
  } catch (err) {
    return {
      reachable: false,
      reason: "Could not reach the validation service. Is the backend running (uvicorn main:app)?",
    };
  }
}

function markTargetInvalid(message) {
  if (targetInput) {
    targetInput.classList.add("input-invalid");
  }
  const tip = document.getElementById("targetErrorTip");
  if (tip) {
    tip.textContent = "⚠ " + message;
    tip.classList.add("visible");
  }
}

function clearTargetInvalid() {
  if (targetInput) {
    targetInput.classList.remove("input-invalid");
  }
  const tip = document.getElementById("targetErrorTip");
  if (tip) {
    tip.textContent = "";
    tip.classList.remove("visible");
  }
}

if (targetInput) {
  targetInput.addEventListener("input", clearTargetInvalid);
}

function markFolderInvalid(message) {
  if (dropzone) dropzone.classList.add("dropzone-invalid");
  const tip = document.getElementById("folderErrorTip");
  if (tip) {
    tip.textContent = "⚠ " + message;
    tip.classList.add("visible");
  }
}

function clearFolderInvalid() {
  if (dropzone) dropzone.classList.remove("dropzone-invalid");
  const tip = document.getElementById("folderErrorTip");
  if (tip) {
    tip.textContent = "";
    tip.classList.remove("visible");
  }
}

function logLine(text, cls = "") {
  const p = document.createElement("p");
  p.className = `term-line ${cls}`;
  const ts = new Date().toLocaleTimeString();
  p.innerHTML = `<span class="term-ts">[${ts}]</span>${escapeHtml(text)}`;
  terminalBody.appendChild(p);
  terminalBody.scrollTop = terminalBody.scrollHeight;
}

function setStatus(state, label) {
  if (statusDot) statusDot.className = `status-dot ${state}`;
  if (statusLabel) statusLabel.textContent = label;
}

function setAgentState(agent, state) {
  const node = document.querySelector(`.agent-node[data-agent="${agent}"]`);
  if (!node) return;
  node.classList.remove("active", "done", "error");
  if (state) node.classList.add(state);
}

function resetAgentStates() {
  document.querySelectorAll(".agent-node").forEach(n => n.classList.remove("active", "done", "error"));
}

/* ==========================================================================
   Findings rendering
   ========================================================================== */
const SEV_ORDER = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };
const SEV_COLOR_VAR = { critical: "crimson", high: "amber", medium: "amber", low: "blue", info: "text-muted" };

function renderFindings(findings) {
  currentFindings = findings || [];

  const counts = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };
  currentFindings.forEach(f => {
    if (!f.is_fixed && counts[f.severity] !== undefined) counts[f.severity]++;
  });
  severitySummary.querySelectorAll(".chip").forEach(chip => {
    chip.textContent = counts[chip.dataset.sev] ?? 0;
  });

  if (!currentFindings.length) {
    findingsList.innerHTML = `<p class="empty-state">No findings yet.</p>`;
    return;
  }

  const sorted = [...currentFindings].sort((a, b) => (SEV_ORDER[a.severity] ?? 9) - (SEV_ORDER[b.severity] ?? 9));
  findingsList.innerHTML = "";
  sorted.forEach((f) => {
    const card = document.createElement("div");
    card.className = `finding-card sev-${f.severity}${f.is_fixed ? ' fixed-finding' : ''}`;
    card.innerHTML = `
      <div class="finding-card-top">
        <span class="finding-sev-tag" style="color:var(--${SEV_COLOR_VAR[f.severity] || "text-muted"})">${escapeHtml(f.severity)}</span>
        <span class="finding-card-agent">${escapeHtml(f.agent_label || f.agent || "")}${f.finding_type === "source_code" ? " · code" : ""}</span>
        ${f.is_fixed ? '<span class="fixed-badge-mini"><i class="fa-solid fa-circle-check"></i> Fixed</span>' : ''}
      </div>
      <div class="finding-card-title">${escapeHtml(f.title)}</div>
      <div class="finding-card-sub">${f.finding_type === "source_code"
        ? escapeHtml(`${f.file_path}:${f.line}`)
        : escapeHtml(f.method || "") + " " + escapeHtml(f.url || "") + (f.param ? " — param: " + escapeHtml(f.param) : "")}</div>
    `;
    card.addEventListener("click", () => openModal(f));
    findingsList.appendChild(card);
  });
}

let chatHistory = [];

function renderAssistantMessage(text, who = "bot") {
  if (!assistantChat) return;
  const bubble = document.createElement("div");
  bubble.className = `assistant-bubble ${who === "user" ? "assistant-bubble-user" : "assistant-bubble-bot"}`;
  bubble.textContent = text;
  assistantChat.appendChild(bubble);
  assistantChat.scrollTop = assistantChat.scrollHeight;
}

function renderAssistantMarkdownMessage(text, who = "bot") {
  if (!assistantChat) return;
  const bubble = document.createElement("div");
  bubble.className = `assistant-bubble ${who === "user" ? "assistant-bubble-user" : "assistant-bubble-bot"}`;
  
  let html = escapeHtml(text);
  
  // 1. Code blocks (```lang ... ```)
  const codeBlockRegex = /```(?:[a-zA-Z0-9]+)?\n([\s\S]*?)```/g;
  html = html.replace(codeBlockRegex, (match, code) => {
    return `<pre class="chat-code-block"><code>${code}</code></pre>`;
  });
  
  // 2. Bold (**text**)
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  
  // 3. Line breaks
  html = html.replace(/\n/g, '<br>');
  
  // 4. Alerts/Notes (e.g. > [!IMPORTANT])
  html = html.replace(/&gt;\s*\[!(NOTE|TIP|IMPORTANT|WARNING|CAUTION)\]<br>([\s\S]*?)(?=<br><br>|<br>&gt;|$)/g, (match, type, content) => {
    const alertClass = type.toLowerCase();
    return `<div class="chat-alert chat-alert-${alertClass}"><strong>${type}:</strong> ${content}</div>`;
  });
  
  bubble.innerHTML = html;
  assistantChat.appendChild(bubble);
  assistantChat.scrollTop = assistantChat.scrollHeight;
}

async function askAssistant(promptText) {
  if (!currentFinding) return;
  
  if (promptText) {
    renderAssistantMessage(promptText, "user");
  }
  
  const loadingEl = document.createElement("div");
  loadingEl.className = "assistant-bubble assistant-bubble-bot assistant-bubble-loading";
  loadingEl.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Analyzing vulnerability details...`;
  assistantChat.appendChild(loadingEl);
  assistantChat.scrollTop = assistantChat.scrollHeight;
  
  try {
    const res = await fetch(`${API_BASE}/api/module2/chat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...authHeaders()
      },
      body: JSON.stringify({
        finding: currentFinding,
        prompt: promptText || "Suggest a secure code fix",
        history: chatHistory
      })
    });
    
    if (loadingEl.parentNode) {
      loadingEl.parentNode.removeChild(loadingEl);
    }
    
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Server returned ${res.status}`);
    }
    
    const data = await res.json();
    const reply = data.response;
    
    if (promptText) {
      chatHistory.push({ role: "user", text: promptText });
    }
    chatHistory.push({ role: "assistant", text: reply });
    
    renderAssistantMarkdownMessage(reply, "bot");
  } catch (err) {
    if (loadingEl.parentNode) {
      loadingEl.parentNode.removeChild(loadingEl);
    }
    renderAssistantMessage(`Error: ${err.message}`, "bot");
  }
}

function openModal(f) {
  currentFinding = f;
  modalSeverity.textContent = (f.severity || "").toUpperCase();
  modalSeverity.style.color = `var(--${SEV_COLOR_VAR[f.severity] || "text-muted"})`;
  modalSeverity.style.borderColor = `var(--${SEV_COLOR_VAR[f.severity] || "text-muted"})`;
  modalTitle.textContent = f.title;

  const isSourceCode = f.finding_type === "source_code";
  modalMeta.textContent = isSourceCode
    ? `${f.agent_label || f.agent || ""} — ${f.file_path}:${f.line} — ${f.cwe || "n/a"}`
    : `${f.agent_label || f.agent || ""} — ${f.cwe || "n/a"} — ${f.rule_id || ""}`;
  modalDesc.textContent = f.description || "";
  modalRecommendation.textContent = f.recommendation || "No remediation guidance available.";

  if (isSourceCode) {
    modalEvidenceLabel.textContent = `Vulnerable Code (${f.file_path}, line ${f.line})`;
    modalEvidence.textContent = (f.evidence && f.evidence.code_snippet) || "(no code snippet captured)";
    if (f.suggested_fix) {
      modalFixTextarea.value = f.suggested_fix;
      modalFixBlock.hidden = false;
      
      if (applyFixBtn && fixStatusMsg) {
        if (f.is_fixed) {
          applyFixBtn.disabled = true;
          modalFixTextarea.disabled = true;
          fixStatusMsg.style.color = "#10b981";
          fixStatusMsg.textContent = "✓ Fix successfully applied";
        } else {
          applyFixBtn.disabled = false;
          modalFixTextarea.disabled = false;
          fixStatusMsg.textContent = "";
        }
      }
    } else {
      modalFixBlock.hidden = true;
    }
  } else {
    modalFixBlock.hidden = true;
    modalEvidenceLabel.textContent = "Live Evidence (real request/response captured from the target)";
    let evidenceText = "(no evidence captured)";
    if (f.evidence) {
      if (typeof f.evidence === "string") {
        evidenceText = f.evidence;
      } else {
        const ev = f.evidence;
        const parts = [];
        if (ev.request) parts.push(`Request: ${ev.request}`);
        if (ev.status_code !== undefined) parts.push(`Status: ${ev.status_code}`);
        if (ev.response_time_s !== undefined) parts.push(`Response time: ${ev.response_time_s}s`);
        if (ev.note) parts.push(`Note: ${ev.note}`);
        if (ev.error) parts.push(`Error: ${ev.error}`);
        if (ev.response_snippet) parts.push(`\n--- Response snippet ---\n${ev.response_snippet}`);
        evidenceText = parts.join("\n");
      }
    }
    modalEvidence.textContent = evidenceText;
  }

  // Reset chatbot conversation and fetch initial secure suggestions automatically
  chatHistory = [];
  if (assistantChat) {
    assistantChat.innerHTML = "";
    renderAssistantMessage("Ask me to explain the issue, suggest a secure patch, or help you decide whether to approve or reject it.", "bot");
    askAssistant("Explain the vulnerability and suggest a secure code fix.");
  }

  modalBackdrop.classList.add("open");
}

if (assistantForm) {
  assistantForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const prompt = assistantInput.value.trim();
    if (!prompt) return;
    assistantInput.value = "";
    askAssistant(prompt);
  });
}

assistantPills.forEach((pill) => {
  pill.addEventListener("click", () => {
    const prompt = pill.dataset.prompt || "";
    if (prompt) {
      askAssistant(prompt);
    }
  });
});


modalClose.addEventListener("click", () => modalBackdrop.classList.remove("open"));
modalBackdrop.addEventListener("click", (e) => { if (e.target === modalBackdrop) modalBackdrop.classList.remove("open"); });

/* ==========================================================================
   Executive summary scorecard
   ========================================================================== */
function renderScorecard(s) {
  if (!s) { scorecardWrap.hidden = true; return; }
  const ratingClass = s.risk_rating === "Good" ? "score-good" : s.risk_rating === "Needs Attention" ? "score-warn" : "score-bad";
  scorecardWrap.hidden = false;
  scorecardWrap.innerHTML = `
    <div class="scorecard">
      <div class="scorecard-main ${ratingClass}">
        <div class="scorecard-number">${s.risk_score}</div>
        <div class="scorecard-label">/ 100 — ${escapeHtml(s.risk_rating)}</div>
      </div>
      <div class="scorecard-grid">
        <div class="scorecard-item sev-critical-text"><span class="sc-num">${s.severity_counts.critical}</span><span class="sc-label">Critical</span></div>
        <div class="scorecard-item sev-high-text"><span class="sc-num">${s.severity_counts.high}</span><span class="sc-label">High</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.severity_counts.medium}</span><span class="sc-label">Medium</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.severity_counts.low}</span><span class="sc-label">Low</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.total_findings}</span><span class="sc-label">Total Findings</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.agents_run.length}</span><span class="sc-label">Agents Run</span></div>
      </div>
    </div>`;
}

/* ==========================================================================
   Submit / launch scan
   ========================================================================== */
module2Form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const rawTarget = targetInput.value.trim();

  let normalizedTarget = null;
  if (rawTarget) {
    try {
      normalizedTarget = normalizeTargetInput(rawTarget);
    } catch (err) {
      logLine(`Invalid target: ${err.message}`, "term-warn");
      return;
    }
  }

  if (!normalizedTarget && !selectedFiles.length) {
    logLine("Provide a target URL and/or upload a project folder to scan.", "term-warn");
    return;
  }
  if (normalizedTarget && !authorizedCheck.checked) {
    logLine("You must confirm authorization before running active agents against a live target.", "term-warn");
    return;
  }

  // ---- Empty folder detection: if a folder was chosen but holds no files ----
  if (selectedFiles.length === 0) {
    // No files at all selected — nothing to scan from source upload.
  } else {
    // Filter out empty directories (folder entries can appear with size 0 / no content).
    const sourceFiles = selectedFiles.filter(f => f.size > 0);
    if (sourceFiles.length === 0) {
      markFolderInvalid("The selected folder is empty (contains no readable source files). Please choose a non-empty folder.");
      logLine("Empty folder detected — no readable files found to scan. Scan aborted.", "term-err");
      return;
    }
  }

  // ---- Fake / unreachable link detection ----
  if (normalizedTarget) {
    clearTargetInvalid();
    logLine("Checking target link reachability...", "term-muted");
    const linkCheck = await checkTargetReachability(normalizedTarget);
    if (!linkCheck.reachable) {
      markTargetInvalid(linkCheck.reason);
      logLine(`Invalid target: ${linkCheck.reason}. Scan not started — the link appears invalid/fake.`, "term-err");
      return;
    }
    clearTargetInvalid();
    logLine(`Target link verified — host is reachable (${linkCheck.statusCode || "OK"}).`, "term-ok");
  }

  const selectedAgents = Array.from(agentPicker.querySelectorAll("input[type=checkbox]:checked")).map(i => i.value);

  launchBtn.disabled = true;
  terminalBody.innerHTML = "";
  scorecardWrap.hidden = true;
  renderFindings([]);
  resetAgentStates();
  setStatus("running", "Module 2 agents running...");
  logLine("Preparing Module 2 job...", "term-muted");

  const formData = new FormData();
  if (normalizedTarget) formData.append("target", normalizedTarget);
  formData.append("agents", selectedAgents.join(","));
  formData.append("aggressive", aggressiveCheck.checked ? "true" : "false");
  formData.append("authorized", normalizedTarget ? "true" : "false");
  selectedFiles.forEach(f => {
    // webkitRelativePath preserves folder structure when a whole folder was chosen
    const name = f.webkitRelativePath || f.name;
    formData.append("files", f, name);
  });

  try {
    const res = await fetch(`${API_BASE}/api/module2/start`, {
      method: "POST",
      body: formData,
      headers: authHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Server responded ${res.status}`);
    }
    const data = await res.json();
    currentJobId = data.job_id;
    jobIdLabel.textContent = `job ${data.job_id}`;
    logLine(`Job ${data.job_id} created. Streaming live agent activity...`, "term-ok");
    streamJob(data.job_id);
  } catch (err) {
    logLine(`Failed to start scan: ${err.message}. Is the backend running (uvicorn main:app)?`, "term-err");
    setStatus("error", "Failed to start");
    launchBtn.disabled = false;
  }
});

function streamJob(jobId) {
  const token = encodeURIComponent(AUTH_TOKEN || "");
  const esUrl = `${API_BASE}/api/module2/stream/${jobId}?token=${token}`;
  let es = null;
  let reconnectAttempts = 0;

  function connect() {
    es = new EventSource(esUrl);
    es.onmessage = onMessage;
    es.onerror = onError;
  }

  function onMessage(event) {
    reconnectAttempts = 0;
    const payload = JSON.parse(event.data);

    if (payload.done) {
      logLine(`Module 2 scan finished (${payload.status}).`, payload.status === "error" ? "term-err" : "term-ok");
      setStatus(payload.status === "error" ? "error" : "done", payload.status === "error" ? "Scan error" : "Scan complete");
      launchBtn.disabled = false;
      if (es) es.close();
      loadReport(jobId);
      loadModule2History();
      return;
    }

    const cls = payload.status === "error" ? "term-err"
      : payload.status === "completed" ? "term-ok"
      : payload.status === "started" ? "term-agent" : "term-muted";
    logLine(`[${payload.agent}] ${payload.message}`, cls);

    if (payload.status === "started") setAgentState(payload.agent, "active");
    if (payload.status === "completed") setAgentState(payload.agent, "done");
    if (payload.status === "error") setAgentState(payload.agent, "error");
  }

  function onError() {
    if (es) try { es.close(); } catch (e) {}
    reconnectAttempts += 1;
    const wait = Math.min(30000, 500 * Math.pow(2, reconnectAttempts));
    logLine(`Connection lost. Reconnecting in ${Math.round(wait / 1000)}s...`, "term-warn");
    setTimeout(connect, wait);
  }

  connect();
}

async function loadReport(jobId) {
  currentJobId = jobId;
  try {
    const res = await fetch(`${API_BASE}/api/module2/report/${jobId}`, {
      headers: authHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Server responded ${res.status}`);
    }
    const data = await res.json();
    const report = data.report || {};
    renderFindings(report.findings || []);
    renderScorecard(report.executive_summary);

    if (downloadZipBtn) {
      if (data.has_uploaded_code) {
        downloadZipBtn.style.display = "inline-flex";
        downloadZipBtn.onclick = () => {
          window.open(`${API_BASE}/api/module2/download_fixed/${jobId}?token=${encodeURIComponent(AUTH_TOKEN || "")}`, "_blank");
        };
      } else {
        downloadZipBtn.style.display = "none";
      }
    }
  } catch (err) {
    logLine(`Could not load report: ${err.message}`, "term-err");
  }
}

if (applyFixBtn) {
  applyFixBtn.addEventListener("click", async () => {
    if (!currentFinding || !currentJobId) return;
    const patchCode = modalFixTextarea.value;
    applyFixBtn.disabled = true;
    modalFixTextarea.disabled = true;
    fixStatusMsg.style.color = "var(--text-muted)";
    fixStatusMsg.textContent = "Applying secure patch...";
    
    try {
      const res = await fetch(`${API_BASE}/api/module2/fix`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...authHeaders()
        },
        body: JSON.stringify({
          job_id: currentJobId,
          file_path: currentFinding.file_path,
          line: currentFinding.line,
          suggested_fix: patchCode
        })
      });
      
      if (!res.ok) {
        const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
        throw new Error(err.detail || `Server returned ${res.status}`);
      }
      
      const data = await res.json();
      
      currentFinding.is_fixed = true;
      currentFinding.suggested_fix = patchCode;
      if (!currentFinding.evidence) currentFinding.evidence = {};
      currentFinding.evidence.code_snippet = patchCode;
      
      modalEvidence.textContent = patchCode;
      
      fixStatusMsg.style.color = "#10b981";
      if (data.fixed_in_workspace) {
        fixStatusMsg.textContent = "✓ Fixed in local workspace!";
      } else {
        fixStatusMsg.textContent = "✓ Fixed in scan session files!";
      }
      
      if (data.report) {
        renderFindings(data.report.findings || []);
        renderScorecard(data.report.executive_summary);
      } else {
        renderFindings(currentFindings);
      }
    } catch (err) {
      applyFixBtn.disabled = false;
      modalFixTextarea.disabled = false;
      fixStatusMsg.style.color = "var(--crimson)";
      fixStatusMsg.textContent = `Error: ${err.message}`;
    }
  });
}
