/* ==========================================================================
   CYVERION — Role → Page routing
   Single source of truth for "which page does this role land on".
   Loaded by login.js (to redirect after auth) and by every role-specific
   page (to guard against a user landing somewhere they shouldn't be).
   ========================================================================== */

// Keys are lower-cased for matching; values are the page to send that role to.
const ROLE_PAGE_MAP = {
  "student": "student.html",
  "developer": "developer.html",
  "security analyst": "security-analyst.html",
  "penetration tester": "pentester.html",
  "administrator": "admin.html",
  "admin": "admin.html", // hardcoded/dev login issues role: "admin"
};

const DEFAULT_ROLE_PAGE = "recon.html";

/**
 * Returns the landing page for a given role string (case-insensitive).
 * Falls back to the generic recon console if the role is unrecognized/blank.
 */
function getPageForRole(role) {
  const key = (role || "").trim().toLowerCase();
  return ROLE_PAGE_MAP[key] || DEFAULT_ROLE_PAGE;
}

/**
 * Guards a role-specific page: redirects to login if not authenticated,
 * and redirects to the *correct* role page if the logged-in user's role
 * doesn't match the page they're on.
 * @param {string} expectedRole - the role this page is meant for, e.g. "Student"
 */
function enforceRolePage(expectedRole) {
  const loggedIn = sessionStorage.getItem("loggedIn") === "true" && sessionStorage.getItem("authToken");
  if (!loggedIn) {
    window.location.href = "login.html";
    return;
  }
  const userRole = (sessionStorage.getItem("userRole") || "").trim().toLowerCase();
  const expected = (expectedRole || "").trim().toLowerCase();

  // Administrators can view any role console; everyone else must match exactly.
  if (userRole !== expected && userRole !== "admin" && userRole !== "administrator") {
    window.location.href = getPageForRole(userRole);
  }
}
