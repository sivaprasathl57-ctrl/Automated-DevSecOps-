const API_BASE = "";
const AUTH_TOKEN = sessionStorage.getItem("authToken");
const LOGGED_IN = sessionStorage.getItem("loggedIn") === "true" && AUTH_TOKEN;
if (!LOGGED_IN) {
  window.location.href = "login.html";
}

function authHeaders() {
  return AUTH_TOKEN ? { Authorization: `Bearer ${AUTH_TOKEN}` } : {};
}

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str == null ? "" : String(str);
  return d.innerHTML;
}

/* ==========================================================================
   AUTH NAVIGATION
   ========================================================================== */
window.addEventListener("DOMContentLoaded", () => {
  if (window.CYVERION_THEME) window.CYVERION_THEME.init();

  const logoutLink = document.getElementById("logoutLink");
  const navLoginLink = document.getElementById("navLoginLink");
  const navRegisterLink = document.getElementById("navRegisterLink");

  if (logoutLink) {
    logoutLink.addEventListener("click", async (e) => {
      e.preventDefault();
      const token = sessionStorage.getItem("authToken");
      try {
        if (token) {
          await fetch(`${API_BASE}/api/auth/logout`, { method: "POST", headers: { "Authorization": `Bearer ${token}` } });
        }
      } catch (err) {}
      sessionStorage.clear();
      window.location.href = "login.html";
    });
  }

  if (navLoginLink) navLoginLink.style.display = "none";
  if (navRegisterLink) navRegisterLink.style.display = "none";

  const adminLink = document.getElementById("adminLink");
  const userRole = sessionStorage.getItem("userRole") || "";
  if (adminLink && userRole.toLowerCase() === "admin") {
    adminLink.style.display = "inline-block";
  }
});

/* ==========================================================================
   DOM refs
   ========================================================================== */
const staticScanForm = document.getElementById("staticScanForm");
const targetInput = document.getElementById("targetInput");
const launchBtn = document.getElementById("launchBtn");

const dropzone = document.getElementById("dropzone");
const folderInput = document.getElementById("folderInput");
const fileInput = document.getElementById("fileInput");
const pickFolderBtn = document.getElementById("pickFolderBtn");
const pickFilesBtn = document.getElementById("pickFilesBtn");
const fileCount = document.getElementById("fileCount");

let selectedFiles = [];

function updateFileCount() {
  fileCount.textContent = selectedFiles.length
    ? `${selectedFiles.length} file(s) selected`
    : "";
}

pickFolderBtn.addEventListener("click", () => folderInput.click());
pickFilesBtn.addEventListener("click", () => fileInput.click());
folderInput.addEventListener("change", () => { selectedFiles = Array.from(folderInput.files); updateFileCount(); clearFolderInvalid(); });
fileInput.addEventListener("change", () => { selectedFiles = Array.from(fileInput.files); updateFileCount(); clearFolderInvalid(); });
dropzone.addEventListener("dragover", (e) => { e.preventDefault(); dropzone.classList.add("dragover"); });
dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));
dropzone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropzone.classList.remove("dragover");
  const dropped = Array.from(e.dataTransfer.files || []);
  if (dropped.length) { selectedFiles = dropped; updateFileCount(); clearFolderInvalid(); }
});

const terminalBody = document.getElementById("terminalBody");
const jobIdLabel = document.getElementById("jobIdLabel");
const statusDot = document.getElementById("statusDot");
const statusLabel = document.getElementById("statusLabel");
const findingsList = document.getElementById("findingsList");
const severitySummary = document.getElementById("severitySummary");
const scorecardWrap = document.getElementById("scorecardWrap");

const modalBackdrop = document.getElementById("modalBackdrop");
const modalClose = document.getElementById("modalClose");
const modalSeverity = document.getElementById("modalSeverity");
const modalTitle = document.getElementById("modalTitle");
const modalMeta = document.getElementById("modalMeta");
const modalDesc = document.getElementById("modalDesc");
const modalEvidence = document.getElementById("modalEvidence");
const modalEvidenceLabel = document.getElementById("modalEvidenceLabel");
const modalFixBlock = document.getElementById("modalFixBlock");
const modalFix = document.getElementById("modalFix");
const modalRecommendation = document.getElementById("modalRecommendation");
const assistantChat = document.getElementById("assistantChat");
const assistantInput = document.getElementById("assistantInput");
const assistantForm = document.getElementById("assistantForm");
const assistantPills = document.querySelectorAll(".assistant-pill");

let currentFindings = [];
let currentFinding = null;

function normalizeTargetInput(raw) {
  if (!raw || !raw.trim()) throw new Error("Target is required.");
  if (raw.includes(" ")) throw new Error("Target must not contain spaces.");
  let value = raw.trim();
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(value)) value = `https://${value}`;
  let url;
  try {
    url = new URL(value);
  } catch {
    throw new Error("Enter a valid domain or URL.");
  }
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("Only http:// and https:// targets are allowed.");
  if (url.username || url.password) throw new Error("Credentials are not allowed in the target URL.");
  if (!url.hostname) throw new Error("Target must include a hostname.");
  return url.href;
}

function markTargetInvalid(message) {
  if (targetInput) {
    targetInput.classList.add("input-invalid");
  }
  const tip = document.getElementById("targetErrorTip");
  if (tip) {
    tip.textContent = "⚠ " + message;
    tip.classList.add("visible");
  }
}

function clearTargetInvalid() {
  if (targetInput) {
    targetInput.classList.remove("input-invalid");
  }
  const tip = document.getElementById("targetErrorTip");
  if (tip) {
    tip.textContent = "";
    tip.classList.remove("visible");
  }
}

if (targetInput) {
  targetInput.addEventListener("input", clearTargetInvalid);
}

function markFolderInvalid(message) {
  if (dropzone) dropzone.classList.add("dropzone-invalid");
  const tip = document.getElementById("folderErrorTip");
  if (tip) {
    tip.textContent = "⚠ " + message;
    tip.classList.add("visible");
  }
}

function clearFolderInvalid() {
  if (dropzone) dropzone.classList.remove("dropzone-invalid");
  const tip = document.getElementById("folderErrorTip");
  if (tip) {
    tip.textContent = "";
    tip.classList.remove("visible");
  }
}

function logLine(text, cls = "") {
  const p = document.createElement("p");
  p.className = `term-line ${cls}`;
  const ts = new Date().toLocaleTimeString();
  p.innerHTML = `<span class="term-ts">[${ts}]</span>${escapeHtml(text)}`;
  terminalBody.appendChild(p);
  terminalBody.scrollTop = terminalBody.scrollHeight;
}

function setStatus(state, label) {
  if (statusDot) statusDot.className = `status-dot ${state}`;
  if (statusLabel) statusLabel.textContent = label;
}

function setAgentState(agent, state) {
  const node = document.querySelector(`.agent-node[data-agent="${agent}"]`);
  if (!node) return;
  node.classList.remove("active", "done", "error");
  if (state) node.classList.add(state);
}

function resetAgentStates() {
  document.querySelectorAll(".agent-node").forEach(n => n.classList.remove("active", "done", "error"));
}

const SEV_ORDER = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };
const SEV_COLOR_VAR = { critical: "crimson", high: "amber", medium: "amber", low: "blue", info: "text-muted" };

function renderFindings(findings) {
  currentFindings = findings || [];

  const counts = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };
  currentFindings.forEach(f => { if (counts[f.severity] !== undefined) counts[f.severity]++; });
  severitySummary.querySelectorAll(".chip").forEach(chip => {
    chip.textContent = counts[chip.dataset.sev] ?? 0;
  });

  if (!currentFindings.length) {
    findingsList.innerHTML = `<p class="empty-state">No findings yet.</p>`;
    return;
  }

  const sorted = [...currentFindings].sort((a, b) => (SEV_ORDER[a.severity] ?? 9) - (SEV_ORDER[b.severity] ?? 9));
  findingsList.innerHTML = "";
  sorted.forEach((f) => {
    const card = document.createElement("div");
    card.className = `finding-card sev-${f.severity}`;
    card.innerHTML = `
      <div class="finding-card-top">
        <span class="finding-sev-tag" style="color:var(--${SEV_COLOR_VAR[f.severity] || "text-muted"})">${escapeHtml(f.severity)}</span>
        <span class="finding-card-agent">${escapeHtml(f.source_agent || f.agent || "")}</span>
      </div>
      <div class="finding-card-title">${escapeHtml(f.title)}</div>
      <div class="finding-card-sub">${escapeHtml(f.file_path || "")}:${f.line || ""}</div>
    `;
    card.addEventListener("click", () => openModal(f));
    findingsList.appendChild(card);
  });
}

function renderAssistantMessage(text, who = "bot") {
  if (!assistantChat) return;
  const bubble = document.createElement("div");
  bubble.className = `assistant-bubble ${who === "user" ? "assistant-bubble-user" : "assistant-bubble-bot"}`;
  bubble.textContent = text;
  assistantChat.appendChild(bubble);
  assistantChat.scrollTop = assistantChat.scrollHeight;
}

function buildAssistantReply(prompt, finding) {
  const text = (prompt || "").toLowerCase();
  const title = finding?.title || "this vulnerability";
  const cwe = finding?.cwe || "";

  if (text.includes("secure") || text.includes("fix") || text.includes("patch") || text.includes("code")) {
    return `Suggested secure fix: use dynamic bind parameters, avoid string interpolation on queries, apply strict regex validations, and reference OWASP Top 10 recommendations. Secure fix recommendation is listed in the details modal above under "Suggested Fix".`;
  }
  return `Vulnerability details: ${title} ${cwe ? "classified under " + cwe : ""}. Review the recommendations section and evidence snippet to formulate compensating controls.`;
}

function openModal(f) {
  currentFinding = f;
  modalSeverity.textContent = (f.severity || "").toUpperCase();
  modalSeverity.style.color = `var(--${SEV_COLOR_VAR[f.severity] || "text-muted"})`;
  modalSeverity.style.borderColor = `var(--${SEV_COLOR_VAR[f.severity] || "text-muted"})`;
  modalTitle.textContent = f.title;

  modalMeta.textContent = `${f.source_agent || f.agent || ""} — ${f.file_path || ""}:${f.line || ""} — ${f.cwe || "n/a"}`;
  modalDesc.textContent = f.description || "";
  modalRecommendation.textContent = f.recommendation || "No recommendation guidelines specified.";

  modalEvidenceLabel.textContent = "Vulnerable Snippet / Offending Line";
  modalEvidence.textContent = f.evidence || "(no snippet captured)";
  
  if (f.recommendation) {
    modalFix.textContent = f.recommendation;
    modalFixBlock.hidden = false;
  } else {
    modalFixBlock.hidden = true;
  }

  if (assistantChat) {
    assistantChat.innerHTML = "";
    renderAssistantMessage("Ask me to explain the risk, suggest a secure patch, or help you understand this vulnerability.", "bot");
  }

  modalBackdrop.classList.add("open");
}

if (assistantForm) {
  assistantForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const prompt = assistantInput.value.trim();
    if (!prompt) return;
    renderAssistantMessage(prompt, "user");
    assistantInput.value = "";
    const reply = buildAssistantReply(prompt, currentFinding);
    renderAssistantMessage(reply, "bot");
  });
}

assistantPills.forEach((pill) => {
  pill.addEventListener("click", () => {
    if (!assistantInput) return;
    assistantInput.value = pill.dataset.prompt || "";
    assistantInput.focus();
  });
});

modalClose.addEventListener("click", () => modalBackdrop.classList.remove("open"));
modalBackdrop.addEventListener("click", (e) => { if (e.target === modalBackdrop) modalBackdrop.classList.remove("open"); });

function renderScorecard(report) {
  const findings = report.findings || [];
  const counts = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };
  findings.forEach(f => { if (counts[f.severity] !== undefined) counts[f.severity]++; });
  
  let score = 100;
  score -= counts.critical * 25;
  score -= counts.high * 12;
  score -= counts.medium * 5;
  score -= counts.low * 2;
  score = Math.max(0, Math.min(100, score));
  
  let rating = "Good";
  let ratingClass = "score-good";
  if (score < 55) { rating = "At Risk"; ratingClass = "score-bad"; }
  else if (score < 80) { rating = "Needs Attention"; ratingClass = "score-warn"; }

  scorecardWrap.hidden = false;
  scorecardWrap.innerHTML = `
    <div class="scorecard">
      <div class="scorecard-main ${ratingClass}">
        <div class="scorecard-number">${score}</div>
        <div class="scorecard-label">/ 100 — ${rating}</div>
      </div>
      <div class="scorecard-grid">
        <div class="scorecard-item sev-critical-text"><span class="sc-num">${counts.critical}</span><span class="sc-label">Critical</span></div>
        <div class="scorecard-item sev-high-text"><span class="sc-num">${counts.high}</span><span class="sc-label">High</span></div>
        <div class="scorecard-item"><span class="sc-num">${counts.medium}</span><span class="sc-label">Medium</span></div>
        <div class="scorecard-item"><span class="sc-num">${counts.low}</span><span class="sc-label">Low</span></div>
        <div class="scorecard-item"><span class="sc-num">${findings.length}</span><span class="sc-label">Total Findings</span></div>
        <div class="scorecard-item"><span class="sc-num">${report.files_scanned || 0}</span><span class="sc-label">Files Scanned</span></div>
      </div>
    </div>`;
}

staticScanForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const rawTarget = targetInput.value.trim();

  let normalizedTarget = null;
  if (rawTarget) {
    try {
      normalizedTarget = normalizeTargetInput(rawTarget);
    } catch (err) {
      logLine(`Invalid target: ${err.message}`, "term-warn");
      return;
    }
  }

  if (!normalizedTarget && !selectedFiles.length) {
    logLine("Provide a target URL and/or upload project files to scan.", "term-warn");
    return;
  }

  if (selectedFiles.length !== 0) {
    const sourceFiles = selectedFiles.filter(f => f.size > 0);
    if (sourceFiles.length === 0) {
      markFolderInvalid("The selected folder is empty. Please choose a non-empty folder.");
      logLine("Empty folder detected — scan aborted.", "term-err");
      return;
    }
  }

  launchBtn.disabled = true;
  terminalBody.innerHTML = "";
  scorecardWrap.hidden = true;
  renderFindings([]);
  resetAgentStates();
  setStatus("running", "Static analysis running...");
  logLine("Preparing Static SAST scan...", "term-muted");

  const formData = new FormData();
  if (normalizedTarget) formData.append("url", normalizedTarget);
  selectedFiles.forEach(f => {
    const name = f.webkitRelativePath || f.name;
    formData.append("files", f, name);
  });

  try {
    const res = await fetch(`${API_BASE}/api/scan`, {
      method: "POST",
      body: formData,
      headers: authHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Server responded ${res.status}`);
    }
    const data = await res.json();
    jobIdLabel.textContent = `job ${data.job_id}`;
    logLine(`Job ${data.job_id} created. Streaming pipeline activity...`, "term-ok");
    streamJob(data.job_id);
  } catch (err) {
    logLine(`Failed to start scan: ${err.message}.`, "term-err");
    setStatus("error", "Failed to start");
    launchBtn.disabled = false;
  }
});

function streamJob(jobId) {
  const esUrl = `${API_BASE}/api/stream/${jobId}`;
  let es = null;
  let reconnectAttempts = 0;

  function connect() {
    es = new EventSource(esUrl);
    es.onmessage = onMessage;
    es.onerror = onError;
  }

  function onMessage(event) {
    reconnectAttempts = 0;
    const payload = JSON.parse(event.data);

    if (payload.done) {
      logLine(`Static scan pipeline finished (${payload.status}).`, payload.status === "error" ? "term-err" : "term-ok");
      setStatus(payload.status === "error" ? "error" : "done", payload.status === "error" ? "Pipeline error" : "Scan complete");
      launchBtn.disabled = false;
      if (es) es.close();
      loadReport(jobId);
      return;
    }

    const cls = payload.status === "error" ? "term-err"
      : payload.status === "completed" ? "term-ok"
      : payload.status === "started" ? "term-agent" : "term-muted";
    logLine(`[${payload.agent}] ${payload.message}`, cls);

    if (payload.status === "started") setAgentState(payload.agent, "active");
    if (payload.status === "completed") setAgentState(payload.agent, "done");
    if (payload.status === "error") setAgentState(payload.agent, "error");
  }

  function onError() {
    if (es) try { es.close(); } catch (e) {}
    reconnectAttempts += 1;
    const wait = Math.min(30000, 500 * Math.pow(2, reconnectAttempts));
    logLine(`Connection lost. Reconnecting in ${Math.round(wait / 1000)}s...`, "term-warn");
    setTimeout(connect, wait);
  }

  connect();
}

async function loadReport(jobId) {
  try {
    const res = await fetch(`${API_BASE}/api/report/${jobId}`, {
      headers: authHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Server responded ${res.status}`);
    }
    const data = await res.json();
    renderFindings(data.findings || []);
    renderScorecard(data);
  } catch (err) {
    logLine(`Could not load report: ${err.message}`, "term-err");
  }
}
