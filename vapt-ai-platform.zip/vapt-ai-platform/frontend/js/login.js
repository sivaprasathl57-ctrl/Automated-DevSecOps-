/* ==========================================
      CYVERION – RED & BLACK LOGIN JS
      Particles + 3D Tilt + GSAP + Auth
========================================== */

// ==========================================
// API & SESSION
// ==========================================

const API_BASE = "";
if (sessionStorage.getItem("loggedIn") === "true") {
    window.location.href = getPageForRole(sessionStorage.getItem("userRole"));
}

// ==========================================
// RED PARTICLE SYSTEM
// ==========================================

(function initParticles() {
    const container = document.getElementById("particles");
    if (!container) return;

    const COUNT = 70;

    for (let i = 0; i < COUNT; i++) {
        const p    = document.createElement("span");
        const size = Math.random() * 3 + 1;
        const isEmber = Math.random() > 0.7;

        p.style.cssText = `
            position: absolute;
            width: ${size}px;
            height: ${size}px;
            border-radius: 50%;
            background: ${isEmber ? '#FF6D00' : '#FF1744'};
            opacity: ${Math.random() * 0.55 + 0.10};
            left: ${Math.random() * 100}vw;
            top: ${window.innerHeight + 20}px;
            box-shadow: 0 0 ${size * 4}px ${isEmber ? '#FF6D00' : '#FF1744'},
                        0 0 ${size * 8}px ${isEmber ? 'rgba(255,109,0,0.3)' : 'rgba(255,23,68,0.25)'};
            pointer-events: none;
        `;

        container.appendChild(p);
        floatUp(p);
    }

    function floatUp(el) {
        const duration = Math.random() * 13 + 9;
        const xDrift   = (Math.random() - 0.5) * 180;

        function run() {
            let start     = null;
            const startY  = parseFloat(el.style.top) || window.innerHeight;
            const endY    = -100;

            (function step(ts) {
                if (!start) start = ts;
                const progress = (ts - start) / (duration * 1000);
                if (progress >= 1) {
                    el.style.top  = window.innerHeight + Math.random() * 200 + 'px';
                    el.style.left = Math.random() * window.innerWidth + 'px';
                    el.style.opacity = Math.random() * 0.55 + 0.10;
                    setTimeout(run, Math.random() * 3000);
                    return;
                }
                el.style.top  = startY + (endY - startY) * progress + 'px';
                el.style.left = parseFloat(el.style.left) + xDrift * 0.0001 + 'px';
                el.style.opacity = (Math.random() * 0.55 + 0.10) * (1 - progress * 0.5);
                requestAnimationFrame(step);
            })(performance.now());
        }

        setTimeout(run, Math.random() * 5000);
    }
})();

// ==========================================
// GSAP ENTRANCE ANIMATIONS
// ==========================================

if (typeof gsap !== "undefined") {
    gsap.from("header", {
        y: -80,
        opacity: 0,
        duration: 1,
        ease: "power3.out"
    });

    gsap.from(".left-panel h4", {
        x: -60,
        opacity: 0,
        duration: 0.9,
        delay: 0.3,
        ease: "power2.out"
    });

    gsap.from(".left-panel h1", {
        x: -100,
        opacity: 0,
        duration: 1.1,
        delay: 0.5,
        ease: "power3.out"
    });

    gsap.from(".left-panel p", {
        x: -70,
        opacity: 0,
        duration: 0.9,
        delay: 0.7,
        ease: "power2.out"
    });

    gsap.from(".features div", {
        y: 40,
        opacity: 0,
        duration: 0.6,
        stagger: 0.1,
        delay: 0.9,
        ease: "power2.out"
    });

    // LOGIN CARD KEPT STATIC — no entrance or 3D tilt
}

// ==========================================
// PASSWORD SHOW / HIDE
// ==========================================

const password = document.getElementById("password");
const toggle   = document.getElementById("togglePassword");

if (toggle && password) {
    toggle.addEventListener("click", () => {
        if (password.type === "password") {
            password.type = "text";
            toggle.classList.remove("fa-eye");
            toggle.classList.add("fa-eye-slash");
        } else {
            password.type = "password";
            toggle.classList.remove("fa-eye-slash");
            toggle.classList.add("fa-eye");
        }
    });
}

// ==========================================
// INPUT FOCUS GLOW EFFECT
// ==========================================

document.querySelectorAll(".input-box input").forEach(input => {
    input.addEventListener("focus", () => {
        input.closest(".input-box").style.filter =
            "drop-shadow(0 0 12px rgba(255,23,68,0.30))";
    });
    input.addEventListener("blur", () => {
        input.closest(".input-box").style.filter = "none";
    });
});

// ==========================================
// NAVBAR SCROLL EFFECT
// ==========================================

window.addEventListener("scroll", () => {
    const header = document.querySelector("header");
    if (!header) return;

    if (window.scrollY > 30) {
        header.style.background   = "rgba(6,6,6,0.92)";
        header.style.borderBottom = "1px solid rgba(255,23,68,0.25)";
        header.style.boxShadow    = "0 10px 40px rgba(255,23,68,0.10)";
    } else {
        header.style.background   = "rgba(6,6,6,0.55)";
        header.style.borderBottom = "1px solid rgba(255,23,68,0.14)";
        header.style.boxShadow    = "none";
    }
});

// ==========================================
// LOGIN FORM SUBMIT — AUTHENTICATE
// ==========================================

const loginForm = document.querySelector("form");

if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const emailInput    = document.querySelector('input[type="email"]');
        const passwordInput = document.getElementById("password");
        const btn           = document.querySelector(".login-btn");

        const enteredEmail = emailInput.value.trim();
        const enteredPassword = passwordInput.value;

        btn.disabled  = true;
        btn.innerHTML = "⏳ VERIFYING...";

        // Temporary hardcoded login bypass
        if (enteredEmail === "siva@gmail.com" && enteredPassword === "1234") {
            const localLogin = () => {
                sessionStorage.setItem("loggedIn",   "true");
                sessionStorage.setItem("userEmail",  "siva@gmail.com");
                sessionStorage.setItem("userName",   "Siva");
                sessionStorage.setItem("userRole",   "admin");
                // Dummy JWT payload signed with sub=42
                const dummyToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjQyLCJlbWFpbCI6InNpdmFAZ21haWwuY29tIiwiZXhwIjoyOTE0ODg5NjAwfQ.dummy_signature";
                sessionStorage.setItem("authToken",  dummyToken);

                btn.innerHTML = "✔ ACCESS GRANTED";
                btn.style.background = "linear-gradient(135deg,#00FF84,#00CC66)";

                setTimeout(() => { window.location.href = getPageForRole("admin"); }, 900);
            };

            const formData = new FormData();
            formData.append("email",    enteredEmail);
            formData.append("password", enteredPassword);

            try {
                const res  = await fetch(`${API_BASE}/api/auth/login`, { method: "POST", body: formData });
                const data = await res.json();
                if (res.ok && data.success) {
                    sessionStorage.setItem("loggedIn",   "true");
                    sessionStorage.setItem("userEmail",  data.user.email);
                    sessionStorage.setItem("userName",   data.user.first_name);
                    sessionStorage.setItem("userRole",   data.user.role || "");
                    sessionStorage.setItem("authToken",  data.token);

                    btn.innerHTML = "✔ ACCESS GRANTED";
                    btn.style.background = "linear-gradient(135deg,#00FF84,#00CC66)";

                    setTimeout(() => { window.location.href = getPageForRole(data.user.role); }, 900);
                } else {
                    localLogin();
                }
            } catch (err) {
                // If backend is down, fall back to offline login directly
                localLogin();
            }
            return;
        }

        const formData = new FormData();
        formData.append("email",    enteredEmail);
        formData.append("password", enteredPassword);

        try {
            const res  = await fetch(`${API_BASE}/api/auth/login`, { method: "POST", body: formData });
            const data = await res.json();

            if (res.ok && data.success) {
                sessionStorage.setItem("loggedIn",   "true");
                sessionStorage.setItem("userEmail",  data.user.email);
                sessionStorage.setItem("userName",   data.user.first_name);
                sessionStorage.setItem("userRole",   data.user.role || "");
                sessionStorage.setItem("authToken",  data.token);

                btn.innerHTML = "✔ ACCESS GRANTED";
                btn.style.background = "linear-gradient(135deg,#00FF84,#00CC66)";

                setTimeout(() => { window.location.href = getPageForRole(data.user.role); }, 900);
            } else {
                const errMsg = data.detail || "Invalid email or password";
                alert(`❌ Login Failed: ${errMsg}`);
                btn.innerHTML = "LOGIN";
                btn.style.background = "";
                btn.disabled = false;
            }
        } catch (err) {
            alert(`❌ Network error: ${err.message}. Is the backend running?`);
            btn.innerHTML = "LOGIN";
            btn.style.background = "";
            btn.disabled = false;
        }
    });
}

// ==========================================
// GOOGLE SIGN-IN FLOW (REAL & MOCK)
// ==========================================

let googleClientId = "";
let googleEnabled = false;
let tokenClient = null;

async function checkGoogleConfig() {
    try {
        const res = await fetch(`${API_BASE}/api/auth/google/config`);
        if (res.ok) {
            const data = await res.json();
            googleClientId = data.client_id;
            googleEnabled = !!data.enabled;
            
            if (googleEnabled && typeof google !== 'undefined') {
                initGoogleOAuth();
            }
        }
    } catch (e) {
        console.warn("Failed to check Google OAuth configuration:", e);
    }
}

function initGoogleOAuth() {
    try {
        tokenClient = google.accounts.oauth2.initTokenClient({
            client_id: googleClientId,
            scope: 'email profile openid',
            callback: async (tokenResponse) => {
                if (tokenResponse && tokenResponse.access_token) {
                    await handleGoogleLogin({ token: tokenResponse.access_token });
                }
            },
        });
    } catch (e) {
        console.error("Failed to initialize Google Identity Services Token Client:", e);
    }
}

const googleBtn = document.querySelector(".google-btn");
if (googleBtn) {
    googleBtn.addEventListener("click", () => {
        if (googleEnabled && tokenClient) {
            tokenClient.requestAccessToken();
        } else {
            showMockGoogleModal();
        }
    });
}

async function handleGoogleLogin(payload) {
    const btn = document.querySelector(".google-btn");
    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = "⏳ SIGNING IN...";
    
    try {
        const res = await fetch(`${API_BASE}/api/auth/google`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (res.ok && data.success) {
            sessionStorage.setItem("loggedIn", "true");
            sessionStorage.setItem("userEmail", data.user.email);
            sessionStorage.setItem("userName", data.user.first_name);
            sessionStorage.setItem("userRole", data.user.role || "student");
            sessionStorage.setItem("authToken", data.token);
            
            btn.innerHTML = "✔ ACCESS GRANTED";
            btn.style.background = "linear-gradient(135deg,#00FF84,#00CC66)";
            
            setTimeout(() => {
                window.location.href = getPageForRole(data.user.role);
            }, 900);
        } else {
            const msg = data.detail || "Google login verification failed";
            alert(`❌ Sign-in Failed: ${msg}`);
            btn.disabled = false;
            btn.innerHTML = originalHtml;
            btn.style.background = "";
        }
    } catch (err) {
        alert(`❌ Connection error: ${err.message}`);
        btn.disabled = false;
        btn.innerHTML = originalHtml;
        btn.style.background = "";
    }
}

const mockModal = document.getElementById("mockGoogleModal");
const closeMockBtn = document.getElementById("closeMockGoogleBtn");
const mockCustomBtn = document.getElementById("mockCustomGoogleBtn");

function showMockGoogleModal() {
    if (mockModal) {
        mockModal.style.display = "flex";
        setTimeout(() => mockModal.classList.add("active"), 10);
    }
}

function hideMockGoogleModal() {
    if (mockModal) {
        mockModal.classList.remove("active");
        setTimeout(() => mockModal.style.display = "none", 300);
    }
}

if (closeMockBtn) {
    closeMockBtn.addEventListener("click", hideMockGoogleModal);
}

if (mockModal) {
    mockModal.addEventListener("click", (e) => {
        if (e.target === mockModal) hideMockGoogleModal();
    });
}

document.querySelectorAll(".mock-account-item").forEach(item => {
    item.addEventListener("click", async () => {
        const email = item.dataset.email;
        const role = item.dataset.role;
        const name = item.dataset.name;
        const parts = name.split(" ");
        const firstName = parts[0] || "Google";
        const lastName = parts[1] || "User";
        
        hideMockGoogleModal();
        
        await handleGoogleLogin({
            is_mock: true,
            email: email,
            role: role,
            first_name: firstName,
            last_name: lastName
        });
    });
});

if (mockCustomBtn) {
    mockCustomBtn.addEventListener("click", async () => {
        const email = prompt("Enter custom test email:", "test@example.com");
        if (!email) return;
        const name = prompt("Enter user name:", "Test User");
        if (!name) return;
        const role = prompt("Enter role (Student, Developer, Security Analyst, Penetration Tester, Administrator):", "Student");
        if (!role) return;
        
        const parts = name.split(" ");
        const firstName = parts[0] || "Google";
        const lastName = parts[1] || "User";
        
        hideMockGoogleModal();
        
        await handleGoogleLogin({
            is_mock: true,
            email: email,
            role: role,
            first_name: firstName,
            last_name: lastName
        });
    });
}

checkGoogleConfig();

console.log(
    "%cCYVERION Login — Red & Black 🔴",
    "color:#FF1744;font-size:16px;font-weight:800;"
);
