const API_BASE = "";
const AUTH_TOKEN = sessionStorage.getItem("authToken");
const LOGGED_IN = sessionStorage.getItem("loggedIn") === "true" && AUTH_TOKEN;
if (!LOGGED_IN) {
  window.location.href = "login.html";
}

function authHeaders() {
  return AUTH_TOKEN ? { Authorization: `Bearer ${AUTH_TOKEN}` } : {};
}

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str == null ? "" : String(str);
  return d.innerHTML;
}

function formatDateTime(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.valueOf())) return String(value);
  return date.toLocaleString();
}

function renderHistoryTable(items) {
  if (!items || !items.length) {
    return `<p class="section-note">No recon history available yet.</p>`;
  }
  return `<div class="history-list">${items.map(item => {
    const statusClass = item.status === "completed" ? "history-ok" : item.status === "error" ? "history-err" : "history-pending";
    return `<button type="button" class="history-entry ${statusClass}" data-job-id="${escapeHtml(item.job_id)}">
      <div class="history-entry-main">
        <div class="history-entry-title">${escapeHtml(item.target)}</div>
        <div class="history-entry-meta">${escapeHtml(item.company_name || "—")} • ${formatDateTime(item.created_at)}</div>
      </div>
      <div class="history-entry-status">${escapeHtml(item.status)}</div>
    </button>`;
  }).join("")}</div>`;
}

async function loadHistory() {
  const historyList = document.getElementById("historyList");
  if (!historyList) return;
  historyList.innerHTML = `<p class="section-note">Loading your recon history...</p>`;
  try {
    const res = await fetch(`${API_BASE}/api/recon/history`, {
      headers: authHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Server responded ${res.status}`);
    }
    const data = await res.json();
    historyList.innerHTML = renderHistoryTable(data.history);
    historyList.querySelectorAll(".history-entry").forEach(btn => {
      btn.addEventListener("click", () => {
        const jobId = btn.getAttribute("data-job-id");
        loadReport(jobId);
      });
    });
  } catch (err) {
    historyList.innerHTML = `<p class="section-note">Could not load history: ${escapeHtml(err.message)}</p>`;
  }
}

/* ==========================================================================
   AUTH NAVIGATION
   ========================================================================== */
window.addEventListener("DOMContentLoaded", () => {
  if (window.CYVERION_THEME) window.CYVERION_THEME.init();

  const logoutLink = document.getElementById("logoutLink");
  const navLoginLink = document.getElementById("navLoginLink");
  const navRegisterLink = document.getElementById("navRegisterLink");

  if (logoutLink) {
    logoutLink.addEventListener("click", async (e) => {
      e.preventDefault();
      const token = sessionStorage.getItem("authToken");
      try {
        if (token) {
          await fetch(`${API_BASE}/api/auth/logout`, { method: "POST", headers: { "Authorization": `Bearer ${token}` } });
        }
      } catch (err) {}
      sessionStorage.clear();
      window.location.href = "login.html";
    });
  }

  if (navLoginLink) navLoginLink.style.display = "none";
  if (navRegisterLink) navRegisterLink.style.display = "none";

  const adminLink = document.getElementById("adminLink");
  const userRole = sessionStorage.getItem("userRole") || "";
  if (adminLink && userRole.toLowerCase() === "admin") {
    adminLink.style.display = "inline-block";
  }

  loadHistory();
});

/* ==========================================================================
   3D Cyber Background - Three.js Particle Network
   ========================================================================== */
(function init3DBackground() {
  const canvas = document.getElementById('bg-canvas');
  if (!canvas || typeof THREE === 'undefined') return;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  const renderer = new THREE.WebGLRenderer({
    canvas: canvas,
    alpha: true,
    antialias: true
  });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  const particlesGeometry = new THREE.BufferGeometry();
  const particlesCount = 1800;
  const posArray = new Float32Array(particlesCount * 3);
  for (let i = 0; i < particlesCount * 3; i++) {
    posArray[i] = (Math.random() - 0.5) * 12;
  }
  particlesGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));

  const particlesMaterial = new THREE.PointsMaterial({
    size: 0.015,
    color: 0xFF1744,
    transparent: true,
    opacity: 0.4,
    blending: THREE.AdditiveBlending,
  });
  const particlesMesh = new THREE.Points(particlesGeometry, particlesMaterial);
  scene.add(particlesMesh);

  const linePositions = [];
  const positions = particlesGeometry.attributes.position.array;
  for (let i = 0; i < particlesCount; i++) {
    for (let j = i + 1; j < particlesCount; j++) {
      const dx = positions[i * 3] - positions[j * 3];
      const dy = positions[i * 3 + 1] - positions[j * 3 + 1];
      const dz = positions[i * 3 + 2] - positions[j * 3 + 2];
      const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (dist < 0.8) {
        linePositions.push(positions[i * 3], positions[i * 3 + 1], positions[i * 3 + 2]);
        linePositions.push(positions[j * 3], positions[j * 3 + 1], positions[j * 3 + 2]);
      }
    }
  }
  const linesGeometry = new THREE.BufferGeometry();
  linesGeometry.setAttribute('position', new THREE.Float32BufferAttribute(linePositions, 3));
  const linesMaterial = new THREE.LineBasicMaterial({
    color: 0xFF1744,
    transparent: true,
    opacity: 0.06,
  });
  const linesMesh = new THREE.LineSegments(linesGeometry, linesMaterial);
  scene.add(linesMesh);

  const torusGeo = new THREE.TorusKnotGeometry(0.3, 0.1, 64, 8);
  const torusMat = new THREE.MeshBasicMaterial({
    color: 0xFF6D00,
    wireframe: true,
    transparent: true,
    opacity: 0.08,
  });
  const torus = new THREE.Mesh(torusGeo, torusMat);
  torus.position.set(1.5, -0.5, -2);
  scene.add(torus);

  const torus2 = new THREE.Mesh(
    new THREE.TorusKnotGeometry(0.2, 0.07, 48, 6),
    new THREE.MeshBasicMaterial({ color: 0xFF1744, wireframe: true, transparent: true, opacity: 0.06 })
  );
  torus2.position.set(-1.8, 1.2, -1.5);
  scene.add(torus2);

  camera.position.z = 4;

  let mouseX = 0;
  let mouseY = 0;
  document.addEventListener('mousemove', (e) => {
    mouseX = (e.clientX / window.innerWidth - 0.5) * 0.3;
    mouseY = (e.clientY / window.innerHeight - 0.5) * 0.3;
  });

  function animate() {
    requestAnimationFrame(animate);
    particlesMesh.rotation.x += 0.0003;
    particlesMesh.rotation.y += 0.0005;
    linesMesh.rotation.x = particlesMesh.rotation.x;
    linesMesh.rotation.y = particlesMesh.rotation.y;
    torus.rotation.x += 0.005;
    torus.rotation.y += 0.008;
    torus2.rotation.x -= 0.004;
    torus2.rotation.z += 0.006;
    camera.position.x += (mouseX - camera.position.x) * 0.02;
    camera.position.y += (mouseY - camera.position.y) * 0.02;
    camera.lookAt(scene.position);
    renderer.render(scene, camera);
  }
  animate();

  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });
})();

/* ==========================================================================
   Recon Application Logic
   ========================================================================== */
const reconForm = document.getElementById("reconForm");
const targetInput = document.getElementById("targetInput");
const companyInput = document.getElementById("companyInput");
const aggressiveCheck = document.getElementById("aggressiveCheck");
const osintCheck = document.getElementById("osintCheck");
const authorizedCheck = document.getElementById("authorizedCheck");
const launchBtn = document.getElementById("launchBtn");

const terminalBody = document.getElementById("terminalBody");
const jobIdLabel = document.getElementById("jobIdLabel");
const statusDot = document.getElementById("statusDot");
const statusLabel = document.getElementById("statusLabel");
const reportBody = document.getElementById("reportBody");
const reportPanel = document.getElementById("reportPanel");
const reportActions = document.getElementById("reportActions");
const expandAllBtn = document.getElementById("expandAllBtn");
const collapseAllBtn = document.getElementById("collapseAllBtn");

let currentJobId = null;
let currentAssessment = {
  likelihood: null,
  impact: null,
  notes: "",
  stride_scenarios: [],
  status: "Draft",
  override_score: false,
  custom_score: 100,
  override_justification: ""
};

function normalizeTargetInput(raw) {
  if (!raw || !raw.trim()) {
    throw new Error("Target is required.");
  }
  if (raw.includes(" ")) {
    throw new Error("Target must not contain spaces.");
  }
  let value = raw.trim();
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(value)) {
    value = `https://${value}`;
  }
  let url;
  try {
    url = new URL(value);
  } catch {
    throw new Error("Enter a valid domain or URL.");
  }
  if (!["http:", "https:"].includes(url.protocol)) {
    throw new Error("Only http:// and https:// targets are allowed.");
  }
  if (url.username || url.password) {
    throw new Error("Credentials are not allowed in the target URL.");
  }
  if (!url.hostname) {
    throw new Error("Target must include a hostname.");
  }
  if (url.hostname.endsWith(".") || url.hostname.startsWith("-") || url.hostname.endsWith("-")) {
    throw new Error("Target hostname is not valid.");
  }
  return url.href;
}

expandAllBtn.addEventListener("click", () => {
  document.querySelectorAll(".report-section").forEach(s => s.classList.add("open"));
});
collapseAllBtn.addEventListener("click", () => {
  document.querySelectorAll(".report-section").forEach(s => s.classList.remove("open"));
});

async function checkTargetReachability(url) {
  const apiBase = window.API_BASE || API_BASE || "";
  try {
    const formData = new FormData();
    formData.append("target", url);
    const res = await fetch(`${apiBase}/api/validate/target`, {
      method: "POST",
      body: formData,
      headers: authHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      return { reachable: false, reason: err.detail || "Validation service returned an error." };
    }
    const data = await res.json();
    if (data.valid) {
      return { reachable: true, statusCode: data.status_code };
    }
    return { reachable: false, reason: data.reason || "This link appears invalid/fake." };
  } catch (err) {
    return {
      reachable: false,
      reason: "Could not reach the validation service. Is the backend running (uvicorn main:app)?",
    };
  }
}

function markTargetInvalid(message) {
  if (targetInput) {
    targetInput.classList.add("input-invalid");
    targetInput.setAttribute("data-error", message);
  }
  const tip = document.getElementById("targetErrorTip");
  if (tip) {
    tip.textContent = "⚠ " + message;
    tip.classList.add("visible");
  }
}

function clearTargetInvalid() {
  if (targetInput) {
    targetInput.classList.remove("input-invalid");
    targetInput.removeAttribute("data-error");
  }
  const tip = document.getElementById("targetErrorTip");
  if (tip) {
    tip.textContent = "";
    tip.classList.remove("visible");
  }
}

if (targetInput) {
  targetInput.addEventListener("input", clearTargetInvalid);
}

function logLine(text, cls = "") {
  const p = document.createElement("p");
  p.className = `term-line ${cls}`;
  const ts = new Date().toLocaleTimeString();
  p.innerHTML = `<span class="term-ts">[${ts}]</span>${escapeHtml(text)}`;
  terminalBody.appendChild(p);
  terminalBody.scrollTop = terminalBody.scrollHeight;
}

function setStatus(state, label) {
  if (statusDot) statusDot.className = `status-dot ${state}`;
  if (statusLabel) statusLabel.textContent = label;
}

function setAgentState(agent, state) {
  const node = document.querySelector(`.agent-node[data-agent="${agent}"]`);
  if (!node) return;
  node.classList.remove("active", "done", "error");
  if (state) node.classList.add(state);
}

function resetAgentStates() {
  document.querySelectorAll(".agent-node").forEach(n => n.classList.remove("active", "done", "error"));
}

reconForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const rawTarget = targetInput.value.trim();
  let normalizedTarget;
  try {
    normalizedTarget = normalizeTargetInput(rawTarget);
  } catch (err) {
    logLine(`Invalid target: ${err.message}`, "term-warn");
    return;
  }
  if (!authorizedCheck.checked) {
    logLine("You must confirm authorization before scanning a target.", "term-warn");
    return;
  }

  logLine("Checking target link reachability...", "term-muted");
  const linkCheck = await checkTargetReachability(normalizedTarget);
  if (!linkCheck.reachable) {
    markTargetInvalid(linkCheck.reason);
    logLine(`Invalid target: ${linkCheck.reason}. Scan not started.`, "term-err");
    return;
  }
  clearTargetInvalid();
  logLine(`Target link verified — host is reachable (${linkCheck.statusCode || "OK"}).`, "term-ok");

  launchBtn.disabled = true;
  terminalBody.innerHTML = "";
  reportBody.innerHTML = `<p class="empty-state">Scan running — report sections populate as each agent completes.</p>`;
  resetAgentStates();
  setStatus("running", "Recon pipeline running...");
  logLine("Preparing recon job...", "term-muted");

  const formData = new FormData();
  formData.append("target", normalizedTarget);
  formData.append("company_name", companyInput.value.trim());
  formData.append("aggressive", aggressiveCheck.checked ? "true" : "false");
  formData.append("run_osint", osintCheck.checked ? "true" : "false");
  formData.append("authorized", "true");

  try {
    const res = await fetch(`${API_BASE}/api/recon/start`, {
      method: "POST",
      body: formData,
      headers: authHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Server responded ${res.status}`);
    }
    const data = await res.json();
    jobIdLabel.textContent = `job ${data.job_id}`;
    logLine(`Job ${data.job_id} created. Streaming agent activity...`, "term-ok");
    streamJob(data.job_id);
  } catch (err) {
    logLine(`Failed to start recon: ${err.message}.`, "term-err");
    setStatus("error", "Failed to start");
    launchBtn.disabled = false;
  }
});

function streamJob(jobId) {
  const token = encodeURIComponent(AUTH_TOKEN || "");
  const esUrl = `${API_BASE}/api/recon/stream/${jobId}?token=${token}`;
  let es = null;
  let reconnectAttempts = 0;

  function connect() {
    es = new EventSource(esUrl);
    es.onmessage = onMessage;
    es.onerror = onError;
  }

  function onMessage(event) {
    reconnectAttempts = 0;
    const payload = JSON.parse(event.data);

    if (payload.done) {
      logLine(`Recon pipeline finished (${payload.status}).`, payload.status === "error" ? "term-err" : "term-ok");
      setStatus(payload.status === "error" ? "error" : "done", payload.status === "error" ? "Pipeline error" : "Recon complete");
      launchBtn.disabled = false;
      if (es) es.close();
      loadHistory();
      loadReport(jobId);
      return;
    }

    const cls = payload.status === "error" ? "term-err"
      : payload.status === "completed" ? "term-ok"
      : payload.status === "started" ? "term-agent" : "term-muted";
    logLine(`[${payload.agent}] ${payload.message}`, cls);

    if (payload.status === "started") setAgentState(payload.agent, "active");
    if (payload.status === "completed") setAgentState(payload.agent, "done");
    if (payload.status === "error") setAgentState(payload.agent, "error");
  }

  function onError() {
    if (es) try { es.close(); } catch (e) {}
    reconnectAttempts += 1;
    const wait = Math.min(30000, 500 * Math.pow(2, reconnectAttempts));
    logLine(`Connection lost. Reconnecting in ${Math.round(wait/1000)}s...`, "term-warn");
    setTimeout(connect, wait);
  }

  connect();
}

async function loadReport(jobId) {
  try {
    currentJobId = jobId;
    const res = await fetch(`${API_BASE}/api/recon/report/${jobId}`, {
      headers: authHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Server responded ${res.status}`);
    }
    const data = await res.json();
    
    const reportData = data.report || {};
    if (reportData.analyst_assessment) {
      currentAssessment = {
        likelihood: reportData.analyst_assessment.likelihood ?? null,
        impact: reportData.analyst_assessment.impact ?? null,
        notes: reportData.analyst_assessment.notes ?? "",
        stride_scenarios: reportData.analyst_assessment.stride_scenarios ?? [],
        status: reportData.analyst_assessment.status ?? "Draft",
        override_score: reportData.analyst_assessment.override_score ?? false,
        custom_score: reportData.analyst_assessment.custom_score ?? 100,
        override_justification: reportData.analyst_assessment.override_justification ?? ""
      };
    } else {
      currentAssessment = {
        likelihood: null,
        impact: null,
        notes: "",
        stride_scenarios: [],
        status: "Draft",
        override_score: false,
        custom_score: 100,
        override_justification: ""
      };
    }
    
    renderReport(reportData);
    reportActions.hidden = false;
    if (window.innerWidth < 1100) {
      reportPanel.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  } catch (err) {
    logLine(`Could not load report: ${err.message}`, "term-err");
  }
}

// ===== Rendering helpers =====
function getMatrixCellSeverity(l, i) {
  const score = l * i;
  if (score >= 16) return { name: "Critical", cls: "cell-critical" };
  if (score >= 10) return { name: "High", cls: "cell-high" };
  if (score >= 5) return { name: "Medium", cls: "cell-medium" };
  return { name: "Low", cls: "cell-low" };
}

function renderScorecard(s) {
  const ratingClass = s.risk_rating === "Good" ? "score-good" : s.risk_rating === "Needs Attention" ? "score-warn" : "score-bad";
  return `
    <div class="scorecard">
      <div class="scorecard-main ${ratingClass}">
        <div class="scorecard-number">${s.risk_score}</div>
        <div class="scorecard-label">/ 100 — ${escapeHtml(s.risk_rating)}</div>
      </div>
      <div class="scorecard-grid">
        <div class="scorecard-item"><span class="sc-num">${s.open_ports}</span><span class="sc-label">Open Ports</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.subdomains_found}</span><span class="sc-label">Subdomains</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.endpoints_found}</span><span class="sc-label">Endpoints</span></div>
        <div class="scorecard-item sev-critical-text"><span class="sc-num">${s.cve_critical}</span><span class="sc-label">Critical CVEs</span></div>
        <div class="scorecard-item sev-high-text"><span class="sc-num">${s.cve_high}</span><span class="sc-label">High CVEs</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.total_cves}</span><span class="sc-label">Total CVEs</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.session_or_jwt_cookies}</span><span class="sc-label">Session/JWT Cookies</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.missing_security_headers}</span><span class="sc-label">Missing Headers</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.waf_detected ? "Yes" : "No"}</span><span class="sc-label">WAF Detected</span></div>
      </div>
    </div>`;
}

function renderAnalystCard() {
  const likelihoods = ["Rare", "Unlikely", "Possible", "Likely", "Almost Certain"];
  const impacts = ["Insignificant", "Minor", "Moderate", "Major", "Severe"];
  
  let matrixHtml = `<div class="matrix-grid">`;
  matrixHtml += `<div class="matrix-header">Impact \\ Like</div>`;
  for (let l = 0; l < 5; l++) {
    matrixHtml += `<div class="matrix-header">${likelihoods[l]}</div>`;
  }
  
  for (let i = 4; i >= 0; i--) {
    matrixHtml += `<div class="matrix-row-label">${impacts[i]}</div>`;
    for (let l = 0; l < 5; l++) {
      const likelihoodVal = l + 1;
      const impactVal = i + 1;
      const cellSev = getMatrixCellSeverity(likelihoodVal, impactVal);
      const isSelected = currentAssessment.likelihood === likelihoodVal && currentAssessment.impact === impactVal;
      matrixHtml += `<button type="button" class="matrix-cell ${cellSev.cls} ${isSelected ? 'selected' : ''}" 
        data-likelihood="${likelihoodVal}" 
        data-impact="${impactVal}">${likelihoodVal * impactVal}</button>`;
    }
  }
  matrixHtml += `</div>`;
  
  let assessedSev = "Unassessed";
  let assessedCls = "bg-secondary text-white";
  let assessedGlow = "rgba(255,255,255,0.05)";
  if (currentAssessment.likelihood && currentAssessment.impact) {
    const item = getMatrixCellSeverity(currentAssessment.likelihood, currentAssessment.impact);
    assessedSev = item.name;
    if (assessedSev === "Critical") { assessedCls = "bg-danger text-white"; assessedGlow = "rgba(231,76,60,0.4)"; }
    else if (assessedSev === "High") { assessedCls = "bg-warning text-dark"; assessedGlow = "rgba(230,126,34,0.4)"; }
    else if (assessedSev === "Medium") { assessedCls = "bg-info text-dark"; assessedGlow = "rgba(241,196,15,0.4)"; }
    else { assessedCls = "bg-success text-white"; assessedGlow = "rgba(46,204,113,0.4)"; }
  }
  
  return `
    <div class="analyst-card text-start">
      <h3>🛡️ Analyst Risk Matrix & Threat Modeling</h3>
      
      <p class="section-note">Evaluate risk by selecting Likelihood and Impact scores below. The matrix calculates severity dynamically.</p>
      
      <div class="risk-matrix-wrapper">
        ${matrixHtml}
      </div>
      
      <div class="assess-badge-container">
        <span class="section-note" style="margin:0;">Risk Severity Grid Mapping:</span>
        <span class="assess-badge ${assessedCls}" style="--badge-glow: ${assessedGlow}">${assessedSev.toUpperCase()}</span>
      </div>

      <!-- STRIDE Section -->
      <div class="stride-box">
        <h4 style="margin:0 0 10px 0;color:#fff;font-size:12.5px;font-family:var(--font-display);">Add Threat Modeling Scenario (STRIDE)</h4>
        
        <div class="stride-grid">
          <div class="stride-field">
            <label for="strideVector">STRIDE Vector</label>
            <select id="strideVector">
              <option value="Spoofing">Spoofing (Identity)</option>
              <option value="Tampering">Tampering (Data Integrity)</option>
              <option value="Repudiation">Repudiation (Audit/Logging)</option>
              <option value="Information Disclosure">Information Disclosure (Privacy)</option>
              <option value="Denial of Service">Denial of Service (Availability)</option>
              <option value="Elevation of Privilege">Elevation of Privilege (Authorization)</option>
            </select>
          </div>
          <div class="stride-field">
            <label for="strideCompliance">Compliance Scope</label>
            <select id="strideCompliance">
              <option value="OWASP Top 10">OWASP Top 10</option>
              <option value="ISO 27001">ISO 27001</option>
              <option value="SOC 2">SOC 2</option>
              <option value="NIST CSF">NIST CSF</option>
              <option value="HIPAA">HIPAA</option>
              <option value="None">None / General</option>
            </select>
          </div>
        </div>

        <div class="stride-field" style="margin-bottom: 12px;">
          <label for="strideDesc">Threat Description / Asset Scenario</label>
          <input type="text" id="strideDesc" placeholder="e.g. Exposed version banner permits target CVE discovery...">
        </div>

        <div class="stride-field">
          <label for="strideMitigation">Remediation / Compensating Controls</label>
          <textarea id="strideMitigation" rows="2" placeholder="e.g. Obfuscate headers and restrict service access..."></textarea>
        </div>

        <div class="stride-btn-row">
          <button type="button" class="btn-assess-action" id="addStrideBtn">Add Threat Scenario</button>
        </div>

        <div class="stride-list-container" id="strideList">
          ${renderStrideScenarios()}
        </div>
      </div>

      <!-- Notes and Override Section -->
      <div class="assess-notes-box">
        <div class="stride-field">
          <label for="assessNotes">General Assessment Notes</label>
          <textarea id="assessNotes" rows="3" placeholder="Enter administrative annotations, compensating controls, audit references, or summary findings here...">${escapeHtml(currentAssessment.notes)}</textarea>
        </div>

        <div class="assess-row-split">
          <div class="assess-score-override-box">
            <label class="checkbox" style="color:#fff;font-weight:600;">
              <input type="checkbox" id="overrideScoreCheck" ${currentAssessment.override_score ? 'checked' : ''}>
              <span>Override Automated Risk Score</span>
            </label>
            <div id="overrideFields" style="display: ${currentAssessment.override_score ? 'flex' : 'none'}; flex-direction:column; gap:8px; margin-top:4px;">
              <div class="stride-field">
                <label for="assessScore">Manually Adjusted Score (0 - 100)</label>
                <input type="number" id="assessScore" min="0" max="100" value="${currentAssessment.custom_score}">
              </div>
              <div class="stride-field">
                <label for="assessJustify">Override Justification</label>
                <textarea id="assessJustify" rows="2" placeholder="Provide explanation for manual severity override...">${escapeHtml(currentAssessment.override_justification)}</textarea>
              </div>
            </div>
          </div>

          <div class="stride-field">
            <label for="assessStatus">Assessment Sign-off Status</label>
            <select id="assessStatus" style="height:100%;">
              <option value="Draft" ${currentAssessment.status === 'Draft' ? 'selected' : ''}>Draft / Under Evaluation</option>
              <option value="Under Review" ${currentAssessment.status === 'Under Review' ? 'selected' : ''}>Under Peer Review</option>
              <option value="Approved" ${currentAssessment.status === 'Approved' ? 'selected' : ''}>Approved &amp; Signed Off</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Action buttons -->
      <div class="assess-actions-bar">
        <button type="button" class="btn-assess-export" id="exportReportBtn">📥 Export PDF / Briefing</button>
        <button type="button" class="btn-assess-submit" id="saveAssessmentBtn">💾 Save Assessment to Server</button>
      </div>
    </div>`;
}

function renderStrideScenarios() {
  if (!currentAssessment.stride_scenarios || !currentAssessment.stride_scenarios.length) {
    return `<p class="section-note" style="text-align:center;margin-top:10px;">No threat scenarios logged yet.</p>`;
  }
  return currentAssessment.stride_scenarios.map((sc, index) => {
    return `
      <div class="stride-item">
        <div class="stride-item-left">
          <div class="stride-item-meta">
            <span class="stride-tag tag-crit">${escapeHtml(sc.vector)}</span>
            <span class="stride-tag">${escapeHtml(sc.compliance)}</span>
          </div>
          <div class="stride-item-desc">${escapeHtml(sc.description)}</div>
          <div class="stride-item-mitigation">Mitigation: ${escapeHtml(sc.mitigation)}</div>
        </div>
        <button type="button" class="stride-item-remove" data-index="${index}" title="Remove scenario"><i class="fa-solid fa-trash"></i></button>
      </div>`;
  }).join("");
}

function bindAssessmentEvents(jobId) {
  document.querySelectorAll(".matrix-cell").forEach(cell => {
    cell.addEventListener("click", () => {
      const l = parseInt(cell.getAttribute("data-likelihood"), 10);
      const i = parseInt(cell.getAttribute("data-impact"), 10);
      currentAssessment.likelihood = l;
      currentAssessment.impact = i;
      refreshAnalystCard();
    });
  });

  const addStrideBtn = document.getElementById("addStrideBtn");
  if (addStrideBtn) {
    addStrideBtn.addEventListener("click", () => {
      const vec = document.getElementById("strideVector").value;
      const comp = document.getElementById("strideCompliance").value;
      const desc = document.getElementById("strideDesc").value.trim();
      const mit = document.getElementById("strideMitigation").value.trim();
      
      if (!desc) {
        alert("Please specify a threat description.");
        return;
      }
      
      currentAssessment.stride_scenarios.push({
        vector: vec,
        compliance: comp,
        description: desc,
        mitigation: mit || "Compensating controls pending formulation."
      });
      
      refreshAnalystCard();
    });
  }

  document.querySelectorAll(".stride-item-remove").forEach(btn => {
    btn.addEventListener("click", () => {
      const idx = parseInt(btn.getAttribute("data-index"), 10);
      currentAssessment.stride_scenarios.splice(idx, 1);
      refreshAnalystCard();
    });
  });

  const assessNotes = document.getElementById("assessNotes");
  if (assessNotes) {
    assessNotes.addEventListener("input", (e) => {
      currentAssessment.notes = e.target.value;
    });
  }

  const overrideScoreCheck = document.getElementById("overrideScoreCheck");
  const overrideFields = document.getElementById("overrideFields");
  if (overrideScoreCheck && overrideFields) {
    overrideScoreCheck.addEventListener("change", (e) => {
      currentAssessment.override_score = e.target.checked;
      overrideFields.style.display = e.target.checked ? "flex" : "none";
    });
  }

  const assessScore = document.getElementById("assessScore");
  if (assessScore) {
    assessScore.addEventListener("input", (e) => {
      currentAssessment.custom_score = parseInt(e.target.value, 10) || 100;
    });
  }

  const assessJustify = document.getElementById("assessJustify");
  if (assessJustify) {
    assessJustify.addEventListener("input", (e) => {
      currentAssessment.override_justification = e.target.value;
    });
  }

  const assessStatus = document.getElementById("assessStatus");
  if (assessStatus) {
    assessStatus.addEventListener("change", (e) => {
      currentAssessment.status = e.target.value;
    });
  }

  const saveBtn = document.getElementById("saveAssessmentBtn");
  if (saveBtn) {
    saveBtn.addEventListener("click", async () => {
      saveBtn.disabled = true;
      saveBtn.innerHTML = "⏳ Saving...";
      try {
        const res = await fetch(`${API_BASE}/api/recon/report/${jobId}/assess`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...authHeaders()
          },
          body: JSON.stringify(currentAssessment)
        });
        if (!res.ok) {
          throw new Error(`Server returned HTTP ${res.status}`);
        }
        alert("💾 Risk assessment saved successfully to MongoDB.");
      } catch (err) {
        alert(`❌ Failed to save assessment: ${err.message}`);
      } finally {
        saveBtn.disabled = false;
        saveBtn.innerHTML = "💾 Save Assessment to Server";
      }
    });
  }

  const exportBtn = document.getElementById("exportReportBtn");
  if (exportBtn) {
    exportBtn.addEventListener("click", () => {
      window.print();
    });
  }
}

function refreshAnalystCard() {
  const cardDiv = document.querySelector(".analyst-card");
  if (cardDiv) {
    const assessNotes = document.getElementById("assessNotes");
    if (assessNotes) currentAssessment.notes = assessNotes.value;
    const assessScore = document.getElementById("assessScore");
    if (assessScore) currentAssessment.custom_score = parseInt(assessScore.value, 10) || 100;
    const assessJustify = document.getElementById("assessJustify");
    if (assessJustify) currentAssessment.override_justification = assessJustify.value;
    const assessStatus = document.getElementById("assessStatus");
    if (assessStatus) currentAssessment.status = assessStatus.value;

    const parent = cardDiv.parentElement;
    const placeholder = document.createElement("div");
    parent.replaceChild(placeholder, cardDiv);
    placeholder.outerHTML = renderAnalystCard();
    
    bindAssessmentEvents(currentJobId);
  }
}

function section(id, title, bodyHtml, openByDefault = true) {
  return `
    <div class="report-section ${openByDefault ? "open" : ""}" id="sec-${id}">
      <div class="report-section-head" onclick="document.getElementById('sec-${id}').classList.toggle('open')">
        <span>${title}</span>
        <span class="chevron">▶</span>
      </div>
      <div class="report-section-body">${bodyHtml}</div>
    </div>`;
}

function kvTable(obj) {
  if (!obj || typeof obj !== "object") return `<p class="section-note">No data.</p>`;
  const rows = Object.entries(obj)
    .filter(([k, v]) => v !== null && v !== undefined && !(Array.isArray(v) && v.length === 0))
    .map(([k, v]) => {
      let val = Array.isArray(v) ? v.join(", ") : (typeof v === "object" ? JSON.stringify(v) : v);
      return `<tr><td>${escapeHtml(k)}</td><td>${escapeHtml(val)}</td></tr>`;
    }).join("");
  return rows ? `<table class="kv-table">${rows}</table>` : `<p class="section-note">No data returned.</p>`;
}

function tagList(items, variantFn) {
  if (!items || !items.length) return `<p class="section-note">None found.</p>`;
  return `<div class="tag-list">${items.map(i => {
    const cls = variantFn ? variantFn(i) : "";
    return `<span class="tag ${cls}">${escapeHtml(typeof i === "object" ? JSON.stringify(i) : i)}</span>`;
  }).join("")}</div>`;
}

function miniTable(rows, columns) {
  if (!rows || !rows.length) return `<p class="section-note">None found.</p>`;
  const head = columns.map(c => `<th>${escapeHtml(c.label)}</th>`).join("");
  const body = rows.map(r => `<tr>${columns.map(c => `<td class="${c.cls ? c.cls(r) : ''}">${escapeHtml(c.get(r))}</td>`).join("")}</tr>`).join("");
  return `<table class="mini-table"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
}

function linkList(items) {
  if (!items || !items.length) return `<p class="section-note">None found.</p>`;
  return `<ul class="link-list">${items.slice(0, 60).map(l =>
    `<li><a href="${escapeHtml(l)}" target="_blank" rel="noopener">${escapeHtml(l)}</a></li>`).join("")}</ul>`;
}

function rawToggle(id, content) {
  return `<span class="raw-toggle" onclick="const el=document.getElementById('${id}'); el.style.display = el.style.display==='none' ? 'block' : 'none';">▸ view raw</span>
          <div class="raw-block" id="${id}" style="display:none">${escapeHtml(content)}</div>`;
}

function renderReport(report) {
  let html = "";

  if (report.executive_summary) {
    html += renderScorecard(report.executive_summary);
  }

  html += renderAnalystCard();

  if (report.target) {
    html += section("target", "🎯 Target Summary", kvTable(report.target), true);
  }

  if (report.dns_whois) {
    const d = report.dns_whois;
    let body = `<h4 style="margin:0 0 6px;color:var(--teal);font-size:11.5px;">Primary IP</h4>${kvTable({ "IP Address": d.primary_ip })}`;
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">DNS Records</h4>`;
    if (d.dns_records && Object.keys(d.dns_records).length) {
      body += miniTable(
        Object.entries(d.dns_records).flatMap(([type, vals]) => vals.map(v => ({ type, v }))),
        [{ label: "Type", get: r => r.type }, { label: "Value", get: r => r.v }]
      );
    } else {
      body += `<p class="section-note">No records resolved.</p>`;
    }
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">WHOIS</h4>`;
    body += d.whois && !d.whois.error ? kvTable(d.whois) : `<p class="section-note">WHOIS lookup unavailable: ${escapeHtml(d.whois?.error || "unknown")}</p>`;
    html += section("dns", "🌐 Domain, DNS &amp; WHOIS", body);
  }

  if (report.subdomains) {
    const s = report.subdomains;
    let body = `<p class="section-note">${s.total_found} subdomain(s) found via ${escapeHtml(s.source || "")}.</p>`;
    body += tagList(s.subdomains);
    if (s.resolved_with_ip && s.resolved_with_ip.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Resolved with IP</h4>`;
      body += miniTable(s.resolved_with_ip, [{ label: "Subdomain", get: r => r.subdomain }, { label: "IP", get: r => r.ip }]);
    }
    html += section("subs", "🧩 Subdomains", body);
  }

  if (report.network_scan) {
    const n = report.network_scan;
    let body = kvTable({ "Scan engine": n.engine, "OS guess": n.os_guess, "Ports checked": n.ports_scanned });
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Open Ports &amp; Services</h4>`;
    body += miniTable(n.open_ports, [
      { label: "Port", get: r => r.port, cls: () => "port-open" },
      { label: "Service", get: r => r.service || r.protocol || "" },
      { label: "Version / Banner", get: r => r.version_guess || r.banner || "—" },
    ]);
    if (n.raw_output) body += rawToggle("raw-nmap", n.raw_output);
    html += section("netscan", "🛰️ Network Scan (Ports / Services / OS)", body);
  }

  if (report.web_recon) {
    const w = report.web_recon;
    let body = kvTable({
      "Status code": w.status_code, "Server banner": w.server_banner,
      "WAF/CDN detected": (w.waf_detected || []).join(", ") || "None detected",
    });
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Technologies</h4>${tagList(w.technologies, () => "tag-teal")}`;
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Cookies</h4>`;
    body += miniTable(w.cookies, [
      { label: "Name", get: r => r.name },
      { label: "Type", get: r => r.type, cls: r => r.type === "JWT" ? "cookie-jwt" : (r.type === "Session ID" ? "cookie-session" : "") },
      { label: "HttpOnly", get: r => r.http_only ? "yes" : "no" },
      { label: "Secure", get: r => r.secure ? "yes" : "no" },
      { label: "SameSite", get: r => r.same_site || "—" },
    ]);
    if (w.ssl_certificate) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">SSL Certificate</h4>${kvTable(w.ssl_certificate)}`;
    }
    if (w.headers) body += rawToggle("raw-headers", JSON.stringify(w.headers, null, 2));
    html += section("webrecon", "🔐 Web Recon (Headers / Cookies / SSL / WAF)", body);
  }

  if (report.endpoints) {
    const e = report.endpoints;
    let body = `<p class="section-note">${e.total_endpoints} total endpoint(s) discovered.</p>`;
    body += `<h4 style="margin:10px 0 6px;color:var(--teal);font-size:11.5px;">Crawled Links</h4>${linkList(e.crawled_links)}`;
    if (e.well_known_paths_present && e.well_known_paths_present.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Well-Known Paths Present</h4>`;
      body += miniTable(e.well_known_paths_present, [
        { label: "Path", get: r => r.path, cls: () => "port-open" },
        { label: "Status", get: r => r.status },
        { label: "Size (bytes)", get: r => r.size_bytes },
      ]);
    }
    if (e.forms_found && e.forms_found.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Forms</h4>`;
      body += miniTable(e.forms_found, [
        { label: "Action", get: r => r.action }, { label: "Method", get: r => r.method },
        { label: "Inputs", get: r => (r.inputs || []).join(", ") },
      ]);
    }
    if (e.disclosed_via_robots_sitemap && e.disclosed_via_robots_sitemap.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Disclosed via robots.txt / sitemap.xml</h4>`;
      body += miniTable(e.disclosed_via_robots_sitemap, [
        { label: "Source", get: r => r.source }, { label: "Directive", get: r => r.directive }, { label: "Path", get: r => r.path },
      ]);
    }
    html += section("endpoints", "🕸️ Endpoint Discovery", body);
  }

  if (report.cve_lookup) {
    const c = report.cve_lookup;
    let body = `<p class="section-note">${c.total_cves_found} CVE(s) found across ${c.software_checked} software version(s) checked against the free NVD database.</p>`;
    if (c.findings && c.findings.length) {
      c.findings.forEach(f => {
        if (!f.cves.length) return;
        body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">${escapeHtml(f.product)} ${escapeHtml(f.version)} <span class="section-note">(${escapeHtml(f.source)})</span></h4>`;
        body += `<table class="mini-table"><thead><tr><th>CVE</th><th>Severity</th><th>CVSS</th><th>Published</th><th>Description</th></tr></thead><tbody>`;
        f.cves.forEach(cv => {
          body += `<tr>
            <td><a href="${escapeHtml(cv.url)}" target="_blank" rel="noopener" style="color:var(--blue)">${escapeHtml(cv.cve_id)}</a></td>
            <td><span class="sev-badge sev-${(cv.severity || 'unknown').toLowerCase()}">${escapeHtml(cv.severity)}</span></td>
            <td>${cv.cvss_score ?? "—"}</td>
            <td>${escapeHtml(cv.published)}</td>
            <td style="max-width:280px;">${escapeHtml(cv.description)}</td>
          </tr>`;
        });
        body += `</tbody></table>`;
      });
      if (!c.total_cves_found) body += `<p class="section-note">No known CVEs matched for the versions detected.</p>`;
    }
    if (c.software_detected && c.software_detected.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">All Detected Software</h4>`;
      body += miniTable(c.software_detected, [
        { label: "Product", get: r => r.product }, { label: "Version", get: r => r.version || "—" }, { label: "Source", get: r => r.source },
      ]);
    }
    html += section("cve", "🛡️ Vulnerability Intelligence (CVE Matches)", body, true);
  }

  if (report.osint) {
    const o = report.osint;
    let body = "";
    if (o.github) {
      body += `<h4 style="margin:0 0 6px;color:var(--teal);font-size:11.5px;">GitHub</h4>`;
      body += o.github.found ? kvTable(o.github.org) : `<p class="section-note">${escapeHtml(o.github.note)}</p>`;
      if (o.github.public_members && o.github.public_members.length) {
        body += miniTable(o.github.public_members, [{ label: "Username", get: r => r.username }, { label: "Profile", get: r => r.profile }]);
      }
    }
    if (o.search_dorks) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Search Dorks (click to open manually)</h4>`;
      body += `<ul class="link-list">${Object.entries(o.search_dorks).map(([label, url]) =>
        `<li>${escapeHtml(label.replace(/_/g, " "))}: <a href="${escapeHtml(url)}" target="_blank" rel="noopener">open ↗</a></li>`).join("")}</ul>`;
    }
    if (o.email_pattern_examples && o.email_pattern_examples.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Email Pattern Guesses</h4>`;
      body += miniTable(o.email_pattern_examples, [{ label: "Pattern", get: r => r.pattern }, { label: "Confidence", get: r => r.confidence }]);
    }
    if (o.breach_check) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Data Breach Exposure</h4>${kvTable(o.breach_check)}`;
    }
    html += section("osint", "🕵️ OSINT — Company / Employees / Breaches", body);
  }

  reportBody.innerHTML = html || `<p class="empty-state">No data returned.</p>`;
  bindAssessmentEvents(currentJobId);
}
