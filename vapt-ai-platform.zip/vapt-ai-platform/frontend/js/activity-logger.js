// CYVERION — Global Activity Logger & Maintenance Redirector
(function () {
  const API_BASE = "";

  function getAuthHeaders() {
    const token = sessionStorage.getItem("authToken");
    return token ? { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" } : { "Content-Type": "application/json" };
  }

  // Retrieve role securely from sessionStorage
  function isUserAdmin() {
    const role = (sessionStorage.getItem("userRole") || "").trim().toLowerCase();
    return role === "admin" || role === "administrator";
  }

  // Post audit logs to the backend
  async function logActivity(action, detail) {
    try {
      const email = sessionStorage.getItem("userEmail") || "anonymous";
      const role = sessionStorage.getItem("userRole") || "guest";
      const enrichedDetail = {
        page: window.location.pathname.split("/").pop() || "index.html",
        user_email: email,
        user_role: role,
        ...detail
      };

      await fetch(`${API_BASE}/api/admin/audit/log`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({
          action: action,
          detail: enrichedDetail
        })
      });
    } catch (err) {
      console.warn("[Logger] Failed to send audit log:", err);
    }
  }

  // Maintenance protection check
  async function checkMaintenanceProtection() {
    const currentPage = window.location.pathname.split("/").pop() || "index.html";
    const fullPath = window.location.pathname;

    const isSecretPath = fullPath.endsWith("/cyverion/cyverion/admin/cy.html") || fullPath.endsWith("/cyverion/cyverion/admin/cy");

    if (currentPage === "maintenance.html" || currentPage === "login.html") return;

    try {
      const res = await fetch(`${API_BASE}/api/maintenance/status`);
      if (res.ok) {
        const data = await res.json();
        if (data.maintenance === true) {
          // Maintenance is active
          if (isSecretPath) return; // Allow access to secret gateway
          if (isUserAdmin()) return; // Allow logged-in admins to access other pages
          
          console.warn("[Maintenance] System is in maintenance mode. Redirecting...");
          window.location.href = "/maintenance.html";
        } else {
          // Maintenance is inactive
          if (isSecretPath) {
            // Secret path is only for maintenance mode; redirect to normal login
            window.location.href = "/login.html";
          }
        }
      }
    } catch (err) {
      console.warn("[Maintenance] Status check failed:", err);
    }
  }

  // Initial load checks
  window.addEventListener("DOMContentLoaded", () => {
    const pageName = window.location.pathname.split("/").pop() || "index.html";
    
    // Log page view
    logActivity("PAGE_VIEW", { title: document.title });
    
    // Check maintenance mode immediately
    checkMaintenanceProtection();
    // Poll maintenance mode every 5 seconds for active sessions
    setInterval(checkMaintenanceProtection, 5000);
  });

  // Intercept button and link click events
  document.addEventListener("click", (e) => {
    let target = e.target;
    
    // Bubble up to find clickable element
    while (target && target !== document.body) {
      const tag = target.nodeName.toUpperCase();
      
      // 1. Tab switches
      if (target.classList.contains("admin-tab")) {
        const tabName = target.querySelector(".node-name")?.textContent?.trim() || target.textContent?.trim();
        logActivity("TAB_SWITCH", { tab: tabName, tabId: target.dataset.tab });
        return;
      }
      
      // 2. Filter chips
      if (target.classList.contains("filter-chip")) {
        logActivity("FILTER_CLICK", { text: target.textContent?.trim(), category: target.parentNode?.id || "unknown" });
        return;
      }

      // 3. Theme switch buttons
      if (target.dataset.themeBtn !== undefined) {
        logActivity("THEME_CHANGE", { theme: target.dataset.themeBtn });
        return;
      }

      // 4. Buttons
      if (tag === "BUTTON" || target.classList.contains("btn") || target.classList.contains("btn-mini")) {
        const btnText = target.textContent?.trim() || target.value || target.title || "unnamed";
        logActivity("BUTTON_CLICK", { 
          text: btnText.substring(0, 100).replace(/\s+/g, " "),
          id: target.id || null,
          classes: target.className
        });
        return;
      }

      // 5. Links
      if (tag === "A") {
        const linkText = target.textContent?.trim() || target.title || "unnamed";
        const href = target.getAttribute("href");
        if (href && !href.startsWith("javascript:")) {
          logActivity("LINK_CLICK", {
            text: linkText.substring(0, 100).replace(/\s+/g, " "),
            href: href,
            id: target.id || null
          });
        }
        return;
      }

      target = target.parentNode;
    }
  });

  // Intercept input changes (dropdowns, checkboxes)
  document.addEventListener("change", (e) => {
    const target = e.target;
    if (!target) return;
    
    const tag = target.nodeName.toUpperCase();
    if (tag === "SELECT") {
      const label = target.options[target.selectedIndex]?.text || target.value;
      logActivity("SELECT_CHANGE", {
        id: target.id || null,
        name: target.name || null,
        value: target.value,
        label: label
      });
    } else if (tag === "INPUT") {
      const type = target.type?.toLowerCase();
      if (type === "checkbox" || type === "radio") {
        logActivity("TOGGLE_CHANGE", {
          id: target.id || null,
          name: target.name || null,
          checked: target.checked
        });
      }
    }
  });

  // Expose logger globally
  window.CYVERION_LOGGER = { logActivity };
})();
