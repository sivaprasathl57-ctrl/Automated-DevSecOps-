/* ===========================================
      CYVERION – ULTIMATE RED & BLACK
      3D Particle System + Animations
===========================================*/

// ==========================================
// RED PARTICLE SYSTEM
// ==========================================

(function initParticles() {
    const container = document.getElementById('particles');
    if (!container) return;

    const PARTICLE_COUNT = 90;

    for (let i = 0; i < PARTICLE_COUNT; i++) {
        const p = document.createElement('span');
        const size = Math.random() * 3.5 + 1;
        const isEmber = Math.random() > 0.75;

        p.style.cssText = `
            position: absolute;
            width: ${size}px;
            height: ${size}px;
            border-radius: 50%;
            background: ${isEmber ? '#FF6D00' : '#FF1744'};
            opacity: ${Math.random() * 0.6 + 0.15};
            left: ${Math.random() * 100}vw;
            top: ${Math.random() * 100}vh;
            box-shadow: 0 0 ${size * 4}px ${isEmber ? '#FF6D00' : '#FF1744'},
                        0 0 ${size * 8}px ${isEmber ? 'rgba(255,109,0,0.4)' : 'rgba(255,23,68,0.3)'};
            pointer-events: none;
        `;

        container.appendChild(p);
        animateParticle(p);
    }

    function animateParticle(el) {
        if (typeof gsap === 'undefined') return;

        const randomX = (Math.random() - 0.5) * 200;

        gsap.to(el, {
            y: -(window.innerHeight + 300),
            x: randomX,
            opacity: 0,
            duration: Math.random() * 14 + 10,
            repeat: -1,
            ease: 'none',
            delay: Math.random() * 8,
            onRepeat: () => {
                gsap.set(el, {
                    y: 0,
                    x: 0,
                    opacity: Math.random() * 0.6 + 0.15,
                    left: Math.random() * window.innerWidth + 'px',
                    top: window.innerHeight + 'px'
                });
            }
        });
    }
})();


// ==========================================
// GSAP INTRO ANIMATIONS
// ==========================================

window.addEventListener('load', () => {
    if (typeof gsap === 'undefined') return;

    // Header slide down
    gsap.from('header', {
        y: -100,
        opacity: 0,
        duration: 1,
        ease: 'power3.out'
    });

    // Hero left text – stagger in
    gsap.from('.small-title', {
        x: -60,
        opacity: 0,
        duration: 0.9,
        delay: 0.3,
        ease: 'power2.out'
    });

    gsap.from('.hero-left h1', {
        x: -100,
        opacity: 0,
        duration: 1.1,
        delay: 0.5,
        ease: 'power3.out'
    });

    gsap.from('.hero-left p', {
        x: -70,
        opacity: 0,
        duration: 1,
        delay: 0.7,
        ease: 'power2.out'
    });

    gsap.from('.buttons', {
        y: 40,
        opacity: 0,
        duration: 0.9,
        delay: 0.9,
        ease: 'back.out(1.5)'
    });

    gsap.from('.stats .box', {
        y: 50,
        opacity: 0,
        duration: 0.7,
        stagger: 0.15,
        delay: 1.1,
        ease: 'power2.out'
    });

    // GLASS CARD KEPT STATIC — no entrance animation

    // Feature cards – scroll triggered
    gsap.from('.card', {
        y: 60,
        opacity: 0,
        duration: 0.7,
        stagger: 0.15,
        delay: 0.2,
        ease: 'power2.out',
        scrollTrigger: {
            trigger: '.features',
            start: 'top 85%'
        }
    });

    gsap.from('.future-panel', {
        y: 70,
        opacity: 0,
        duration: 1,
        delay: 0.3,
        ease: 'power2.out',
        scrollTrigger: {
            trigger: '.future-showcase',
            start: 'top 85%'
        }
    });

    gsap.from('.future-card', {
        y: 50,
        opacity: 0,
        duration: 0.7,
        stagger: 0.12,
        delay: 0.45,
        ease: 'power2.out',
        scrollTrigger: {
            trigger: '.future-showcase',
            start: 'top 80%'
        }
    });
});


// ==========================================
// GLASS CARD KEPT STATIC — no 3D parallax tilt
// ==========================================


// ==========================================
// FEATURE CARD – MOUSE CURSOR GLOW
// ==========================================

document.querySelectorAll('.card, .future-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
        const rect  = card.getBoundingClientRect();
        const x     = e.clientX - rect.left;
        const y     = e.clientY - rect.top;

        card.style.background = `
            radial-gradient(
                circle at ${x}px ${y}px,
                rgba(255,23,68,0.14),
                rgba(17,17,17,0.90) 60%
            )
        `;
    });

    card.addEventListener('mouseleave', () => {
        card.style.background = '';
    });
});


// ==========================================
// BUTTON MAGNETIC HOVER (GSAP)
// ==========================================

document.querySelectorAll('.btn1, .btn2').forEach(btn => {
    btn.addEventListener('mouseenter', () => {
        if (typeof gsap !== 'undefined') {
            gsap.to(btn, { scale: 1.07, duration: 0.25, ease: 'back.out(2)' });
        }
    });
    btn.addEventListener('mouseleave', () => {
        if (typeof gsap !== 'undefined') {
            gsap.to(btn, { scale: 1, duration: 0.25, ease: 'power2.out' });
        }
    });
});


// ==========================================
// COUNTER ANIMATION – STATS BOXES
// ==========================================

document.querySelectorAll('.box h2').forEach(counter => {
    const raw    = counter.innerText.replace(/[^0-9]/g, '');
    const target = parseInt(raw) || 0;
    const suffix = counter.innerText.replace(/[0-9]/g, '').trim();
    let current  = 0;
    const speed  = Math.max(target / 80, 0.5);

    function update() {
        current += speed;
        if (current < target) {
            counter.innerText = Math.floor(current) + suffix;
            requestAnimationFrame(update);
        } else {
            counter.innerText = target + suffix;
        }
    }

    setTimeout(update, 1200); // delay to let GSAP entrance finish
});


// ==========================================
// RADAR BLINK – STATUS INDICATORS
// ==========================================

setInterval(() => {
    document.querySelectorAll('.online').forEach(item => {
        item.style.opacity = '0.3';
        setTimeout(() => { item.style.opacity = '1'; }, 200);
    });
}, 2000);


// ==========================================
// TYPING EFFECT – SMALL TITLE
// ==========================================

const text  = 'AI POWERED CYBER DEFENSE PLATFORM';
const title = document.querySelector('.small-title');

if (title) {
    title.innerHTML = '';
    let index = 0;

    const borderLeft = title.style.borderLeft;

    function type() {
        if (index < text.length) {
            title.innerHTML += text.charAt(index);
            index++;
            setTimeout(type, 50);
        }
    }

    setTimeout(type, 800);
}


// ==========================================
// NAVBAR SCROLL EFFECT
// ==========================================

window.addEventListener('scroll', () => {
    const header = document.querySelector('header');
    if (!header) return;

    if (window.scrollY > 40) {
        header.style.background      = 'rgba(6,6,6,0.92)';
        header.style.borderBottom    = '1px solid rgba(255,23,68,0.25)';
        header.style.boxShadow       = '0 10px 40px rgba(255,23,68,0.10)';
    } else {
        header.style.background      = 'rgba(6,6,6,0.55)';
        header.style.borderBottom    = '1px solid rgba(255,23,68,0.14)';
        header.style.boxShadow       = 'none';
    }
});


// ==========================================
// PULSING RANDOM RED GLOW ON CARDS
// ==========================================

setInterval(() => {
    document.querySelectorAll('.card').forEach(card => {
        const intensity = (Math.random() * 20 + 8).toFixed(0);
        if (!card.matches(':hover')) {
            card.style.boxShadow =
                `0 0 ${intensity}px rgba(255,23,68,0.12), inset 0 0 ${intensity}px rgba(255,23,68,0.03)`;
        }
    });
}, 1500);


// ==========================================
// CONSOLE BRANDING
// ==========================================

console.log(
    '%cCYVERION AI PLATFORM',
    'color:#FF1744;font-size:22px;font-weight:900;text-shadow:0 0 10px #FF1744;'
);
console.log(
    '%c🔴 Ultimate Red & Black UI — v4.2.1',
    'color:#FF6D00;font-size:13px;font-weight:600;'
);
