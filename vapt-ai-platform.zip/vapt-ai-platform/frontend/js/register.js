/* ==========================================
      CYVERION – RED & BLACK REGISTER JS
      Particles + 3D Tilt + GSAP + Validation
========================================== */

// ==========================================
// API & SESSION
// ==========================================

const API_BASE = "";
if (sessionStorage.getItem("loggedIn") === "true") {
    window.location.href = "recon.html";
}

// ==========================================
// PASSWORD SHOW / HIDE
// ==========================================

const password = document.getElementById("password");
const confirmPassword = document.getElementById("confirmPassword");
const toggle = document.getElementById("togglePassword");

if (toggle && password) {
    toggle.addEventListener("click", () => {
        if (password.type === "password") {
            password.type = "text";
            toggle.classList.remove("fa-eye");
            toggle.classList.add("fa-eye-slash");
        } else {
            password.type = "password";
            toggle.classList.remove("fa-eye-slash");
            toggle.classList.add("fa-eye");
        }
    });
}

// ==========================================
// PASSWORD STRENGTH
// ==========================================

const strengthBar = document.getElementById("strength-bar");
const strengthText = document.getElementById("strength-text");

if (password && strengthBar && strengthText) {
    password.addEventListener("input", () => {
        const value = password.value;
        let strength = 0;

        if (value.length >= 8) strength++;
        if (/[A-Z]/.test(value)) strength++;
        if (/[0-9]/.test(value)) strength++;
        if (/[!@#$%^&*(),.?":{}|<>]/.test(value)) strength++;

        switch (strength) {
            case 1:
                strengthBar.style.width = "25%";
                strengthBar.style.background = "#FF1744";
                strengthText.innerHTML = "Weak Password";
                break;
            case 2:
                strengthBar.style.width = "50%";
                strengthBar.style.background = "#FF6D00";
                strengthText.innerHTML = "Medium Password";
                break;
            case 3:
                strengthBar.style.width = "75%";
                strengthBar.style.background = "#FFD600";
                strengthText.innerHTML = "Strong Password";
                break;
            case 4:
                strengthBar.style.width = "100%";
                strengthBar.style.background = "#00FF84";
                strengthText.innerHTML = "Very Strong Password";
                break;
            default:
                strengthBar.style.width = "10%";
                strengthBar.style.background = "#FF1744";
                strengthText.innerHTML = "Password Strength";
        }
    });
}

// ==========================================
// CONFIRM PASSWORD CHECK
// ==========================================

if (confirmPassword && password) {
    confirmPassword.addEventListener("keyup", () => {
        if (confirmPassword.value === "") {
            confirmPassword.style.borderColor = "rgba(255,23,68,0.15)";
            return;
        }

        if (password.value === confirmPassword.value) {
            confirmPassword.style.borderColor = "#00FF84";
        } else {
            confirmPassword.style.borderColor = "#FF1744";
        }
    });
}

// ==========================================
// RED PARTICLE SYSTEM
// ==========================================

(function initParticles() {
    const container = document.getElementById("particles");
    if (!container) return;

    const COUNT = 70;

    for (let i = 0; i < COUNT; i++) {
        const p = document.createElement("span");
        const size = Math.random() * 3 + 1;
        const isEmber = Math.random() > 0.7;

        p.style.cssText = `
            position: absolute;
            width: ${size}px;
            height: ${size}px;
            border-radius: 50%;
            background: ${isEmber ? '#FF6D00' : '#FF1744'};
            opacity: ${Math.random() * 0.55 + 0.10};
            left: ${Math.random() * 100}vw;
            top: ${window.innerHeight + 20}px;
            box-shadow: 0 0 ${size * 4}px ${isEmber ? '#FF6D00' : '#FF1744'},
                        0 0 ${size * 8}px ${isEmber ? 'rgba(255,109,0,0.3)' : 'rgba(255,23,68,0.25)'};
            pointer-events: none;
        `;

        container.appendChild(p);
        floatUp(p);
    }

    function floatUp(el) {
        const duration = Math.random() * 13 + 9;
        const xDrift = (Math.random() - 0.5) * 180;

        function run() {
            let start = null;
            const startY = parseFloat(el.style.top) || window.innerHeight;
            const endY = -100;

            (function step(ts) {
                if (!start) start = ts;
                const progress = (ts - start) / (duration * 1000);
                if (progress >= 1) {
                    el.style.top = window.innerHeight + Math.random() * 200 + 'px';
                    el.style.left = Math.random() * window.innerWidth + 'px';
                    el.style.opacity = Math.random() * 0.55 + 0.10;
                    setTimeout(run, Math.random() * 3000);
                    return;
                }
                el.style.top = startY + (endY - startY) * progress + 'px';
                el.style.left = parseFloat(el.style.left) + xDrift * 0.0001 + 'px';
                el.style.opacity = (Math.random() * 0.55 + 0.10) * (1 - progress * 0.5);
                requestAnimationFrame(step);
            })(performance.now());
        }

        setTimeout(run, Math.random() * 5000);
    }
})();

// ==========================================
// GSAP ENTRANCE ANIMATIONS
// ==========================================

if (typeof gsap !== "undefined") {
    gsap.from("header", {
        y: -80,
        opacity: 0,
        duration: 1,
        ease: "power3.out"
    });

    gsap.from(".left-panel h4", {
        x: -60,
        opacity: 0,
        duration: 0.9,
        delay: 0.3,
        ease: "power2.out"
    });

    gsap.from(".left-panel h1", {
        x: -100,
        opacity: 0,
        duration: 1.1,
        delay: 0.5,
        ease: "power3.out"
    });

    gsap.from(".left-panel p", {
        x: -70,
        opacity: 0,
        duration: 0.9,
        delay: 0.7,
        ease: "power2.out"
    });

    gsap.from(".features div", {
        y: 40,
        opacity: 0,
        duration: 0.6,
        stagger: 0.1,
        delay: 0.9,
        ease: "power2.out"
    });

    // REGISTER CARD KEPT STATIC — no entrance or 3D tilt
}

// ==========================================
// NAVBAR SCROLL EFFECT
// ==========================================

window.addEventListener("scroll", () => {
    const header = document.querySelector("header");
    if (!header) return;

    if (window.scrollY > 30) {
        header.style.background = "rgba(6,6,6,0.92)";
        header.style.borderBottom = "1px solid rgba(255,23,68,0.25)";
        header.style.boxShadow = "0 10px 40px rgba(255,23,68,0.10)";
    } else {
        header.style.background = "rgba(6,6,6,0.55)";
        header.style.borderBottom = "1px solid rgba(255,23,68,0.14)";
        header.style.boxShadow = "none";
    }
});

// ==========================================
// REGISTRATION FORM SUBMIT
// ==========================================

const form = document.querySelector("form");

if (form && password && confirmPassword) {
    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        if (password.value !== confirmPassword.value) {
            alert("Passwords do not match!");
            return;
        }

        const btn = document.querySelector(".register-btn");
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = "⏳ CREATING ACCOUNT...";
        }

        const formData = new FormData();
        const firstName = document.querySelector('input[placeholder="First Name"]');
        const lastName = document.querySelector('input[placeholder="Last Name"]');
        const email = document.querySelector('input[placeholder="Email Address"]');
        const phone = document.querySelector('input[placeholder="Phone Number"]');
        const organization = document.querySelector('input[placeholder="Organization / College"]');
        const role = document.querySelector('select');

        formData.append("first_name", firstName ? firstName.value : "");
        formData.append("last_name", lastName ? lastName.value : "");
        formData.append("email", email ? email.value : "");
        formData.append("phone", phone ? phone.value : "");
        formData.append("organization", organization ? organization.value : "");
        formData.append("role", role ? role.value : "");
        formData.append("password", password.value);

        try {
            const res = await fetch(`${API_BASE}/api/auth/register`, {
                method: "POST",
                body: formData,
            });
            const data = await res.json();

            if (res.ok && data.success) {
                if (btn) {
                    btn.innerHTML = "✔ SUCCESS";
                    btn.style.background = "linear-gradient(135deg,#00FF84,#00CC66)";
                }
                setTimeout(() => {
                    alert("Registration Successful! Please login.");
                    window.location.href = "login.html";
                }, 800);
            } else {
                const errMsg = (data && data.detail) || "Registration failed";
                alert(`❌ ${errMsg}`);
                if (btn) {
                    btn.innerHTML = "CREATE ACCOUNT";
                    btn.style.background = "";
                    btn.disabled = false;
                }
            }
        } catch (err) {
            alert(`❌ Network error: ${err.message || err}. Is the backend running?`);
            if (btn) {
                btn.innerHTML = "CREATE ACCOUNT";
                btn.style.background = "";
                btn.disabled = false;
            }
        }
    });
}

console.log(
    "%cCYVERION Register — Red & Black 🔴",
    "color:#FF1744;font-size:16px;font-weight:800;"
);
