 const API_BASE = "";
const AUTH_TOKEN = sessionStorage.getItem("authToken");
const LOGGED_IN = sessionStorage.getItem("loggedIn") === "true" && AUTH_TOKEN;
if (!LOGGED_IN) {
  window.location.href = "login.html";
}

function authHeaders() {
  return AUTH_TOKEN ? { Authorization: `Bearer ${AUTH_TOKEN}` } : {};
}

// Utility functions — must be defined BEFORE renderHistoryTable which uses them
function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str == null ? "" : String(str);
  return d.innerHTML;
}

function formatDateTime(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.valueOf())) return String(value);
  return date.toLocaleString();
}

function renderHistoryTable(items) {
  if (!items || !items.length) {
    return `<p class="section-note">No recon history available yet.</p>`;
  }
  return `<div class="history-list">${items.map(item => {
    const statusClass = item.status === "completed" ? "history-ok" : item.status === "error" ? "history-err" : "history-pending";
    return `<button type="button" class="history-entry ${statusClass}" data-job-id="${escapeHtml(item.job_id)}">
      <div class="history-entry-main">
        <div class="history-entry-title">${escapeHtml(item.target)}</div>
        <div class="history-entry-meta">${escapeHtml(item.company_name || "—")} • ${formatDateTime(item.created_at)}</div>
      </div>
      <div class="history-entry-status">${escapeHtml(item.status)}</div>
    </button>`;
  }).join("")}</div>`;
}

async function loadHistory() {
  const historyList = document.getElementById("historyList");
  if (!historyList) return;
  historyList.innerHTML = `<p class="section-note">Loading your recon history...</p>`;
  try {
    const res = await fetch(`${API_BASE}/api/recon/history`, {
      headers: authHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Server responded ${res.status}`);
    }
    const data = await res.json();
    historyList.innerHTML = renderHistoryTable(data.history);
    historyList.querySelectorAll(".history-entry").forEach(btn => {
      btn.addEventListener("click", () => {
        const jobId = btn.getAttribute("data-job-id");
        window.location.href = `view.html?job_id=${encodeURIComponent(jobId)}`;
      });
    });
  } catch (err) {
    historyList.innerHTML = `<p class="section-note">Could not load history: ${escapeHtml(err.message)}</p>`;
  }
}

/* ==========================================================================
   AUTH NAVIGATION
   ========================================================================== */
window.addEventListener("DOMContentLoaded", () => {
  // Apply globally-synced theme (Classic / Hacker / CEO) from theme.js
  if (window.CYVERION_THEME) window.CYVERION_THEME.init();

  const logoutLink = document.getElementById("logoutLink");
  const navLoginLink = document.getElementById("navLoginLink");
  const navRegisterLink = document.getElementById("navRegisterLink");

  if (logoutLink) {
    logoutLink.addEventListener("click", async (e) => {
      e.preventDefault();
      const token = sessionStorage.getItem("authToken");
      try {
        if (token) {
          await fetch(`${API_BASE}/api/auth/logout`, { method: "POST", headers: { "Authorization": `Bearer ${token}` } });
        }
      } catch (err) {
        // ignore logout errors and continue clearing session
      }
      sessionStorage.clear();
      window.location.href = "login.html";
    });
  }

  if (navLoginLink) navLoginLink.style.display = "none";
  if (navRegisterLink) navRegisterLink.style.display = "none";

  // Show admin link for users with admin role
  const adminLink = document.getElementById("adminLink");
  const userRole = sessionStorage.getItem("userRole") || "";
  if (adminLink && userRole.toLowerCase() === "admin") {
    adminLink.style.display = "inline-block";
  }

  loadHistory();
});

/* ==========================================================================
   3D Cyber Background - Three.js Particle Network
   ========================================================================== */
(function init3DBackground() {
  const canvas = document.getElementById('bg-canvas');
  if (!canvas || typeof THREE === 'undefined') return;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  const renderer = new THREE.WebGLRenderer({
    canvas: canvas,
    alpha: true,
    antialias: true
  });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  // Particle network
  const particlesGeometry = new THREE.BufferGeometry();
  const particlesCount = 1800;
  const posArray = new Float32Array(particlesCount * 3);
  for (let i = 0; i < particlesCount * 3; i++) {
    posArray[i] = (Math.random() - 0.5) * 12;
  }
  particlesGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));

  const particlesMaterial = new THREE.PointsMaterial({
    size: 0.015,
    color: 0xFF1744,
    transparent: true,
    opacity: 0.4,
    blending: THREE.AdditiveBlending,
  });
  const particlesMesh = new THREE.Points(particlesGeometry, particlesMaterial);
  scene.add(particlesMesh);

  // Connecting lines between nearby particles
  const linePositions = [];
  const positions = particlesGeometry.attributes.position.array;
  for (let i = 0; i < particlesCount; i++) {
    for (let j = i + 1; j < particlesCount; j++) {
      const dx = positions[i * 3] - positions[j * 3];
      const dy = positions[i * 3 + 1] - positions[j * 3 + 1];
      const dz = positions[i * 3 + 2] - positions[j * 3 + 2];
      const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (dist < 0.8) {
        linePositions.push(positions[i * 3], positions[i * 3 + 1], positions[i * 3 + 2]);
        linePositions.push(positions[j * 3], positions[j * 3 + 1], positions[j * 3 + 2]);
      }
    }
  }
  const linesGeometry = new THREE.BufferGeometry();
  linesGeometry.setAttribute('position', new THREE.Float32BufferAttribute(linePositions, 3));
  const linesMaterial = new THREE.LineBasicMaterial({
    color: 0xFF1744,
    transparent: true,
    opacity: 0.06,
  });
  const linesMesh = new THREE.LineSegments(linesGeometry, linesMaterial);
  scene.add(linesMesh);

  // Floating torus knot
  const torusGeo = new THREE.TorusKnotGeometry(0.3, 0.1, 64, 8);
  const torusMat = new THREE.MeshBasicMaterial({
    color: 0xFF6D00,
    wireframe: true,
    transparent: true,
    opacity: 0.08,
  });
  const torus = new THREE.Mesh(torusGeo, torusMat);
  torus.position.set(1.5, -0.5, -2);
  scene.add(torus);

  const torus2 = new THREE.Mesh(
    new THREE.TorusKnotGeometry(0.2, 0.07, 48, 6),
    new THREE.MeshBasicMaterial({ color: 0xFF1744, wireframe: true, transparent: true, opacity: 0.06 })
  );
  torus2.position.set(-1.8, 1.2, -1.5);
  scene.add(torus2);

  camera.position.z = 4;

  let mouseX = 0;
  let mouseY = 0;
  document.addEventListener('mousemove', (e) => {
    mouseX = (e.clientX / window.innerWidth - 0.5) * 0.3;
    mouseY = (e.clientY / window.innerHeight - 0.5) * 0.3;
  });

  function animate() {
    requestAnimationFrame(animate);
    particlesMesh.rotation.x += 0.0003;
    particlesMesh.rotation.y += 0.0005;
    linesMesh.rotation.x = particlesMesh.rotation.x;
    linesMesh.rotation.y = particlesMesh.rotation.y;
    torus.rotation.x += 0.005;
    torus.rotation.y += 0.008;
    torus2.rotation.x -= 0.004;
    torus2.rotation.z += 0.006;
    camera.position.x += (mouseX - camera.position.x) * 0.02;
    camera.position.y += (mouseY - camera.position.y) * 0.02;
    camera.lookAt(scene.position);
    renderer.render(scene, camera);
  }
  animate();

  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });
})();

// ==========================================================================
//  Recon Application Logic
// ==========================================================================

const reconForm = document.getElementById("reconForm");
const targetInput = document.getElementById("targetInput");
const companyInput = document.getElementById("companyInput");
const aggressiveCheck = document.getElementById("aggressiveCheck");
const osintCheck = document.getElementById("osintCheck");
const authorizedCheck = document.getElementById("authorizedCheck");
const launchBtn = document.getElementById("launchBtn");

const terminalBody = document.getElementById("terminalBody");
const jobIdLabel = document.getElementById("jobIdLabel");
const statusDot = document.getElementById("statusDot");
const statusLabel = document.getElementById("statusLabel");
const reportBody = document.getElementById("reportBody");
const reportPanel = document.getElementById("reportPanel");
const reportActions = document.getElementById("reportActions");
const expandAllBtn = document.getElementById("expandAllBtn");
const collapseAllBtn = document.getElementById("collapseAllBtn");

function normalizeTargetInput(raw) {
  if (!raw || !raw.trim()) {
    throw new Error("Target is required.");
  }
  if (raw.includes(" ")) {
    throw new Error("Target must not contain spaces.");
  }
  let value = raw.trim();
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(value)) {
    value = `https://${value}`;
  }
  let url;
  try {
    url = new URL(value);
  } catch {
    throw new Error("Enter a valid domain or URL.");
  }
  if (!["http:", "https:"].includes(url.protocol)) {
    throw new Error("Only http:// and https:// targets are allowed.");
  }
  if (url.username || url.password) {
    throw new Error("Credentials are not allowed in the target URL.");
  }
  if (!url.hostname) {
    throw new Error("Target must include a hostname.");
  }
  if (url.hostname.endsWith(".") || url.hostname.startsWith("-") || url.hostname.endsWith("-")) {
    throw new Error("Target hostname is not valid.");
  }
  return url.href;
}

expandAllBtn.addEventListener("click", () => {
  document.querySelectorAll(".report-section").forEach(s => s.classList.add("open"));
});
collapseAllBtn.addEventListener("click", () => {
  document.querySelectorAll(".report-section").forEach(s => s.classList.remove("open"));
});

/* ==========================================================================
   LINK VALIDATION — detect fake / unreachable targets
   ========================================================================== */
async function checkTargetReachability(url) {
  // Browsers block client-side cross-origin fetches with CORS, so real sites
  // (e.g. https://www.shopsy.in/) would appear unreachable even when they are
  // valid. Instead, we delegate the reachability test to the backend, which
  // performs DNS + HTTP checks with no CORS restriction.
  const apiBase = window.API_BASE || API_BASE || "";
  try {
    const formData = new FormData();
    formData.append("target", url);
    const res = await fetch(`${apiBase}/api/validate/target`, {
      method: "POST",
      body: formData,
      headers: authHeaders(),
    });
    if (!res.ok) {
      // Fall back to server-unreachable handling
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      return { reachable: false, reason: err.detail || "Validation service returned an error." };
    }
    const data = await res.json();
    if (data.valid) {
      return { reachable: true, statusCode: data.status_code };
    }
    return { reachable: false, reason: data.reason || "This link appears invalid/fake." };
  } catch (err) {
    return {
      reachable: false,
      reason: "Could not reach the validation service. Is the backend running (uvicorn main:app)?",
    };
  }
}

function markTargetInvalid(message) {
  if (targetInput) {
    targetInput.classList.add("input-invalid");
    targetInput.setAttribute("data-error", message);
  }
  const tip = document.getElementById("targetErrorTip");
  if (tip) {
    tip.textContent = "⚠ " + message;
    tip.classList.add("visible");
  }
}

function clearTargetInvalid() {
  if (targetInput) {
    targetInput.classList.remove("input-invalid");
    targetInput.removeAttribute("data-error");
  }
  const tip = document.getElementById("targetErrorTip");
  if (tip) {
    tip.textContent = "";
    tip.classList.remove("visible");
  }
}

if (targetInput) {
  targetInput.addEventListener("input", clearTargetInvalid);
}

// escapeHtml is defined at the top of this file

function logLine(text, cls = "") {
  const p = document.createElement("p");
  p.className = `term-line ${cls}`;
  const ts = new Date().toLocaleTimeString();
  p.innerHTML = `<span class="term-ts">[${ts}]</span>${escapeHtml(text)}`;
  terminalBody.appendChild(p);
  terminalBody.scrollTop = terminalBody.scrollHeight;
}

function setStatus(state, label) {
  if (statusDot) statusDot.className = `status-dot ${state}`;
  if (statusLabel) statusLabel.textContent = label;
}

function setAgentState(agent, state) {
  const node = document.querySelector(`.agent-node[data-agent="${agent}"]`);
  if (!node) return;
  node.classList.remove("active", "done", "error");
  if (state) node.classList.add(state);
}

function resetAgentStates() {
  document.querySelectorAll(".agent-node").forEach(n => n.classList.remove("active", "done", "error"));
}

// ===== Submit =====
reconForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const rawTarget = targetInput.value.trim();
  let normalizedTarget;
  try {
    normalizedTarget = normalizeTargetInput(rawTarget);
  } catch (err) {
    logLine(`Invalid target: ${err.message}`, "term-warn");
    return;
  }
  if (!authorizedCheck.checked) {
    logLine("You must confirm authorization before scanning a target.", "term-warn");
    return;
  }

  // ---- Link validation: reject fake / unreachable targets ----
  logLine("Checking target link reachability...", "term-muted");
  const linkCheck = await checkTargetReachability(normalizedTarget);
  if (!linkCheck.reachable) {
    markTargetInvalid(linkCheck.reason);
    logLine(`Invalid target: ${linkCheck.reason}. Scan not started — the link appears invalid/fake.`, "term-err");
    return;
  }
  clearTargetInvalid();
  logLine(`Target link verified — host is reachable (${linkCheck.statusCode || "OK"}).`, "term-ok");

  launchBtn.disabled = true;
  terminalBody.innerHTML = "";
  reportBody.innerHTML = `<p class="empty-state">Scan running — report sections populate as each agent completes.</p>`;
  resetAgentStates();
  setStatus("running", "Recon pipeline running...");
  logLine("Preparing recon job...", "term-muted");

  const formData = new FormData();
  formData.append("target", normalizedTarget);
  formData.append("company_name", companyInput.value.trim());
  formData.append("aggressive", aggressiveCheck.checked ? "true" : "false");
  formData.append("run_osint", osintCheck.checked ? "true" : "false");
  formData.append("authorized", "true");

  try {
    const res = await fetch(`${API_BASE}/api/recon/start`, {
      method: "POST",
      body: formData,
      headers: authHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Server responded ${res.status}`);
    }
    const data = await res.json();
    jobIdLabel.textContent = `job ${data.job_id}`;
    logLine(`Job ${data.job_id} created. Streaming agent activity...`, "term-ok");
    streamJob(data.job_id);
  } catch (err) {
    logLine(`Failed to start recon: ${err.message}. Is the backend running (uvicorn main:app)?`, "term-err");
    setStatus("error", "Failed to start");
    launchBtn.disabled = false;
  }
});

function streamJob(jobId) {
  const token = encodeURIComponent(AUTH_TOKEN || "");
  const esUrl = `${API_BASE}/api/recon/stream/${jobId}?token=${token}`;
  let es = null;
  let reconnectAttempts = 0;

  function connect() {
    es = new EventSource(esUrl);
    es.onmessage = onMessage;
    es.onerror = onError;
  }

  function onMessage(event) {
    reconnectAttempts = 0; // reset backoff on successful message
    const payload = JSON.parse(event.data);

    if (payload.done) {
      logLine(`Recon pipeline finished (${payload.status}).`, payload.status === "error" ? "term-err" : "term-ok");
      setStatus(payload.status === "error" ? "error" : "done", payload.status === "error" ? "Pipeline error" : "Recon complete");
      launchBtn.disabled = false;
      if (es) es.close();
      loadHistory();
      if (payload.status !== "error") {
        window.location.href = `view.html?job_id=${encodeURIComponent(jobId)}`;
      } else {
        loadReport(jobId);
      }
      return;
    }

    const cls = payload.status === "error" ? "term-err"
      : payload.status === "completed" ? "term-ok"
      : payload.status === "started" ? "term-agent" : "term-muted";
    logLine(`[${payload.agent}] ${payload.message}`, cls);

    if (payload.status === "started") setAgentState(payload.agent, "active");
    if (payload.status === "completed") setAgentState(payload.agent, "done");
    if (payload.status === "error") setAgentState(payload.agent, "error");
  }

  function onError() {
    if (es) try { es.close(); } catch (e) {}
    reconnectAttempts += 1;
    const wait = Math.min(30000, 500 * Math.pow(2, reconnectAttempts));
    logLine(`Connection lost. Reconnecting in ${Math.round(wait/1000)}s...`, "term-warn");
    setTimeout(connect, wait);
  }

  // initial connect
  connect();
}

async function loadReport(jobId) {
  currentJobId = jobId;
  try {
    const res = await fetch(`${API_BASE}/api/recon/report/${jobId}`, {
      headers: authHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Server responded ${res.status}`);
    }
    const data = await res.json();
    currentReport = data.report || {};
    renderReport(currentReport);
    reportActions.hidden = false;
    
    // Bind click handlers for export buttons dynamically
    const exportJsonBtn = document.getElementById("exportJsonBtn");
    const exportMdBtn = document.getElementById("exportMdBtn");
    const exportPdfBtn = document.getElementById("exportPdfBtn");
    
    if (exportJsonBtn) {
      exportJsonBtn.onclick = () => exportJson(currentReport, currentJobId);
    }
    if (exportMdBtn) {
      exportMdBtn.onclick = () => exportMarkdown(currentReport, currentJobId);
    }
    if (exportPdfBtn) {
      exportPdfBtn.onclick = () => exportPdf(currentReport, currentJobId);
    }
    
    if (window.innerWidth < 1100) {
      reportPanel.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  } catch (err) {
    logLine(`Could not load report: ${err.message}`, "term-err");
  }
}

// ===== Rendering helpers =====
function renderScorecard(s) {
  const ratingClass = s.risk_rating === "Good" ? "score-good" : s.risk_rating === "Needs Attention" ? "score-warn" : "score-bad";
  return `
    <div class="scorecard">
      <div class="scorecard-main ${ratingClass}">
        <div class="scorecard-number">${s.risk_score}</div>
        <div class="scorecard-label">/ 100 — ${escapeHtml(s.risk_rating)}</div>
      </div>
      <div class="scorecard-grid">
        <div class="scorecard-item"><span class="sc-num">${s.open_ports}</span><span class="sc-label">Open Ports</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.subdomains_found}</span><span class="sc-label">Subdomains</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.endpoints_found}</span><span class="sc-label">Endpoints</span></div>
        <div class="scorecard-item sev-critical-text"><span class="sc-num">${s.cve_critical}</span><span class="sc-label">Critical CVEs</span></div>
        <div class="scorecard-item sev-high-text"><span class="sc-num">${s.cve_high}</span><span class="sc-label">High CVEs</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.total_cves}</span><span class="sc-label">Total CVEs</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.session_or_jwt_cookies}</span><span class="sc-label">Session/JWT Cookies</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.missing_security_headers}</span><span class="sc-label">Missing Headers</span></div>
        <div class="scorecard-item"><span class="sc-num">${s.waf_detected ? "Yes" : "No"}</span><span class="sc-label">WAF Detected</span></div>
      </div>
    </div>`;
}

function section(id, title, bodyHtml, openByDefault = true) {
  return `
    <div class="report-section ${openByDefault ? "open" : ""}" id="sec-${id}">
      <div class="report-section-head" onclick="document.getElementById('sec-${id}').classList.toggle('open')">
        <span>${title}</span>
        <span class="chevron">▶</span>
      </div>
      <div class="report-section-body">${bodyHtml}</div>
    </div>`;
}

function kvTable(obj) {
  if (!obj || typeof obj !== "object") return `<p class="section-note">No data.</p>`;
  const rows = Object.entries(obj)
    .filter(([k, v]) => v !== null && v !== undefined && !(Array.isArray(v) && v.length === 0))
    .map(([k, v]) => {
      let val = Array.isArray(v) ? v.join(", ") : (typeof v === "object" ? JSON.stringify(v) : v);
      return `<tr><td>${escapeHtml(k)}</td><td>${escapeHtml(val)}</td></tr>`;
    }).join("");
  return rows ? `<table class="kv-table">${rows}</table>` : `<p class="section-note">No data returned.</p>`;
}

function tagList(items, variantFn) {
  if (!items || !items.length) return `<p class="section-note">None found.</p>`;
  return `<div class="tag-list">${items.map(i => {
    const cls = variantFn ? variantFn(i) : "";
    return `<span class="tag ${cls}">${escapeHtml(typeof i === "object" ? JSON.stringify(i) : i)}</span>`;
  }).join("")}</div>`;
}

function miniTable(rows, columns) {
  if (!rows || !rows.length) return `<p class="section-note">None found.</p>`;
  const head = columns.map(c => `<th>${escapeHtml(c.label)}</th>`).join("");
  const body = rows.map(r => `<tr>${columns.map(c => `<td class="${c.cls ? c.cls(r) : ''}">${escapeHtml(c.get(r))}</td>`).join("")}</tr>`).join("");
  return `<table class="mini-table"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
}

function linkList(items) {
  if (!items || !items.length) return `<p class="section-note">None found.</p>`;
  return `<ul class="link-list">${items.slice(0, 60).map(l =>
    `<li><a href="${escapeHtml(l)}" target="_blank" rel="noopener">${escapeHtml(l)}</a></li>`).join("")}</ul>`;
}

function rawToggle(id, content) {
  return `<span class="raw-toggle" onclick="const el=document.getElementById('${id}'); el.style.display = el.style.display==='none' ? 'block' : 'none';">▸ view raw</span>
          <div class="raw-block" id="${id}" style="display:none">${escapeHtml(content)}</div>`;
}

// ===== Main render =====
function renderReport(report) {
  let html = "";

  // --- Executive summary scorecard (always first — the "easy to see" view) ---
  if (report.executive_summary) {
    html += renderScorecard(report.executive_summary);
  }

  // --- Target / Domain summary ---
  if (report.target) {
    html += section("target", "🎯 Target Summary", kvTable(report.target), true);
  }

  // --- DNS & WHOIS ---
  if (report.dns_whois) {
    const d = report.dns_whois;
    let body = `<h4 style="margin:0 0 6px;color:var(--teal);font-size:11.5px;">Primary IP</h4>${kvTable({ "IP Address": d.primary_ip })}`;
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">DNS Records</h4>`;
    if (d.dns_records && Object.keys(d.dns_records).length) {
      body += miniTable(
        Object.entries(d.dns_records).flatMap(([type, vals]) => vals.map(v => ({ type, v }))),
        [{ label: "Type", get: r => r.type }, { label: "Value", get: r => r.v }]
      );
    } else {
      body += `<p class="section-note">No records resolved.</p>`;
    }
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">WHOIS</h4>`;
    body += d.whois && !d.whois.error ? kvTable(d.whois) : `<p class="section-note">WHOIS lookup unavailable: ${escapeHtml(d.whois?.error || "unknown")}. (WHOIS uses port 43, which some sandboxed/corporate networks block — will work on a normal internet connection.)</p>`;
    html += section("dns", "🌐 Domain, DNS &amp; WHOIS", body);
  }

  // --- Subdomains ---
  if (report.subdomains) {
    const s = report.subdomains;
    let body = `<p class="section-note">${s.total_found} subdomain(s) found via ${escapeHtml(s.source || "")}.</p>`;
    body += tagList(s.subdomains);
    if (s.resolved_with_ip && s.resolved_with_ip.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Resolved with IP</h4>`;
      body += miniTable(s.resolved_with_ip, [{ label: "Subdomain", get: r => r.subdomain }, { label: "IP", get: r => r.ip }]);
    }
    html += section("subs", "🧩 Subdomains", body);
  }

  // --- Network scan ---
  if (report.network_scan) {
    const n = report.network_scan;
    let body = kvTable({ "Scan engine": n.engine, "OS guess": n.os_guess, "Ports checked": n.ports_scanned });
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Open Ports &amp; Services</h4>`;
    body += miniTable(n.open_ports, [
      { label: "Port", get: r => r.port, cls: () => "port-open" },
      { label: "Service", get: r => r.service || r.protocol || "" },
      { label: "Version / Banner", get: r => r.version_guess || r.banner || "—" },
    ]);
    if (n.raw_output) body += rawToggle("raw-nmap", n.raw_output);
    html += section("netscan", "🛰️ Network Scan (Ports / Services / OS)", body);
  }

  // --- Web recon ---
  if (report.web_recon) {
    const w = report.web_recon;
    let body = kvTable({
      "Status code": w.status_code, "Server banner": w.server_banner,
      "WAF/CDN detected": (w.waf_detected || []).join(", ") || "None detected",
    });
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Technologies</h4>${tagList(w.technologies, () => "tag-teal")}`;
    body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Cookies</h4>`;
    body += miniTable(w.cookies, [
      { label: "Name", get: r => r.name },
      { label: "Type", get: r => r.type, cls: r => r.type === "JWT" ? "cookie-jwt" : (r.type === "Session ID" ? "cookie-session" : "") },
      { label: "HttpOnly", get: r => r.http_only ? "yes" : "no" },
      { label: "Secure", get: r => r.secure ? "yes" : "no" },
      { label: "SameSite", get: r => r.same_site || "—" },
    ]);
    if (w.ssl_certificate) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">SSL Certificate</h4>${kvTable(w.ssl_certificate)}`;
    }
    if (w.headers) body += rawToggle("raw-headers", JSON.stringify(w.headers, null, 2));
    html += section("webrecon", "🔐 Web Recon (Headers / Cookies / SSL / WAF)", body);
  }

  // --- Endpoints ---
  if (report.endpoints) {
    const e = report.endpoints;
    let body = `<p class="section-note">${e.total_endpoints} total endpoint(s) discovered.</p>`;
    body += `<h4 style="margin:10px 0 6px;color:var(--teal);font-size:11.5px;">Crawled Links</h4>${linkList(e.crawled_links)}`;
    if (e.well_known_paths_present && e.well_known_paths_present.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Well-Known Paths Present</h4>`;
      body += miniTable(e.well_known_paths_present, [
        { label: "Path", get: r => r.path, cls: () => "port-open" },
        { label: "Status", get: r => r.status },
        { label: "Size (bytes)", get: r => r.size_bytes },
      ]);
    }
    if (e.forms_found && e.forms_found.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Forms</h4>`;
      body += miniTable(e.forms_found, [
        { label: "Action", get: r => r.action }, { label: "Method", get: r => r.method },
        { label: "Inputs", get: r => (r.inputs || []).join(", ") },
      ]);
    }
    if (e.disclosed_via_robots_sitemap && e.disclosed_via_robots_sitemap.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Disclosed via robots.txt / sitemap.xml</h4>`;
      body += miniTable(e.disclosed_via_robots_sitemap, [
        { label: "Source", get: r => r.source }, { label: "Directive", get: r => r.directive }, { label: "Path", get: r => r.path },
      ]);
    }
    html += section("endpoints", "🕸️ Endpoint Discovery", body);
  }

  // --- CVE Intelligence ---
  if (report.cve_lookup) {
    const c = report.cve_lookup;
    let body = `<p class="section-note">${c.total_cves_found} CVE(s) found across ${c.software_checked} software version(s) checked against the free NVD database. ${c.note || ""}</p>`;
    if (c.findings && c.findings.length) {
      c.findings.forEach(f => {
        if (!f.cves.length) return;
        body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">${escapeHtml(f.product)} ${escapeHtml(f.version)} <span class="section-note">(${escapeHtml(f.source)})</span></h4>`;
        body += `<table class="mini-table"><thead><tr><th>CVE</th><th>Severity</th><th>CVSS</th><th>Published</th><th>Description</th></tr></thead><tbody>`;
        f.cves.forEach(cv => {
          body += `<tr>
            <td><a href="${escapeHtml(cv.url)}" target="_blank" rel="noopener" style="color:var(--blue)">${escapeHtml(cv.cve_id)}</a></td>
            <td><span class="sev-badge sev-${(cv.severity || 'unknown').toLowerCase()}">${escapeHtml(cv.severity)}</span></td>
            <td>${cv.cvss_score ?? "—"}</td>
            <td>${escapeHtml(cv.published)}</td>
            <td style="max-width:280px;">${escapeHtml(cv.description)}</td>
          </tr>`;
        });
        body += `</tbody></table>`;
      });
      if (!c.total_cves_found) body += `<p class="section-note">No known CVEs matched for the versions detected — good sign, though this only covers software with a clearly parsed version string.</p>`;
    }
    if (c.software_detected && c.software_detected.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">All Detected Software</h4>`;
      body += miniTable(c.software_detected, [
        { label: "Product", get: r => r.product }, { label: "Version", get: r => r.version || "—" }, { label: "Source", get: r => r.source },
      ]);
    }
    html += section("cve", "🛡️ Vulnerability Intelligence (CVE Matches)", body, true);
  }

  // --- OSINT ---
  if (report.osint) {
    const o = report.osint;
    let body = "";
    if (o.github) {
      body += `<h4 style="margin:0 0 6px;color:var(--teal);font-size:11.5px;">GitHub</h4>`;
      body += o.github.found ? kvTable(o.github.org) : `<p class="section-note">${escapeHtml(o.github.note)}</p>`;
      if (o.github.public_members && o.github.public_members.length) {
        body += miniTable(o.github.public_members, [{ label: "Username", get: r => r.username }, { label: "Profile", get: r => r.profile }]);
      }
    }
    if (o.search_dorks) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Search Dorks (click to open manually)</h4>`;
      body += `<ul class="link-list">${Object.entries(o.search_dorks).map(([label, url]) =>
        `<li>${escapeHtml(label.replace(/_/g, " "))}: <a href="${escapeHtml(url)}" target="_blank" rel="noopener">open ↗</a></li>`).join("")}</ul>`;
      body += `<p class="section-note">These generate search-engine queries rather than scraping platforms directly — the ToS-safe way to gather this category of OSINT.</p>`;
    }
    if (o.email_pattern_examples && o.email_pattern_examples.length) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Email Pattern Guesses</h4>`;
      body += miniTable(o.email_pattern_examples, [{ label: "Pattern", get: r => r.pattern }, { label: "Confidence", get: r => r.confidence }]);
    }
    if (o.breach_check) {
      body += `<h4 style="margin:14px 0 6px;color:var(--teal);font-size:11.5px;">Data Breach Exposure</h4>${kvTable(o.breach_check)}`;
    }
    html += section("osint", "🕵️ OSINT — Company / Employees / Breaches", body);
  }

  reportBody.innerHTML = html || `<p class="empty-state">No data returned.</p>`;
}

// ===== Export helpers =====
let currentReport = null;
let currentJobId = null;

function exportJson(report, jobId) {
  if (!report) return;
  const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `VAPT_Report_${jobId}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function exportMarkdown(report, jobId) {
  if (!report) return;
  const md = generateReportMarkdown(report, jobId);
  const blob = new Blob([md], { type: "text/markdown" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `VAPT_Report_${jobId}.md`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function exportPdf(report, jobId) {
  if (!report) return;
  
  const tempDiv = document.createElement("div");
  tempDiv.style.position = "fixed";
  tempDiv.style.left = "-9999px";
  tempDiv.style.top = "-9999px";
  document.body.appendChild(tempDiv);
  
  tempDiv.innerHTML = generateVaptHtmlReport(report, jobId);
  
  if (typeof html2pdf === "undefined") {
    const script = document.createElement("script");
    script.src = "https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js";
    script.onload = () => {
      runHtml2Pdf(tempDiv, jobId);
    };
    script.onerror = () => {
      alert("Failed to load PDF generation library from CDN.");
      document.body.removeChild(tempDiv);
    };
    document.head.appendChild(script);
  } else {
    runHtml2Pdf(tempDiv, jobId);
  }
}

function runHtml2Pdf(element, jobId) {
  const opt = {
    margin:       10,
    filename:     `VAPT_Report_${jobId}.pdf`,
    image:        { type: 'jpeg', quality: 0.98 },
    html2canvas:  { scale: 2, useCORS: true, letterRendering: true },
    jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' },
    pagebreak:    { mode: ['avoid-all', 'css', 'legacy'] }
  };
  
  html2pdf().from(element).set(opt).save().then(() => {
    document.body.removeChild(element);
  });
}

function generateReportMarkdown(report, jobId) {
  const target = report.target || report.base_url || "N/A";
  const riskScore = report.executive_summary?.risk_score ?? 100;
  const riskRating = report.executive_summary?.risk_rating || "HIGH";
  
  let md = `# VAPT HIGH-LEVEL TESTER REPORT\n\n`;
  md += `## 1. Report Information\n\n`;
  md += `| Field | Details |\n`;
  md += `| :--- | :--- |\n`;
  md += `| Report ID | VAPT-${jobId.toUpperCase()} |\n`;
  md += `| Client / Organization | Cyverion Security User |\n`;
  md += `| Target Domain | ${target} |\n`;
  md += `| Assessment Type | Vulnerability Assessment / Penetration Testing |\n`;
  md += `| Testing Status | Completed |\n`;
  md += `| Tester / Team | Cyverion Automated Core |\n`;
  md += `| Time Zone | IST (UTC+05:30) |\n`;
  md += `\n---\n\n`;
  
  md += `## 2. Executive Summary\n\n`;
  md += `A automated security assessment was performed against the target: **${target}**.\n\n`;
  md += `### Overall Security Rating\n\n`;
  md += `**Risk Level: ${riskRating.toUpperCase()} (Score: ${riskScore}/100)**\n\n`;
  md += `### Assessment Summary\n\n`;
  md += `| Metric | Result |\n`;
  md += `| :--- | ---: |\n`;
  md += `| Subdomains Discovered | ${report.subdomains?.total_found ?? 0} |\n`;
  md += `| Open Ports Identified | ${(report.network_scan?.open_ports || []).length} |\n`;
  md += `| Vulnerabilities Found | ${(report.findings || []).length} |\n`;
  md += `| Critical | ${report.executive_summary?.severity_counts?.critical ?? report.executive_summary?.cve_critical ?? 0} |\n`;
  md += `| High | ${report.executive_summary?.severity_counts?.high ?? report.executive_summary?.cve_high ?? 0} |\n`;
  md += `| Medium | ${report.executive_summary?.severity_counts?.medium ?? 0} |\n`;
  md += `| Low | ${report.executive_summary?.severity_counts?.low ?? 0} |\n`;
  md += `\n---\n\n`;
  
  md += `## 3. Technology Stack\n\n`;
  md += `* **Web Server**: ${report.web_recon?.server_banner || "N/A"}\n`;
  md += `* **Exposed Technologies**: ${(report.web_recon?.technologies || []).join(", ") || "N/A"}\n`;
  md += `* **CDN/WAF**: ${(report.web_recon?.waf_detected || []).join(", ") || "None Detected"}\n\n`;
  md += `\n---\n\n`;
  
  md += `## 4. Service & Port Discovery\n\n`;
  md += `| Port | Service | Version banner / OS guess |\n`;
  md += `| :--- | :--- | :--- |\n`;
  if (report.network_scan?.open_ports && report.network_scan.open_ports.length) {
    report.network_scan.open_ports.forEach(p => {
      md += `| ${p.port} | ${p.service || p.protocol || "N/A"} | ${p.version_guess || p.banner || "—"} |\n`;
    });
  } else {
    md += `| — | — | No open ports identified |\n`;
  }
  md += `\n---\n\n`;
  
  md += `## 5. Detailed Findings Report\n\n`;
  if (report.findings && report.findings.length) {
    report.findings.forEach((f, i) => {
      md += `### VAPT-${String(i+1).padStart(3, '0')} — ${f.title}\n\n`;
      md += `* **Severity**: ${f.severity.toUpperCase()}\n`;
      md += `* **CWE**: ${f.cwe || "N/A"}\n`;
      md += `* **Affected Endpoint**: ${f.url || f.file_path || "N/A"}\n`;
      md += `* **Status**: ${f.is_fixed ? "Remediation Confirmed" : "Active"}\n\n`;
      md += `#### Description\n\n${f.description || "No description provided."}\n\n`;
      if (f.evidence) {
        const evidenceStr = typeof f.evidence === 'string' ? f.evidence : (f.evidence.code_snippet || f.evidence.request || JSON.stringify(f.evidence, null, 2));
        md += `#### Evidence\n\n\`\`\`\n${evidenceStr}\n\`\`\`\n\n`;
      }
      md += `#### Recommendation\n\n${f.recommendation || "Implement standard remediation controls."}\n\n`;
      if (f.suggested_fix) {
        md += `#### Suggested Secure Fix\n\n\`\`\`\n${f.suggested_fix}\n\`\`\`\n\n`;
      }
      md += `\n---\n\n`;
    });
  } else {
    md += `*No findings were recorded for this scan.*\n`;
  }
  
  return md;
}

function generateVaptHtmlReport(report, jobId) {
  const target = report.target || report.base_url || "N/A";
  const riskScore = report.executive_summary?.risk_score ?? 100;
  const riskRating = report.executive_summary?.risk_rating || "HIGH";
  
  return `
    <div style="font-family: 'Inter', 'Segoe UI', Arial, sans-serif; color: #1e293b; padding: 25px; background: #fff; box-sizing: border-box;">
      <div style="border-bottom: 2px solid #0f172a; padding-bottom: 15px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center;">
        <div>
          <h1 style="margin: 0; font-size: 26px; color: #e11d48; font-weight: 800; letter-spacing: 0.5px;">CYVERION</h1>
          <p style="margin: 4px 0 0 0; font-size: 13px; font-weight: 700; text-transform: uppercase; color: #64748b; letter-spacing: 0.5px;">VAPT High-Level Tester Report</p>
        </div>
        <div style="text-align: right;">
          <p style="margin: 0; font-size: 12px; color: #475569;">Report ID: <strong>VAPT-${jobId.toUpperCase()}</strong></p>
          <p style="margin: 4px 0 0 0; font-size: 11px; color: #94a3b8;">Generated: ${new Date().toLocaleString()}</p>
        </div>
      </div>

      <div style="margin-bottom: 30px;">
        <h2 style="font-size: 15px; border-left: 4px solid #e11d48; padding-left: 8px; margin-bottom: 12px; color: #0f172a; text-transform: uppercase; font-weight: 700;">1. Report Information</h2>
        <table style="width: 100%; border-collapse: collapse; font-size: 12.5px;">
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; width: 30%; background: #f8fafc; color: #475569;">Report ID</td>
            <td style="padding: 7px; color: #1e293b; font-family: monospace;">VAPT-${jobId.toUpperCase()}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; background: #f8fafc; color: #475569;">Target URL/Domain</td>
            <td style="padding: 7px; color: #1e293b; font-family: monospace;">${escapeHtml(target)}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; background: #f8fafc; color: #475569;">Assessment Type</td>
            <td style="padding: 7px; color: #1e293b;">Vulnerability Assessment / Penetration Testing</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; background: #f8fafc; color: #475569;">Testing Status</td>
            <td style="padding: 7px; font-weight: 700; color: #10b981;">Completed</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; background: #f8fafc; color: #475569;">Tester Team</td>
            <td style="padding: 7px; color: #1e293b;">Cyverion Automated Security Core</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; background: #f8fafc; color: #475569;">Time Zone</td>
            <td style="padding: 7px; color: #1e293b;">IST (UTC+05:30)</td>
          </tr>
        </table>
      </div>

      <div style="margin-bottom: 30px; page-break-inside: avoid;">
        <h2 style="font-size: 15px; border-left: 4px solid #e11d48; padding-left: 8px; margin-bottom: 12px; color: #0f172a; text-transform: uppercase; font-weight: 700;">2. Executive Summary</h2>
        <p style="font-size: 13px; line-height: 1.55; margin: 0 0 15px 0; color: #334155;">
          A security vulnerability assessment was completed against the target **${escapeHtml(target)}**. 
          This high-level summary encapsulates subdomain intelligence, service mapping, open ports detection, and correlated common vulnerabilities and exposures (CVEs).
        </p>
        
        <div style="display: flex; gap: 15px; margin-bottom: 15px;">
          <div style="flex: 1; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; text-align: center; background: #fffcfc; border-left: 4px solid #e11d48;">
            <p style="margin: 0; font-size: 10.5px; text-transform: uppercase; font-weight: 600; color: #64748b;">Risk Rating</p>
            <h3 style="margin: 4px 0 0 0; font-size: 20px; font-weight: 800; color: ${riskRating === 'Good' ? '#10b981' : (riskRating === 'Needs Attention' ? '#f59e0b' : '#e11d48')};">${escapeHtml(riskRating)}</h3>
          </div>
          <div style="flex: 1; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; text-align: center; background: #f8fafc;">
            <p style="margin: 0; font-size: 10.5px; text-transform: uppercase; font-weight: 600; color: #64748b;">Risk Score</p>
            <h3 style="margin: 4px 0 0 0; font-size: 20px; font-weight: 800; color: #0f172a;">${riskScore} / 100</h3>
          </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; font-size: 12.5px;">
          <thead>
            <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1; text-align: left;">
              <th style="padding: 7px; font-weight: 600; color: #475569;">Assessment Metric</th>
              <th style="padding: 7px; font-weight: 600; color: #475569; text-align: right;">Result</th>
            </tr>
          </thead>
          <tbody>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 7px; color: #334155;">Subdomains Discovered</td>
              <td style="padding: 7px; color: #1e293b; text-align: right; font-weight: 600;">${report.subdomains?.total_found ?? 0}</td>
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 7px; color: #334155;">Open Ports Identified</td>
              <td style="padding: 7px; color: #1e293b; text-align: right; font-weight: 600;">${(report.network_scan?.open_ports || []).length}</td>
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 7px; color: #334155;">Total Vulnerabilities Found</td>
              <td style="padding: 7px; color: #e11d48; text-align: right; font-weight: 600;">${(report.findings || []).length}</td>
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 7px; color: #64748b; padding-left: 20px; font-size: 11.5px;">Critical Severity</td>
              <td style="padding: 7px; color: #e11d48; text-align: right; font-weight: 600; font-size: 11.5px;">${report.executive_summary?.severity_counts?.critical ?? report.executive_summary?.cve_critical ?? 0}</td>
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 7px; color: #64748b; padding-left: 20px; font-size: 11.5px;">High Severity</td>
              <td style="padding: 7px; color: #f59e0b; text-align: right; font-weight: 600; font-size: 11.5px;">${report.executive_summary?.severity_counts?.high ?? report.executive_summary?.cve_high ?? 0}</td>
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 7px; color: #64748b; padding-left: 20px; font-size: 11.5px;">Medium Severity</td>
              <td style="padding: 7px; color: #334155; text-align: right; font-weight: 600; font-size: 11.5px;">${report.executive_summary?.severity_counts?.medium ?? 0}</td>
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td style="padding: 7px; color: #64748b; padding-left: 20px; font-size: 11.5px;">Low Severity</td>
              <td style="padding: 7px; color: #64748b; text-align: right; font-weight: 600; font-size: 11.5px;">${report.executive_summary?.severity_counts?.low ?? 0}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div style="margin-bottom: 30px; page-break-inside: avoid;">
        <h2 style="font-size: 15px; border-left: 4px solid #e11d48; padding-left: 8px; margin-bottom: 12px; color: #0f172a; text-transform: uppercase; font-weight: 700;">3. Scope &amp; Tech Stack</h2>
        <table style="width: 100%; border-collapse: collapse; font-size: 12.5px;">
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; width: 30%; background: #f8fafc; color: #475569;">Web Server</td>
            <td style="padding: 7px; color: #1e293b;">${escapeHtml(report.web_recon?.server_banner || "N/A")}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; background: #f8fafc; color: #475569;">Technologies</td>
            <td style="padding: 7px; color: #1e293b;">${escapeHtml((report.web_recon?.technologies || []).join(", ") || "N/A")}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 7px; font-weight: 600; background: #f8fafc; color: #475569;">WAF/CDN</td>
            <td style="padding: 7px; color: #1e293b;">${escapeHtml((report.web_recon?.waf_detected || []).join(", ") || "None Detected")}</td>
          </tr>
        </table>
      </div>

      <div style="margin-bottom: 30px;">
        <h2 style="font-size: 15px; border-left: 4px solid #e11d48; padding-left: 8px; margin-bottom: 12px; color: #0f172a; text-transform: uppercase; font-weight: 700;">4. Port Discovery &amp; Services</h2>
        <table style="width: 100%; border-collapse: collapse; font-size: 12.5px; text-align: left;">
          <thead>
            <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
              <th style="padding: 7px; font-weight: 600; color: #475569;">Port</th>
              <th style="padding: 7px; font-weight: 600; color: #475569;">Service</th>
              <th style="padding: 7px; font-weight: 600; color: #475569;">Version Guess / Banner</th>
            </tr>
          </thead>
          <tbody>
            ${(report.network_scan?.open_ports || []).map(p => `
              <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="padding: 7px; color: #0284c7; font-weight: 700; font-family: monospace;">${escapeHtml(p.port)}</td>
                <td style="padding: 7px; color: #1e293b;">${escapeHtml(p.service || p.protocol || "N/A")}</td>
                <td style="padding: 7px; color: #475569; font-family: monospace; font-size: 11.5px;">${escapeHtml(p.version_guess || p.banner || "—")}</td>
              </tr>
            `).join("") || `<tr><td colspan="3" style="padding: 10px; text-align: center; color: #64748b; font-style: italic;">No open ports identified.</td></tr>`}
          </tbody>
        </table>
      </div>

      <div style="page-break-before: always;"></div>

      <div style="margin-bottom: 30px;">
        <h2 style="font-size: 15px; border-left: 4px solid #e11d48; padding-left: 8px; margin-bottom: 15px; color: #0f172a; text-transform: uppercase; font-weight: 700;">5. Detailed Findings Report</h2>
        
        ${(report.findings || []).map((f, i) => {
          const sev = (f.severity || "info").toLowerCase();
          const sevColor = sev === 'critical' ? '#e11d48' : (sev === 'high' ? '#f59e0b' : (sev === 'medium' ? '#3b82f6' : '#64748b'));
          const bg = sev === 'critical' ? '#fff1f2' : (sev === 'high' ? '#fffbeb' : '#f8fafc');
          
          let evidenceText = "";
          if (f.evidence) {
            evidenceText = typeof f.evidence === 'string' ? f.evidence : (f.evidence.code_snippet || f.evidence.request || JSON.stringify(f.evidence, null, 2));
          }
          
          return `
            <div style="border: 1px solid #e2e8f0; border-radius: 6px; margin-bottom: 20px; page-break-inside: avoid; background: ${bg}; overflow: hidden;">
              <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 15px; border-bottom: 1px solid #e2e8f0; background: #fff;">
                <span style="font-weight: 700; font-size: 13.5px; color: #0f172a;">VAPT-${String(i+1).padStart(3, '0')} — ${escapeHtml(f.title)}</span>
                <span style="background: ${sevColor}; color: #fff; font-size: 10.5px; font-weight: 700; text-transform: uppercase; padding: 2px 7px; border-radius: 3px; font-family: monospace;">${escapeHtml(sev)}</span>
              </div>
              <div style="padding: 15px; font-size: 12.5px;">
                <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 11.5px;">
                  <tr style="border-bottom: 1px dashed #cbd5e1;">
                    <td style="padding: 4px 0; font-weight: 600; width: 25%; color: #64748b;">Classification / CWE</td>
                    <td style="padding: 4px 0; color: #1e293b; font-family: monospace;">${escapeHtml(f.cwe || "N/A")}</td>
                  </tr>
                  <tr style="border-bottom: 1px dashed #cbd5e1;">
                    <td style="padding: 4px 0; font-weight: 600; color: #64748b;">Endpoint / File Location</td>
                    <td style="padding: 4px 0; color: #1e293b; font-family: monospace; word-break: break-all;">${escapeHtml(f.url || f.file_path || "N/A")}${f.line ? ` (Line ${f.line})` : ''}</td>
                  </tr>
                  ${f.param ? `
                    <tr style="border-bottom: 1px dashed #cbd5e1;">
                      <td style="padding: 4px 0; font-weight: 600; color: #64748b;">Parameter</td>
                      <td style="padding: 4px 0; color: #1e293b; font-family: monospace;">${escapeHtml(f.param)}</td>
                    </tr>
                  ` : ''}
                  <tr style="border-bottom: 1px dashed #cbd5e1;">
                    <td style="padding: 4px 0; font-weight: 600; color: #64748b;">Status</td>
                    <td style="padding: 4px 0; font-weight: 700; color: ${f.is_fixed ? '#10b981' : '#e11d48'};">${f.is_fixed ? '✓ Remediation Confirmed' : '⚠ Active'}</td>
                  </tr>
                </table>

                <p style="margin: 0 0 5px 0; font-weight: 600; color: #475569;">Description</p>
                <p style="margin: 0 0 12px 0; line-height: 1.5; color: #334155;">${escapeHtml(f.description || "No description provided.")}</p>

                ${evidenceText ? `
                  <p style="margin: 0 0 4px 0; font-weight: 600; color: #475569;">Evidence</p>
                  <pre style="margin: 0 0 12px 0; padding: 8px; background: #0f172a; color: #38bdf8; border-radius: 4px; font-family: monospace; font-size: 11px; overflow-x: auto; white-space: pre-wrap; line-height: 1.4;">${escapeHtml(evidenceText)}</pre>
                ` : ''}

                <p style="margin: 0 0 4px 0; font-weight: 600; color: #475569;">Recommendation</p>
                <p style="margin: 0; line-height: 1.5; color: #334155; font-weight: 500; border-left: 2px solid #10b981; padding-left: 6px;">${escapeHtml(f.recommendation || "Implement secure parameterization/encoding controls.")}</p>

                ${f.suggested_fix ? `
                  <p style="margin: 12px 0 4px 0; font-weight: 600; color: #475569;">Suggested Secure Patch</p>
                  <pre style="margin: 0; padding: 8px; background: #f1f5f9; color: #0f172a; border-radius: 4px; font-family: monospace; font-size: 11.5px; border: 1px dashed #cbd5e1; overflow-x: auto; white-space: pre-wrap; line-height: 1.4;">${escapeHtml(f.suggested_fix)}</pre>
                ` : ''}
              </div>
            </div>
          `;
        }).join("") || `<p style="text-align: center; color: #64748b; font-style: italic; padding: 15px;">No findings recorded for this scan.</p>`}
      </div>

      <div style="margin-top: 40px; border-top: 1px solid #cbd5e1; padding-top: 15px; page-break-inside: avoid;">
        <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #64748b;">
          <tr>
            <td style="width: 50%;">
              <p style="margin: 0 0 2px 0;">Report Version: <strong>1.0 (Confidential)</strong></p>
              <p style="margin: 0;">System ID: <strong>CY-${jobId.toUpperCase()}</strong></p>
            </td>
            <td style="text-align: right; width: 50%;">
              <p style="margin: 0 0 2px 0; font-weight: 600; color: #475569;">Cyverion Automated Platform</p>
              <p style="margin: 0;">Testing completed successfully.</p>
            </td>
          </tr>
        </table>
      </div>
    </div>
  `;
}
