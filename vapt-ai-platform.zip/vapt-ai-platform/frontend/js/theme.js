/* ==========================================================
   CYVERION — GLOBAL THEME SYNC (Classic / Hacker / CEO)
   Shared across Admin, Recon & Module 2 pages.

   Persists the chosen theme in localStorage so every module
   honors the same look. Exposes:
     - getTheme()
     - applyTheme(theme)
     - initThemeSync()  -> call on page load
   ========================================================== */
(function () {
  const THEME_KEY = "cyverion_admin_theme_v1";

  function getTheme() {
    let t = "classic";
    try { t = localStorage.getItem(THEME_KEY) || "classic"; } catch (e) { /* ignore */ }
    return t;
  }

  function applyTheme(theme) {
    const t = theme || getTheme();
    document.body.setAttribute("data-theme", t);
    document.querySelectorAll("[data-theme-btn]").forEach(function (btn) {
      btn.classList.toggle("active", btn.dataset.themeBtn === t);
    });
    try { localStorage.setItem(THEME_KEY, t); } catch (e) { /* ignore */ }
  }

  function initThemeSync() {
    applyTheme(getTheme());
    // Wire any theme-switch buttons already present in the DOM.
    document.querySelectorAll("[data-theme-btn]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        applyTheme(btn.dataset.themeBtn);
      });
    });
  }

  window.CYVERION_THEME = {
    getTheme: getTheme,
    applyTheme: applyTheme,
    init: initThemeSync
  };
})();

