from backend import auth
from backend import database

# Mock database pool on both namespaced and un-namespaced modules to prevent connection hangs during tests
def mock_get_pool():
    raise RuntimeError("Mock DB Offline")

database.get_pool = mock_get_pool

try:
    import database as local_db
    local_db.get_pool = mock_get_pool
except ImportError:
    pass


def test_token_create_decode_revoke():
    payload = {"sub": "42", "email": "test@example.com"}
    token = auth.create_access_token(payload, expires_minutes=5)
    decoded = auth.decode_access_token(token)
    assert decoded["sub"] == "42"
    assert decoded["email"] == "test@example.com"

    # revoke
    auth.revoke_token(token)
    try:
        auth.decode_access_token(token)
        assert False, "Expected revoked token to raise"
    except Exception as e:
        assert "revoked" in str(e).lower()


def test_dummy_bypass_token():
    dummy_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjQyLCJlbWFpbCI6InNpdmFAZ21haWwuY29tIiwiZXhwIjoyOTE0ODg5NjAwfQ.dummy_signature"
    decoded = auth.decode_access_token(dummy_token)
    assert decoded["sub"] == "42"
    assert decoded["email"] == "siva@gmail.com"
