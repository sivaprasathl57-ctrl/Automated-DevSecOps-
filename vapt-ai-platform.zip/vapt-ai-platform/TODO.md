 # Tasks

## Task 1 (DONE): Make Login, Register & Index boxes static
- [x] login.js / login.css — login-card static (removed GSAP, 3D tilt, cardShine)
- [x] register.js / register.css — register-card static
- [x] intro.js — glass-card static

## Task 2 (DONE): Input validation — fake link & empty folder detection
- [x] Empty folder detection (module2)
- [x] Fake-link heuristic
- [x] Error tips + invalid styling

## Task 3 (DONE): Server-side reachability check (no CORS)
- [x] POST /api/validate/target (DNS + HTTP)
- [x] recon.js + module2.js call it
- [x] DNS guard on /api/recon/start + /api/module2/start
- [x] Fix pre-existing `selected` NameError in start_module2

## Task 4 (DONE): Ultimate Admin Upgrade — Live 24x7 Monitor + Hacker & CEO modes
- [x] backend/main.py — add SSE GET /api/admin/monitor (live aggregate snapshot)
- [x] frontend/admin.html — add "Live Monitor" tab + live feed panels
- [x] frontend/js/admin.js — live monitor logic (fetch+ReadableStream SSE, ticking counters, uptime clock)
- [x] Wire Monitor tab into refreshActivePanel + stopMonitor on tab switch
- [x] frontend/css/style.css — Hacker theme variables + CRT/scanline effects
- [x] admin.html — theme toggle UI
- [x] admin.js — theme switching logic
- [x] theme switcher topbar toggle (Classic / Hacker / CEO), persisted in localStorage

## Task 5 (DONE): Per-user scan history + any-time report viewing (Module 2)
- [x] backend/database.py — add `module2_jobs` table + DB helpers (save/update/get history/get job any)
- [x] backend/main.py — persist Module 2 job metadata + final report in background threads
- [x] backend/main.py — add GET /api/module2/history (user-scoped)
- [x] backend/main.py — /api/module2/report falls back to DB (user-scoped, admin any)
- [x] backend/main.py — include persisted Module 2 jobs in /api/admin/scans + admin stats
- [x] frontend/module2.html — add "Recent Scan History" panel
- [x] frontend/js/module2.js — loadHistory() + click-to-open + refresh on completion
- [x] frontend/view.html — support ?mode=module2 to render Module 2 reports
- [x] frontend/js/view.js — render Module 2 report (scorecard + findings) for mode=module2
- [x] frontend/admin.js — add "Open full report" link for Module 2 jobs in scan drawer
- [x] Verify: backend py_compile + JS node --check

## Task 6 (DONE): Admin Settings — Security & Hardening with "More" button
- [x] frontend/admin.html — add "Security & Hardening" settings card with a "More security features" expand/collapse button
- [x] frontend/admin.html — add toggles: 2FA, session timeout lock, brute-force protection
- [x] frontend/admin.html — add audit retention selector + expanded features (strong passwords, admin login notify, encrypt reports, revoke sessions, regenerate API token)
- [x] frontend/css (admin.html style) — security card, status badges, more-button + caret styles
- [x] frontend/js/admin.js — persist security prefs (localStorage), apply on load, wire all toggles + more button
- [x] frontend/js/admin.js — regenerate API token + revoke-other-sessions actions with confirm dialog
- [x] Verify — admin.js node --check OK

## Task 7 (DONE): Admin Settings — Maintenance Mode + 10+ Advanced Controls
- [x] frontend/admin.html — add "Maintenance & Advanced Controls" card with password-protected maintenance mode toggle
- [x] frontend/admin.html — maintenance status flag (LIVE / MAINTENANCE), password input row, confirm button, banner
- [x] frontend/admin.html — "More advanced settings" expand button
- [x] frontend/admin.html — advanced toggles: auto backup, backup schedule, rate limiting, scan approval, email alerts, video-log retention, lock scan config, compliance mode, cloud sync, restrict admin creation, clear cache, integrity check
- [x] frontend/css (admin.html style) — maintenance card, status flag pulse, password input, advanced feature styling
- [x] frontend/js/admin.js — persist advanced + maintenance prefs (localStorage), apply on load
- [x] frontend/js/admin.js — maintenance mode requires admin password (demo "1234") to enter/exit and to unlock service
- [x] frontend/js/admin.js — wire all advanced toggles, selects, actions (clear cache, integrity check) with confirm dialogs
- [x] Verify — admin.js node --check OK
