"""Live verification of the recon information-gathering fix.

Tests the full flow against a running backend on 127.0.0.1:8000:
  1. Obtain a demo-admin JWT via the login endpoint (sub=42).
  2. POST /api/recon/start  -> must return job_id quickly (no DB hang).
  3. GET  /api/recon/stream/{job_id}?token=... -> must stream events (previously 401'd).
  4. GET  /api/recon/report/{job_id} -> must return populated report.
"""
import json
import time
import urllib.error
import urllib.parse
import urllib.request

BASE = "http://127.0.0.1:8000"


def get_token():
    """Obtain a demo-admin JWT via the running server's login endpoint."""
    data = urllib.parse.urlencode({"email": "siva@gmail.com", "password": "1234"}).encode()
    req = urllib.request.Request(f"{BASE}/api/auth/login", data=data, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = json.loads(resp.read().decode())
        if body.get("success") and body.get("token"):
            return body["token"]
        print("  !! login did not return a token:", body)
        return None
    except urllib.error.HTTPError as e:
        print("  !! login HTTP %s: %s" % (e.code, e.read().decode()[:300]))
        return None


def main():
    token = get_token()
    if not token:
        return
    print("STEP 1: got demo-admin token via login endpoint:", token[:24], "...")

    # ---- Start recon ----
    print("\nSTEP 2: POST /api/recon/start (target=localhost:8000, authorized=true)")
    data = urllib.parse.urlencode({
        "target": "http://localhost:8000",
        "authorized": "true",
        "aggressive": "false",
        "run_osint": "false",
        "company_name": "",
    }).encode()
    req = urllib.request.Request(
        f"{BASE}/api/recon/start",
        data=data,
        method="POST",
        headers={"Authorization": "Bearer %s" % token},
    )
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = json.loads(resp.read().decode())
        elapsed = time.time() - t0
        print("  -> HTTP %s in %.2fs, body=%s" % (resp.status, elapsed, body))
        if elapsed > 6:
            print("  !! WARNING: start took too long (DB hang risk)")
        job_id = body.get("job_id")
        if not job_id:
            print("  !! FAIL: no job_id returned")
            return
    except urllib.error.HTTPError as e:
        print("  !! FAIL: HTTP %s %s" % (e.code, e.read().decode()[:400]))
        return

    # ---- Stream events (the endpoint that previously 401'd) ----
    print("\nSTEP 3: GET /api/recon/stream/%s?token=..." % job_id)
    sreq = urllib.request.Request(
        "%s/api/recon/stream/%s?token=%s" % (BASE, job_id, urllib.parse.quote(token)),
        method="GET",
    )
    try:
        sresp = urllib.request.urlopen(sreq, timeout=40)
        print("  -> HTTP %s, content-type=%s" % (sresp.status, sresp.headers.get("Content-Type")))
        count = 0
        t0 = time.time()
        while time.time() - t0 < 35:
            line = sresp.readline().decode("utf-8", errors="ignore")
            if not line:
                break
            line = line.strip()
            if line.startswith("data:"):
                count += 1
                try:
                    ev = json.loads(line[5:].strip())
                    print("     EVENT[%d]: agent=%s status=%s" % (count, ev.get("agent"), ev.get("status")))
                except json.JSONDecodeError:
                    print("     RAW:", line[:120])
                if count >= 30:
                    break
        print("  -> streamed %d event(s)" % count)
        if count == 0:
            print("  !! FAIL: no events streamed (auth or SSE problem)")
        else:
            print("  -> STREAM OK")
    except Exception as e:
        print("  !! FAIL: stream error %r" % (e,))
        return

    # ---- Fetch report ----
    print("\nSTEP 4: GET /api/recon/report/%s" % job_id)
    rreq = urllib.request.Request(
        "%s/api/recon/report/%s" % (BASE, job_id),
        method="GET",
        headers={"Authorization": "Bearer %s" % token},
    )
    try:
        with urllib.request.urlopen(rreq, timeout=10) as resp:
            rdata = json.loads(resp.read().decode())
        print("  -> HTTP %s, job_status=%s" % (resp.status, rdata.get("status")))
        rep = rdata.get("report", {})
        print("  -> report keys: %s" % list(rep.keys()))
        exec_sum = rep.get("executive_summary")
        if exec_sum:
            print("  -> exec summary: risk_score=%s rating=%s" % (exec_sum.get("risk_score"), exec_sum.get("risk_rating")))
        dw = rep.get("dns_whois", {})
        print("  -> dns_whois: primary_ip=%s" % dw.get("primary_ip"))
        print("  -> REPORT OK")
    except Exception as e:
        print("  !! FAIL: report error %r" % (e,))

    print("\nDONE")


if __name__ == "__main__":
    main()

