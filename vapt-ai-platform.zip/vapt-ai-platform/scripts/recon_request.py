import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend import database, auth
import requests

email = 'e2e_366738@example.com'
password = 'TestPass123!'
user = database.login_user(email, password)
if not user:
    print('local login failed')
    raise SystemExit(1)

token = auth.create_access_token({'sub': user['id'], 'email': user['email']})
print('TOKEN=', token)
headers = {'Authorization': f'Bearer {token}'}
resp = requests.post('http://127.0.0.1:8000/api/recon/start', data={'target':'https://example.com','authorized':'true'}, headers=headers)
print('STATUS', resp.status_code)
print('BODY', resp.text)
