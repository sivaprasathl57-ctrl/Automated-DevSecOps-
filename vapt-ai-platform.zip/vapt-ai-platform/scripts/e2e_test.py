import sys
import time
import json
import uuid
from urllib import request, parse

BASE = "http://127.0.0.1:8000"


def post_form(path, data, headers=None):
    data_enc = parse.urlencode(data).encode()
    req = request.Request(BASE + path, data=data_enc, method="POST")
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    try:
        with request.urlopen(req, timeout=30) as resp:
            return resp.read().decode(), resp.getcode()
    except Exception as e:
        # Try to surface HTTP response body when available
        if hasattr(e, 'read'):
            try:
                body = e.read().decode()
                print('HTTPError body:', body)
            except Exception:
                pass
        raise


def get(path, headers=None, stream=False):
    req = request.Request(BASE + path, method="GET")
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    resp = request.urlopen(req, timeout=30)
    if stream:
        return resp
    return resp.read().decode(), resp.getcode()


if __name__ == '__main__':
    suffix = uuid.uuid4().hex[:6]
    email = f"e2e_{suffix}@example.com"
    password = "TestPass123!"

    print("Registering user...", email)
    try:
        body, code = post_form("/api/auth/register", {
            "first_name": "E2E",
            "last_name": "Tester",
            "email": email,
            "password": password,
            "phone": "",
            "organization": "QA",
            "role": "user",
        })
        print("register->", code, body)
    except Exception as e:
        print("Register failed (might already exist):", e)

    # Instead of calling the HTTP login endpoint (sometimes returns 500),
    # create a JWT locally using the database + auth modules.
    import sys, os
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    from backend import database, auth

    print("Verifying credentials locally and creating token...")
    user = database.login_user(email, password)
    if not user:
        print("Local login failed; aborting")
        sys.exit(1)
    token = auth.create_access_token({"sub": user["id"], "email": user["email"]}, expires_minutes=30)
    headers = {"Authorization": f"Bearer {token}"}

    print("Starting recon job...")
    body, code = post_form("/api/recon/start", {"target": "https://example.com", "authorized": "true"}, headers=headers)
    print("start->", code, body)
    job = json.loads(body)
    job_id = job.get("job_id")
    if not job_id:
        print("no job_id returned; aborting")
        sys.exit(1)

    print("Streaming events for 6 seconds...")
    try:
        # Use token query param for SSE
        resp = get(f"/api/recon/stream/{job_id}?token={parse.quote(token)}", stream=True)
        start = time.time()
        while time.time() - start < 6:
            line = resp.readline()
            if not line:
                break
            line = line.decode().strip()
            if line.startswith("data:"):
                print("EVENT:", line[5:].strip())
    except Exception as e:
        print("Streaming error:", e)

    print("Fetching report...")
    try:
        body, code = get(f"/api/recon/report/{job_id}", headers=headers)
        print("report->", code, body[:1000])
    except Exception as e:
        print("Report fetch error:", e)

    print("Done")
