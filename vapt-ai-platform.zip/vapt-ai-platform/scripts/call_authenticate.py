import sys, os, traceback
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend.main import authenticate_user

# Use a token generated from the same environment
from backend import database, auth
user = database.login_user('e2e_366738@example.com', 'TestPass123!')
if not user:
    print('user not found')
    raise SystemExit(1)

token = auth.create_access_token({'sub': user['id'], 'email': user['email']})
header = f'Bearer {token}'
print('Calling authenticate_user with header fingerprint:', header[:64])
try:
    u = authenticate_user(header)
    print('authenticate_user returned:', u)
except Exception as e:
    print('authenticate_user raised:')
    traceback.print_exc()
