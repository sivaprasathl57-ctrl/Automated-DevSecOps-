import traceback
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend import database

email = 'e2e_91b2f8@example.com'
password = 'TestPass123!'

try:
    user = database.login_user(email, password)
    print('login_user returned:', user)
except Exception as e:
    print('Exception from login_user:')
    traceback.print_exc()
