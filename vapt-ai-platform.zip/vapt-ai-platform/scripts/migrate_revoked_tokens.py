#!/usr/bin/env python3
"""Run simple DB migration to ensure revoked_tokens table exists."""
import os
import psycopg2

DB_HOST = os.getenv('DB_HOST', 'localhost')
DB_PORT = int(os.getenv('DB_PORT', '5432'))
DB_NAME = os.getenv('DB_NAME', 'VAPT')
DB_USER = os.getenv('DB_USER', 'postgres')
DB_PASSWORD = os.getenv('DB_PASSWORD', '12345')

SQL = '''
CREATE TABLE IF NOT EXISTS revoked_tokens (
  token TEXT PRIMARY KEY,
  revoked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
'''

if __name__ == '__main__':
    dsn = f"host={DB_HOST} port={DB_PORT} dbname={DB_NAME} user={DB_USER} password={DB_PASSWORD}"
    with psycopg2.connect(dsn) as conn:
        with conn.cursor() as cur:
            cur.execute(SQL)
            conn.commit()
    print('Migration complete')
