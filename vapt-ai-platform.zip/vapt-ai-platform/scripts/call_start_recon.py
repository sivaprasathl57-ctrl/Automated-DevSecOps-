import sys, os, asyncio
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend import database, auth
from backend.main import start_recon

user = database.login_user('e2e_366738@example.com', 'TestPass123!')
if not user:
    print('user not found')
    raise SystemExit(1)

token = auth.create_access_token({'sub': user['id'], 'email': user['email']})
header = f'Bearer {token}'

async def run():
    try:
        res = await start_recon(target='https://example.com', aggressive=False, run_osint=False, company_name=None, authorized=True, authorization=header)
        print('start_recon returned', res)
    except Exception as e:
        import traceback; traceback.print_exc()

asyncio.run(run())
