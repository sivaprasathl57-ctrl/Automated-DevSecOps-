"""List all distinct roles and emails in the users table."""
import sys, os, json
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend import database

try:
    conn = database.get_conn()
    with conn.cursor(cursor_factory=database.RealDictCursor) as cur:
        cur.execute("SELECT user_id, email, role, account_status FROM users ORDER BY user_id")
        rows = cur.fetchall()
    database.put_conn(conn)
    print("ALL USERS:")
    for r in rows:
        print(f"  id={r['user_id']}  email={r['email']!r}  role={r['role']!r}  status={r['account_status']!r}")
    print("\nDISTINCT ROLES:")
    roles = set((r['role'] or '').strip() for r in rows)
    for rol in sorted(roles):
        print(f"  {rol!r}")
except Exception as e:
    print("Query failed:", repr(e))
