"""Diagnose why the Administrator login redirects to recon instead of admin."""
import sys, os, json
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend import database

EMAIL = "sivaprasathl57@gmail.com"
PASSWORD = "Siva123#"

# 1) Raw row from DB
try:
    conn = database.get_conn()
    with conn.cursor(cursor_factory=database.RealDictCursor) as cur:
        cur.execute(
            "SELECT user_id, email, role, account_status FROM users WHERE email = %s",
            (EMAIL,),
        )
        row = cur.fetchone()
    database.put_conn(conn)
    print("RAW DB ROW:", json.dumps(dict(row), indent=2, default=str) if row else "NOT FOUND")
except Exception as e:
    print("DB query failed:", repr(e))

# 2) login_user result
try:
    user = database.login_user(EMAIL, PASSWORD)
    print("login_user result:", json.dumps(user, indent=2, default=str))
    if user:
        print("role value =", repr(user.get("role")))
        print("role lowercase =", repr((user.get("role") or "").lower()))
except Exception as e:
    print("login_user raised:", repr(e))

