"""Verify the login response and admin-role checks that affect role-based redirects."""
import sys, os, json
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend')))

from fastapi.testclient import TestClient
import main as app_module
from database import login_user
from auth import create_access_token

EMAIL = "sivaprasathl57@gmail.com"
PASSWORD = "Siva123#"

print("=" * 70)
print("1) /api/auth/login response for the admin credential")
print("=" * 70)
client = TestClient(app_module.app)
resp = client.post("/api/auth/login", data={"email": EMAIL, "password": PASSWORD})
print("HTTP status:", resp.status_code)
try:
    data = resp.json()
    print("response:", json.dumps(data, indent=2, default=str))
    if data.get("success"):
        role = data.get("user", {}).get("role")
        print("\nrole from login response:", repr(role))
        key = (role or "").strip().lower()
        ROLE_PAGE_MAP = {
            "student": "student.html",
            "developer": "developer.html",
            "security analyst": "security-analyst.html",
            "penetration tester": "pentester.html",
            "administrator": "admin.html",
            "admin": "admin.html",
        }
        target = ROLE_PAGE_MAP.get(key, "recon.html (DEFAULT)")
        print("frontend getPageForRole would redirect to:", target)
except Exception as e:
    print("could not parse json:", repr(e), resp.text[:500])

print()
print("=" * 70)
print("2) require_admin() with a valid token for the Administrator user")
print("=" * 70)
try:
    user = login_user(EMAIL, PASSWORD)
    print("login_user role:", repr(user.get("role")) if user else None)
    token = create_access_token({"sub": str(user["id"]), "email": user["email"]})
    try:
        app_module.require_admin("Bearer " + token)
        print("require_admin: PASSED (no exception) -> admin APIs allowed")
    except Exception as e:
        print(f"require_admin: FAILED with {type(e).__name__}: {getattr(e, 'detail', e)}")
        print("=> admin APIs would return 403, so the Admin console data calls break")
except Exception as e:
    print("setup error:", repr(e))

print()
print("=" * 70)
print("3) recon_report is_admin computation (same role comparison)")
print("=" * 70)
role = (login_user(EMAIL, PASSWORD) or {}).get("role")
lower = (role or "").lower()
is_admin_current = lower == "Administrator"          # what the code does today
is_admin_fixed = lower in ("administrator", "admin") # what it should be
print("stored role:", repr(role))
print("current code (lower == 'Administrator'):", is_admin_current)
print("fixed code  (lower in admin set):", is_admin_fixed)
